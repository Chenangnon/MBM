#' Run a Simulation Experiment
#'
#' This function runs a simulation experiment on Multistage Binomial Model based Regression
#'
#' @param n numeric vector of sample sizes.
#' Note that the supplied \code{n} is ignored if a non null \code{w} is
#' provided: only one sample size is then considered, namely the number of
#' rows of \code{w}.
#'
#' @param verbose numeric integer, if positive, information is printed during the running of step.
#' Larger values may give more detailed information.
#'
#' @param models character vector, specifies desired fitting models.
#' One or many of \code{'M0'} (univariate model \code{y ~ w1}),
#' \code{'M1'} (bivariate model \code{y ~ w1 + w2}),
#' \code{'M2'} (bivariate model \code{y ~ w1 + w3}), and
#' \code{'M3'} (full model \code{y ~ w1 + w2 + w3}). The shorthand
#' \code{'M0:3'} is also accepted for all the four models (\code{'M0'} to \code{'M3'}).
#'
#' The default (when \code{models = NULL}) depends on the argument \code{L}
#' (specifically \code{L[1]}): if \code{L = 1}, then \code{models = 'M0'},
#' otherwise, \code{models = 'M0:3'}.
#'
#' @param onlyW1 logical, should the multiplicative factors for the second and
#' third covariates be replaced by one? If \code{TRUE}, the last two covariates
#' are simply ignored when simulating the response variable.
#'
#' @param w optional design matrix of true covariate values.
#' Note that the supplied \code{n} is ignored if a non null \code{w} is provided.
#'
#' @param x optional design matrix of measurement-prone covariate values.
#'
#' @details
#' Except for \code{sigma_e.fits}, only the first value of each multiple-valued
#' argument is used.
#'
#'
#' @export sim.experiment
#' @export mbm.experiment
#'
#' @export batch.mbm
#' @aliases mbm.experiment
#'
#' @import stats
#' @import parallel
#
#
# Do NOT use \code{w3.continuous = FALSE} for \code{L < 1}: only the product of the factor corresponding to w_3 and L can be identified.
# For L = 1, allowing \code{w3.continuous = FALSE} is simply another way to have L < 1.
#
# Run a simulation experiment using 'glm.mrb'
#

batch.mbm <- function (n = c(100, 200, 300, 400, 500, 750, 1000, 5000),
                       L = c(1, 0.9, 0.75, 0.5, 0.25, 0.1),
                       beta_1 = -c(0.5, 1, 5),
                       w = NULL, # matrix of true covariates
                       CD = c('unif', 'norm', 'lnorm'),
                       mu_c = 1,   # Average of each continuous covariate
                       w3.continuous = TRUE,
                       mu_b = 0.5, # Average of the third (binary) covariate
                       sigma_22 = c(0.5, 1, 5),
                       rho = c(0, 0.3, 0.9),
                       x = NULL, # matrix of covariates with measurement errors
                       MED = c('bridge', 'norm'),
                       sigma_e2 = c(0, 0.25, 0.5),
                       beta_10 = 3,
                       beta_2 = -1,
                       beta_20 = beta_10,
                       beta_3 = -1,
                       beta_30 = beta_10,
                       onlyW1 = FALSE,
                       link = "logit",
                       Lstart = NULL,
                       criterion = c('ML', "NLS"),
                       method.optim = "BFGS",
                       slope.signs = NULL,
                       models = NULL,
                       B = 2000,
                       sigma_e.fits = 0,
                       seed = 167,
                       verbose = 3,
                       nb.clusters = 0,
                       cl = if (nb.clusters > 0) parallel::makeCluster(nb.clusters),
                       chunk.size = NULL) {
  # Ignore the supplied 'n' if w is provided
  if (!is.null(w)) {
    n <- NROW(w)
  }

  # Grid of simulatio n parameters
  Pgrid <- expand.grid (L = L,
                        beta_1 = beta_1,
                        CD = CD,
                        sigma_22 = sigma_22,
                        rho = rho,
                        MED = MED,
                        sigma_e2 = sigma_e2)

  # Set seed for parallel computing if required
  if (is.null(seed)) {
    seed <- 167
  }
  saved.kind <- RNGkind()[1]
  saved.seed <- .Random.seed
  set.seed(seed)

  if (!is.null(cl)) {
    RNGkind("L'Ecuyer-CMRG")
    parallel::clusterSetRNGStream (cl, iseed = .Random.seed)
  }


  # A routine to run over settings
  nb.settings <- NROW(Pgrid)
  kfunc <- function(k) {

    if (verbose) {
      cat(paste0('\nRunning setting ', k, ' / ', nb.settings))
    }

    combs <- Pgrid[k,]

    # For each sample size in 'n'
    outk <- lapply(n,
                   FUN = function(nk) {
                     nkdesigns <- generate.covariate.matrix (n = nk,
                                                             w = w,
                                                             CD = as.character(combs[3][[1]]),
                                                             mu_c = mu_c,
                                                             w3.continuous = w3.continuous,
                                                             mu_b = mu_b,
                                                             sigma_22 = as.numeric(combs[4]),
                                                             rho = as.numeric(combs[5]),
                                                             x = x,
                                                             MED = as.character(combs[6][[1]]),
                                                             sigma_e2 = as.numeric(combs[7]),
                                                             seed = NULL)

                     outnk <- mbm.experiment (n = nk,
                                              L = as.numeric(combs[1]),
                                              beta_1 = as.numeric(combs[2]),
                                              w = nkdesigns$w,
                                              CD = as.character(combs[3][[1]]),
                                              mu_c = mu_c,
                                              w3.continuous = w3.continuous,
                                              mu_b = mu_b,
                                              sigma_22 = as.numeric(combs[4]),
                                              rho = as.numeric(combs[5]),
                                              x = nkdesigns$x,
                                              MED = as.character(combs[6][[1]]),
                                              sigma_e2 = as.numeric(combs[7]),
                                              beta_10 = beta_10[1],
                                              beta_2 = beta_2[1],
                                              beta_20 = beta_20[1],
                                              beta_3 = beta_3[1],
                                              beta_30 = beta_30[1],
                                              onlyW1 = onlyW1[1],
                                              link = link[1],
                                              Lstart = Lstart[1],
                                              criterion = criterion[1],
                                              method.optim = method.optim[1],
                                              slope.signs = slope.signs[1],
                                              models = models,
                                              B = B[1],
                                              sigma_e.fits = sigma_e.fits,
                                              seed = NULL,
                                              verbose = verbose,
                                              cl = NULL,
                                              chunk.size = NULL)

                     return(outnk)
                   })

    names(outk) <- paste0('n=', n)

    outk$params <- combs

    return(outk)

  }

  out <- mrbglm:::matteLapply(X = 1:nb.settings,
                              FUN = kfunc,
                              cl = cl,
                              chunk.size = chunk.size)

  if (!is.null(cl)) {
    catch.conditions({
      parallel::stopCluster(cl)
    })
  }

  if (!is.null(seed)) {
    RNGkind(saved.kind)
    .Random.seed <- saved.seed
  }

  names(out) <- paste0("Setting", 1:nb.settings)

  return(out)

}

mbm.experiment <- function(n = c(100, 200, 300, 400, 500, 750, 1000, 5000),
                           L = c(1, 0.9, 0.75, 0.5, 0.25, 0.1),
                           beta_1 = -c(0.5, 1, 5),
                           w = NULL, # matrix of true covariates
                           CD = c('unif', 'norm', 'lnorm'),
                           mu_c = 1,   # Average of each continuous covariate
                           w3.continuous = TRUE,
                           mu_b = 0.5, # Average of the third (binary) covariate
                           sigma_22 = c(0.5, 1, 5),
                           rho = c(0, 0.3, 0.9),
                           x = NULL, # matrix of covariates with measurement errors
                           MED = c('bridge', 'norm'),
                           sigma_e2 = c(0, 0.25, 0.5),
                           beta_10 = 1,
                           beta_2 = -1,
                           beta_20 = beta_10,
                           beta_3 = -2,
                           beta_30 = beta_10,
                           onlyW1 = FALSE,
                           link = "logit",
                           Lstart = NULL,
                           criterion = c('ML', "NLS"),
                           method.optim = "BFGS",
                           slope.signs = NULL,
                           models = NULL,
                           B = 2000,
                           sigma_e.fits = sqrt(c(0, 0.5, 1, 2)),
                           seed = 167,
                           verbose = 3,
                           nb.clusters = 8,
                           cl = if (nb.clusters > 0) parallel::makeCluster(nb.clusters),
                           chunk.size = NULL) {
  # Saved the call
  mcall <- match.call()

  # Pick first values of arguments
  n <- n[1]
  L <- L[1]
  beta_1 <- beta_1[1]
  sigma_22 <- sigma_22[1]
  rho <- rho[1]
  CD <- CD[1]
  mu_c <- mu_c[1]
  w3.continuous <- w3.continuous[1]
  mu_b <- mu_b[1]
  sigma_e2 <- sigma_e2[1]
  MED <- MED[1]
  beta_10 <- beta_10[1]
  beta_2 <- beta_2[1]
  beta_20 <- beta_20[1]
  beta_3 <- beta_3[1]
  beta_30 <- beta_30[1]
  link <- link[1]
  stopifnot(is.logical(onlyW1))
  onlyW1 <- onlyW1[1]
  criterion <- criterion[1]
  B <- B[1]

  # Default fitting models
  if (is.null(models)) {
    models <- ifelse(L < 1, 'M0', 'M0:3')
  }
  else {
    stopifnot(all(models %in% c('M0', 'M1', 'M2', 'M3', 'M0:3')))
  }
  if ('M0:3' %in% models) {
    models <- c('M0', 'M1', 'M2', 'M3')
  }

  # Argument check
  stopifnot(n > 10)
  if (identical(CD, "lnorm"))
    stopifnot(mu_c > 0 )
  if (!w3.continuous)
    stopifnot(mu_b > 0, mu_b < 1)
  stopifnot(all(sigma_e.fits >= 0))
  stopifnot(link %in% c('logit', 'probit'))

  # Generate covariate matrices
  design.mats <- generate.covariate.matrix (n = n,
                                            w = w,
                                            CD = CD,
                                            mu_c = mu_c,
                                            w3.continuous = w3.continuous,
                                            mu_b = mu_b,
                                            sigma_22 = sigma_22,
                                            rho = rho,
                                            x = x,
                                            MED = MED,
                                            sigma_e2 = sigma_e2,
                                            seed = seed)


  # Set seed for parallel computing if required
  if (!is.null(seed)) {
    saved.kind <- RNGkind()[1]
    saved.seed <- .Random.seed
    set.seed(seed)

    if (!is.null(cl)) {
      RNGkind("L'Ecuyer-CMRG")
      parallel::clusterSetRNGStream (cl, iseed = .Random.seed)
    }
  }

  # Run B replicates of the simulation setting
  if (verbose) {
    cat(paste0("\nExperiment A with sample size n = ", NROW(design.mats$w), "."))
  }
  out <- mrbglm:::matteLapply (X = 1:B,
                               FUN = run.mbmsim.k,
                               design.mat = design.mats,
                               models = models,
                               w3.continuous = w3.continuous,
                               beta = c(beta_10, beta_1,
                                        beta_20, beta_2,
                                        if (w3.continuous) beta_30, beta_3),
                               delta = qlogis(L),
                               Lstart = Lstart,
                               onlyW1 = onlyW1,
                               link = link,
                               criterion = criterion,
                               method.optim = method.optim,
                               slope.signs = slope.signs,
                               verbose = max(0, verbose - 1),
                               cl = cl,
                               chunk.size = chunk.size)

  if (!is.null(cl)) {
    catch.conditions({
      parallel::stopCluster(cl)
    })
  }

  if (!is.null(seed)) {
    RNGkind(saved.kind)
    .Random.seed <- saved.seed
  }

  names(out) <- paste0("k", 1:B)
  out <- list(main = out)

  # Save call, covariate data
  out$design.mats <- design.mats
  out$call <- mcall

  # Set class
  class(out) <- "mbm.exp"

  # Compute performance measures
  # out$performance <- get.performance (out)

  return(out)

}

