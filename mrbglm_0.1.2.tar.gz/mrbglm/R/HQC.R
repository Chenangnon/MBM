
#' @export HQC.default
#' @importFrom stats AIC
#

HQC.default <- function(object, ...) {
  objects <- list(object, ...)

  ## Find the number of observations
  nobs <- sapply(objects, FUN = nnobs)

  if (all(nobs == nobs[1])) {
    ## Use the AIC function (safest route)
    out <- stats::AIC(object, ..., k = 2 * log(log(nobs[1])))

    if (length(objects) > 1) {
      Call <- match.call()
      rownames(out) <- make.unique(as.character(Call[-1L])[1:length(objects)])
      colnames(out) <- c('df', 'HQC')
    }

  }
  else {
    ## Case where fitted models are based on different number of observations
    warning('\n  models are not all fitted to the same number of observations')
    #warning('Different number of observations detected. \nComparing HQC for models fitted on different datasets is meaningless!')

    out <- sapply(objects, FUN = hqc.default)
    if (length(objects) > 1) {
      out <- data.frame(df = out[1,], HQC = out[2,])
    }

    ## Name the outputs
    if (length(objects) > 1) {
      Call <- match.call()
      rownames(out) <- make.unique(as.character(Call[-1L])[1:length(objects)])
      colnames(out) <- c('df', 'HQC')
    }
    else {
      out <- out[2]
    }

  }

  return (out)

}

nnobs <- function(object) {
  ## Extract sample size (number of observations)
  n <- object$nobs

  ## Try the generic 'nobs'
  if (is.null(n))
    n <- nobs(object)

  if (is.null(n)) {
    return(NA)
  }

  return(n)
}

hqc.default <- function(object) {
  ## Extract the log-likelihood of the fitted model
  LL <- logLik(object)

  ## If NULL log-likelihood, return NA
  if (is.null(LL)) {
    return(c(NA, NA))
  }

  ## Extract sample size
  n <- attr(LL, 'nobs')

  ## Try other possibilities if NULL
  if (is.null(n))
    n <- object$nobs
  if (is.null(n))
    n <- nobs(object)

  ## Number of parameters in the fitted model
  df <- attr(LL, 'df')

  ## Try other possibilities if NULL
  if (is.null(df)) {
    df <- length(unlist(coef(object)))
  }
  if (is.null(df)) {
    return(c(NA, NA))
  }

  hqc <- - 2 * LL + 2 * df * log(log(n))

  return (c(df, hqc))
}

#'
#' Hannan–Quinn Information Criterion
#'
#' Generic function calculating the Hannan–Quinn Information Criterion for one or
#' several fitted model objects for which a log-likelihood value can be obtained.
#'
#' @details
#' Similar to the \link[stats]{AIC} function, \code{HQC} calculates a criterion
#' according to the formula \code{-2log-likelihood} \eqn{+} \eqn{2log(log(N)) \times n_{par}}
#' where \eqn{N} represents the number of observations and \eqn{n_{par}} is the
#' number of parameters in the fitted model \insertCite{hannan1979determination}{mrbglm}.
#'
#' \code{HQC} is defined as \code{AIC(object, ..., k = 2 * log(log(nobs(object))))}.
#' This requires the number of observations to be known: the default method looks first
#' for a \code{'nobs'} attribute on the return value from the \link[stats]{logLik} method,
#' then looks for a \code{'nobs'} attribute on the supplied \code{object},
#' and finally tries the \link[stats]{nobs} generic, and if neither succeed
#' returns \code{HQC} as \code{NA}.
#'
#' This is a generic function (\code{S3}). As for \link[stats]{AIC},
#' methods should however be defined for
#' the log-likelihood function \link[stats]{logLik} rather than this function:
#' the action of the default method is to call \link[stats]{logLik} on all the
#' supplied objects and assemble the results.
#'
#' See \link[stats]{AIC} for some theoretical details and potential problems
#' related to \link[stats]{logLik} not returning the value at the MLE in
#' several common cases.
#'
#' @return
#' If just one object is provided, a numeric value with the corresponding HQC.
#'
#' If multiple objects are provided, a \code{data.frame} with rows corresponding
#' to the objects and columns representing the number of parameters in the model
#' (\code{df}) and the HQC.
#'
#' @export HQC
#' @aliases HQC.default
#'
#' @references
#' \insertAllCited{}
#'
#' @examples
#' require(mrbglm)
#'
#' # Simulate some data
#' set.seed(167)
#' mrbdata = sim.mrb (beta = c(2, -2),
#'                    x = cbind(x1 = runif(1000, min = -10, max = 5),
#'                              x2 = runif(1000, min = -5, max = 10)),
#'                    delta = qlogis(.66))$data
#'
#' # Fit univariate and bivariate MRB models
#' MRBfit1 = glm.mrb (y ~ x1, data = mrbdata)
#'
#' MRBfit2 = glm.mrb (y ~ x1 + x2, data = mrbdata)
#'
#' # Get HQC
#' HQC(MRBfit1)
#' HQC(MRBfit1, MRBfit2)
#'
setGeneric(name = 'HQC',
           def = HQC.default)
