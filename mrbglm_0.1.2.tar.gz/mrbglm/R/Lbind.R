
lbind <- function(..., FUN = c, unique = TRUE,
         keep.element.names = TRUE,
         make.vector.names = TRUE,
         verbose = TRUE) {
  FUN <- match.fun(FUN)
  if (verbose)
    result <- mapply (function(...) FUN(...), ..., SIMPLIFY = FALSE)
  else
    result <- catch.conditions(mapply (function(...) FUN(...), ..., SIMPLIFY = FALSE))$value
  if (!missing(FUN)) {
    return(result)
  }

  if (unique) {
    if (keep.element.names) { # If the name attributed have to be kept
      result <- lapply(result, FUN = function(resj) {
        dups <- duplicated(resj)
        if (any(dups))
          resj <- resj[!dups] # Remove duplicates, if any.
        resj
      })
    }
    else { # If name attributed can be ignored, use 'unique' which does not preserve name attributes.
      result <- lapply(result, unique)
    }
  }
  if (make.vector.names) {
    INargs <- list(...)
    largs <- sapply(INargs, FUN = length)
    names(result) <- names(INargs[[which.max(largs)[1]]])
  }
  return(result)
}
