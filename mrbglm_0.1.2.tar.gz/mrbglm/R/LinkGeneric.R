#
#
link <- function(object, ...) {
  link.mrbglm (object, ...)
}

setGeneric(name = "link")

link.mrbglm <- function (object, ...)
  object$link

link.memrb.fit <- function (object, ...)
  object$link
