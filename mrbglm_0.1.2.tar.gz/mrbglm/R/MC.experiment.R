# Routine ti run Experiment A  or B
run.mbmsim.k <- function (k,
                          design.mat,
                          models,
                          w3.continuous,
                          beta,
                          delta, Lstart,
                          onlyW1, link, criterion,
                          method.optim,
                          slope.signs,
                          verbose) {
  if (verbose) {
    cat(paste0("\n\n  # replicate k = ", k, " \n"))
  }

  # Initialize output object
  out <- list(MBMdata = list(),
              SBMdata = list())

  if (verbose) {
    cat("      * Generating MBM data ... ")
  }

  # Sample data
  MBMdata <- sim.mrb (x = design.mat$w,
                      intercepts = c(TRUE, TRUE, w3.continuous),
                      beta = beta,
                      delta = delta,
                      link = link)$data
  if (onlyW1) {
    MBMdata$y <- sim.mrb (x = design.mat$w[,1, drop = FALSE],
                          intercepts = TRUE,
                          beta = beta[1:2],
                          delta = delta,
                          link = link)$data$y
  }

  # Replace covariates by measurement error prone-observations
  MBMdata$w1 <- design.mat$x[,1]
  MBMdata$w2 <- design.mat$x[,2]
  MBMdata$w3 <- design.mat$x[,3]

  if (verbose) {
    cat("\n      * Fitting SBMs ... ")
  }

  out$MBMdata$SBMfits <- SBMfitting (MBMdata, link = link, models = models,
                                     verbose = max(0, verbose - 1))

  if (verbose) {
    cat("\n      * Fitting MBMs ... ")
  }
  out$MBMdata$MBMfits <- MBMfitting (MBMdata,
                                     models = models,
                                     w3.continuous = w3.continuous,
                                     link = link, verbose = max(0, verbose - 1),
                                     Lstart = Lstart, criterion = criterion,
                                     method.optim = method.optim,
                                     slope.signs = slope.signs)

  out$MBMdata$y <- MBMdata$y
  if (delta == Inf) {
    if (verbose) {
      cat("\n      * Generating SBM data ... ")
    }

    # Sample data
    SBMdata <- sim.mib (x = design.mat$w,
                        beta = beta[c(1, 2, 4, length(beta))],
                        delta = delta,
                        link = link)$data

    # Replace covariates by measurement error prone-observations
    SBMdata$w1 <- design.mat$x[,1]
    SBMdata$w2 <- design.mat$x[,2]
    SBMdata$w3 <- design.mat$x[,3]

    if (verbose) {
      cat("\n      * Fitting SBMs ... ")
    }

    out$SBMdata$SBMfits <- SBMfitting (SBMdata,
                                       link = link, models = models,
                                       verbose = max(0, verbose - 1))

    if (verbose) {
      cat("\n      * Fitting MBMs ... ")
    }

    out$SBMdata$MBMfits <- MBMfitting (SBMdata,
                                       models = models,
                                       w3.continuous = w3.continuous,
                                       link = link, verbose = max(0, verbose - 1),
                                       Lstart = Lstart, criterion = criterion,
                                       method.optim = method.optim,
                                       slope.signs = slope.signs)

    out$SBMdata$y <- SBMdata$y
  }

  if (verbose) {
    cat("\n ")
  }

  return(out)
}

# Routine to fit SBM models M0 to M3
SBMfitting <- function (mdata, models, link, verbose) {
  SBMfits <- list()

  if ("M0" %in% models) {
    if (verbose) {
      cat("\n        - M0 specification: y ~ w1 ... ")
    }
    rtime <- system.time({
      SBMfits$M0 <- catch.conditions({
        glm(formula = y ~ w1,
            family = binomial(link = link),
            data = mdata)
      })$value
    })

    SBMfits$M0 <- as.list(SBMfits$M0)
    SBMfits$M0$time <- rtime
  }

  if ("M1" %in% models) {
    if (verbose) {
      cat("\n        - M1 specification: y ~ w1 + w2 ... ")
    }

    rtime <- system.time({
      SBMfits$M1 <- catch.conditions({
        glm(formula = y ~ w1 + w2,
            family = binomial(link = link),
            data = mdata)
      })$value
    })

    SBMfits$M1 <- as.list(SBMfits$M1)
    SBMfits$M1$time <- rtime
  }

  if ("M2" %in% models) {
    if (verbose) {
      cat("\n        - M2 specification: y ~ w1 + w3 ... ")
    }

    rtime <- system.time({
      SBMfits$M2 <- catch.conditions({
        glm(formula = y ~ w1 + w3,
            family = binomial(link = link),
            data = mdata)
      })$value
    })

    SBMfits$M2 <- as.list(SBMfits$M2)
    SBMfits$M2$time <- rtime
  }

  if ("M3" %in% models) {
    if (verbose) {
      cat("\n        - M3 specification: y ~ w1 + w2 + w3 ... ")
    }

    rtime <- system.time({
      SBMfits$M3 <- catch.conditions({
        glm(formula = y ~ w1 + w2 + w3,
            family = binomial(link = link),
            data = mdata)
      })$value
    })

    SBMfits$M3 <- as.list(SBMfits$M3)
    SBMfits$M3$time <- rtime
  }

  return(SBMfits)
}

# Routine to fit MBM models M0 to M3
MBMfitting <- function (mdata,
                        models,
                        w3.continuous,
                        link, verbose,
                        Lstart, criterion, method.optim,
                        slope.signs, sigma_e.fits = 0) {
  MBMfits <- list()

  if ("M0" %in% models) {
    if (verbose) {
      cat("\n        - M0 specification: y ~ w1 ... ")
    }

    M0fun <- function (Lstarti) {
      rtime <- system.time({
        M0 <- catch.conditions({
          mrbglm::glm.mrb (formula = y ~ w1,
                           link = link,
                           maxp.formula = ~1,
                           start = NULL,
                           Lstart = Lstarti,
                           control = control.mrb(criterion = criterion,
                                                 method = method.optim,
                                                 slope.signs = slope.signs),
                           data = mdata)
        })$value
      })
      M0 <- as.list(M0)
      M0$time <- rtime

      return(M0)

    }

    M0.21 <- lapply(seq(0.05, 0.99, by = 0.05), # length.out = 20
                    FUN = M0fun)
    M0.21[[length(M0.21) + 1]] <- M0fun(NULL)

    rdev <- sapply(M0.21, FUN = function(x) {
      if(!is.list(x))
        return(NA)
      res <- x$deviance

      if (is.null(res))
        return(NA)

      return(res)
    })

    MBMfits$M0 <- M0.21[[which.min(rdev)]]

  }

  if ("M1" %in% models) {
    if (verbose) {
      cat("\n        - M1 specification: y ~ w1 + w2 ... ")
    }

    rtime <- system.time({
      MBMfits$M1 <- catch.conditions({
        mrbglm::glm.mrb (formula = y ~ w1 + w2,
                         link = link,
                         intercepts = c(TRUE, TRUE),
                         maxp.formula = ~1,
                         start = NULL,
                         Lstart = Lstart,
                         control = control.mrb(criterion = criterion,
                                               method = method.optim,
                                               slope.signs = slope.signs),
                         data = mdata)
      })$value
    })
    MBMfits$M1$time <- rtime
  }

  if ("M2" %in% models) {
    if (verbose) {
      cat("\n        - M2 specification: y ~ w1 + w3 ... ")
    }

    rtime <- system.time({
      MBMfits$M2 <- catch.conditions({
        mrbglm::glm.mrb (formula = y ~ w1 + w3,
                         link = link,
                         intercepts = c(TRUE, w3.continuous),
                         maxp.formula = ~1,
                         start = NULL,
                         Lstart = Lstart,
                         control = control.mrb(criterion = criterion,
                                               method = method.optim,
                                               slope.signs = slope.signs),
                         data = mdata)
      })$value
    })
    MBMfits$M2$time <- rtime
  }

  if ("M3" %in% models) {
    if (verbose) {
      cat("\n        - M3 specification: y ~ w1 + w2 + w3 ... ")
    }

    rtime <- system.time({
      MBMfits$M3 <- catch.conditions({
        mrbglm::glm.mrb (formula = y ~ w1 + w2 + w3,
                         link = link,
                         intercepts = c(TRUE, TRUE, w3.continuous),
                         maxp.formula = ~1,
                         start = NULL,
                         Lstart = Lstart,
                         control = control.mrb(criterion = criterion,
                                               method = method.optim,
                                               slope.signs = slope.signs),
                         data = mdata)
      })$value
    })
    MBMfits$M3 <- as.list(MBMfits$M3)
    MBMfits$M3$time <- rtime

    # Same run but with L fixed to one
    rtime <- system.time({
      MBMfits$M3$WithfixL <- catch.conditions({
        mrbglm::glm.mrb (formula = y ~ w1 + w2 + w3,
                         link = link,
                         intercepts = c(TRUE, TRUE, w3.continuous),
                         maxp.formula = ~-1,
                         start = NULL,
                         Lstart = 1,
                         control = control.mrb(criterion = criterion,
                                               method = method.optim,
                                               slope.signs = slope.signs),
                         data = mdata)
      })$value
    })
    MBMfits$M3$WithfixL <- as.list(MBMfits$M3$WithfixL)
    MBMfits$M3$WithfixL$time <- rtime
  }

  if (is.null(sigma_e.fits))
    sigma_e.fits <- 0

  if (all(sigma_e.fits == 0)) {
    return(MBMfits)
  }

  ### Add codes for fitting models accounting for measurement errors


  return(MBMfits)

}

# Routine for Experiment B
run.mbmsimB.k <- function (k,
                           design.mat,
                           beta,
                           delta, Lstart,
                           link, criterion,
                           method.optim,
                           return.fits, fixL,
                           sigma_e.fits = sigma_e.fits,
                           verbose) {
  if (verbose) {
    cat(paste0("\nExperiment B with sample size n = ", NROW(design.mat), ". \n"))

    cat(paste0("\n  * replicate k = ", k, " \n"))

    cat("\n      - Generating MBM data ... ")
  }

  MBMdata <- sim.mrb (x = design.mat,
                      intercepts = c(TRUE, TRUE, FALSE),
                      beta = beta,
                      delta = delta,
                      link = link)

  # Initialize output object
  out <- list(MBMdata = list(MBMfits = list(),
                             SBMfits = list()),
              SBMdata = list(MBMfits = list(),
                             SBMfits = list()))

  formula0 <- y ~ w1 + w2 + w3
  formula1 <- y ~ w1 + w2
  formula2 <- y ~ w1 + w3
  formula3 <- y ~ w1

  if (verbose) {
    cat("\n      - Fitting SBMs ... ")
    cat("\n        - M0 specification: y ~ w1 + w2 + w3 ... ")
  }

  out$MBMdata$SBMfits$M0 <- glm(formula = formula0,
                                family = binomial(link = link),
                                data = MBMdata)

  if (verbose) {
    cat("\n        - M1 specification: y ~ w1 + w2 ... ")
  }

  out$MBMdata$SBMfits$M1 <- glm(formula = formula1,
                                family = binomial(link = link),
                                data = MBMdata)

  if (verbose) {
    cat("\n        - M2 specification: y ~ w1 + w3 ... ")
  }

  out$MBMdata$SBMfits$M2 <- glm(formula = formula2,
                                family = binomial(link = link),
                                data = MBMdata)

  if (verbose) {
    cat("\n        - M3 specification: y ~ w1 ... ")
  }

  out$MBMdata$SBMfits$M3 <- glm(formula = formula3,
                                family = binomial(link = link),
                                data = MBMdata)

  if (verbose) {
    cat("\n      - Fitting MBMs ... ")
    cat("\n        - M0 specifications ... ")
  }

  # Run all specifications with no measurement error (ME), to be used to provide starting values when there are MEs
  Msigma_e0 <- list()
  rtime <- system.time({
    Msigma_e0$M0 = mrbglm::glm.mrb (formula = formula0,
                                    link = link,
                                    maxp.formula = ~1,
                                    start = NULL,
                                    Lstart = Lstart,
                                    data = datae)
  })
  Msigma_e0$M0$time <- rtime


  rtime <- system.time({
    Msigma_e0$M1 = mrbglm::glm.mrb (formula = formula1,
                                    link = link,
                                    maxp.formula = ~1,
                                    start = NULL,
                                    Lstart = Lstart,
                                    data = datae)
  })
  Msigma_e0$M1$time <- rtime

  rtime <- system.time({
    Msigma_e0$M2 = mrbglm::glm.mrb (formula = formula2,
                                    link = link,
                                    maxp.formula = ~1,
                                    start = NULL,
                                    Lstart = Lstart,
                                    data = datae)
  })
  Msigma_e0$M2$time <- rtime

  rtime <- system.time({
    Msigma_e0$M3 = mrbglm::glm.mrb (formula = formula3,
                                    link = link,
                                    maxp.formula = ~1,
                                    start = NULL,
                                    Lstart = Lstart,
                                    data = datae)
  })
  Msigma_e0$M3$time <- rtime

  out$MBMdata$MBMfits$M0 <- lapply(sigma_e.fits,
                                   FUN = function (sigma_e) {

                                     if (sigma_e == 0)
                                       return(Msigma_e0$M0)

                                     datae <- MBMdata
                                     datae$sigma_e1 <- sigma_e
                                     datae$sigma_e2 <- sigma_e
                                     rtime <- system.time({
                                       res <- mrbglm::glm.mrb (formula = formula0,
                                                               link = link,
                                                               x.with.me.offsets = if (sigma_e > 0) c(TRUE, TRUE, FALSE),
                                                               me.offsets = if (sigma_e > 0) ~ sigma_e1 + sigma_e2 else ~-1,
                                                               maxp.formula = ~1,
                                                               start = Msigma_e0$M0$coefficients,
                                                               Lstart = Msigma_e0$M0$L.values[1],
                                                               data = datae)
                                     })
                                     res$time <- rtime

                                     return(res)
                                   })

  if (verbose) {
    cat("\n        - M1 specifications ... ")
  }
  out$MBMdata$MBMfits$M1 <- lapply(sigma_e.fits,
                                   FUN = function (sigma_e) {

                                     if (sigma_e == 0)
                                       return(Msigma_e0$M1)

                                     datae <- MBMdata
                                     datae$sigma_e1 <- sigma_e
                                     datae$sigma_e2 <- sigma_e
                                     rtime <- system.time({
                                       res <- mrbglm::glm.mrb (formula = formula1,
                                                               link = link,
                                                               x.with.me.offsets = if (sigma_e > 0) c(TRUE, TRUE),
                                                               me.offsets = if (sigma_e > 0) ~ sigma_e1 + sigma_e2 else ~-1,
                                                               maxp.formula = ~1,
                                                               start = Msigma_e0$M1$coefficients,
                                                               Lstart = Msigma_e0$M1$L.values[1],
                                                               data = datae)
                                     })
                                     res$time <- rtime

                                     return(res)
                                   })

  if (verbose) {
    cat("\n        - M2 specifications ... ")
  }
  out$MBMdata$MBMfits$M2 <- lapply(sigma_e.fits,
                                   FUN = function (sigma_e) {

                                     if (sigma_e == 0)
                                       return(Msigma_e0$M2)

                                     datae <- MBMdata
                                     datae$sigma_e1 <- sigma_e
                                     rtime <- system.time({
                                       res <- mrbglm::glm.mrb (formula = formula2,
                                                               link = link,
                                                               x.with.me.offsets = if (sigma_e > 0) c(TRUE, FALSE),
                                                               me.offsets = if (sigma_e > 0) ~ sigma_e1 else ~-1,
                                                               maxp.formula = ~1,
                                                               start = Msigma_e0$M2$coefficients,
                                                               Lstart = Msigma_e0$M2$L.values[1],
                                                               data = datae)
                                     })
                                     res$time <- rtime

                                     return(res)
                                   })

  if (verbose) {
    cat("\n        - M3 specifications ... ")
  }
  out$MBMdata$MBMfits$M3 <- lapply(sigma_e.fits,
                                   FUN = function (sigma_e) {

                                     if (sigma_e == 0)
                                       return(Msigma_e0$M3)

                                     datae <- MBMdata
                                     datae$sigma_e1 <- sigma_e
                                     rtime <- system.time({
                                       res <- mrbglm::glm.mrb (formula = formula3,
                                                               link = link,
                                                               x.with.me.offsets = if (sigma_e > 0) TRUE,
                                                               me.offsets = if (sigma_e > 0) ~ sigma_e1 else ~-1,
                                                               maxp.formula = ~1,
                                                               start = Msigma_e0$M3$coefficients,
                                                               Lstart = Msigma_e0$M3$L.values[1],
                                                               data = datae)
                                     })
                                     res$time <- rtime

                                     return(res)
                                   })


  SBMdata <- NULL
  if (delta == Inf) {
    if (verbose) {
      cat("\n      - SBM data ... ")
    }
    SBMdata <- sim.mib (x = design.mat,
                        beta = beta[c(1, 2, 4, 6)],
                        delta = delta,
                        link = link)


  }


  out$y <- MBMdata$y
}
