
NagelkerkeR2 <- function (object, ..., adjust.size = FALSE) {

  out <- rsquared.default (object = object, ..., method = 'Nagelkerke', adjust.size = adjust.size)
  if (NROW(out) > 1) {
    Call <- match.call()
    rownames(out) <- as.character(Call[-1L])[1:NROW(out)]
  }
  return(out)
}

NagelkerkeR20 <- function (object, ..., adjust.size = FALSE) {

  # List of classes with a method
  availclasses <- c("glm", "mrbglm", 'mibglm')

  # Argument adjust.size: coerce to be logical
  adjust.size <- as.logical(adjust.size[1])

  # List of additional object, if any
  objects <- list(...)

  if (length(objects) == 0) { # If no additional object provided through  ...

    if (any(class(object) %in% availclasses)) { # If object is of a class with an available method

      if (inherits(object, "glm")) {
        n <- nrow(object$model)
        rank <- object$df.null - object$df.residual + 1
      }
      else {
        n <- object$nobs
        rank <- object$rank
      }

      R2 <- get.NR2VAL (object = object, n = n, rank = rank, adjust.size = adjust.size)

      RVAL <- structure(R2, df = rank, N = n)

      return(RVAL)
    }
    else {
      if (is.list(object)) {
        nm <- names(object)

        clobject <- sapply(object,
                           FUN = function(x) any(class(x) %in% availclasses))
        if (all(!clobject)) {
          cat("\n classes with an 'R2' method are: \n")
          cat(availclasses)
          cat(" \n")
          stop("object(s) of a class not handled")
        }
        res <- matrix(NA, nrow = length(clobject), ncol = 3)

        RVAL <- sapply(object[clobject],
                       FUN = function(objectj) {
                         if (inherits(objectj, "glm")) {
                           nj <- nrow(objectj$model)
                           rankj <- objectj$df.null - objectj$df.residual + 1
                         }
                         else {
                           nj <- objectj$nobs
                           rankj <- objectj$rank
                         }

                         R2j <- get.NR2VAL (object = objectj, n = nj, rank = rankj, adjust.size = adjust.size)

                         return(c(N = nj, df = rankj, R2 = R2j))
                       })
        res[clobject,] <- if (sum(clobject) > 0) t(RVAL) else RVAL
        RVAL <- data.frame(N = res[,1], df = res[,2], R2 = res[,3])
        if (!is.null(nm))
          row.names(RVAL) <- nm

        return(RVAL)
      }

      stop(paste0(" object of a class not handled. Available classes are: ",
                  paste(availclasses, collapse = ', '), '.'))
    }
  }
  else {
    objects <- list(object, ...)
    Call <- match.call()
    names(objects) <- as.character(Call[-1L])[1:length(objects)]
    return(NagelkerkeR2(objects, adjust.size = adjust.size))
  }
}

get.NR2VAL <- function (object, n, rank, adjust.size) {
  R2 <- (1 - exp((object$deviance - object$null.deviance)/n))/(1 - exp(-object$null.deviance/n))
  if (adjust.size)
    R2 <- 1 - (1 - R2) * (n - 1) / (n - rank)

  return(R2)
}

