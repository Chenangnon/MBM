#' Anova Tables
#'
#' Compute analysis of deviance tables for one or more fitted model objects.
#'
#' @aliases anode.mrbglm
#'
# @exportS3Method anova mrbglm
# @export anova.mrbglm
# @export anode.mrbglm
#'
#' @param object an object of class \code{mrbglm}.
#'
#' @param dispersion dispersion
#'
#' @param test test
#'
#' @param ... additional object of the same class as \code{object}.
#'
#' @return returns an analysis-of-deviance table, which is an object of class
#' \code{anova}.
#'
#' When given a single argument it produces a table which tests whether the
#' model terms are significant. When given a sequence of objects, \code{anova}
#' tests the models against one another in the order specified.
#'
#'

anova.mrbglm <- function (object, ..., dispersion = NULL, test = NULL) {
  dotargs <- list(...)
  named <- if (is.null(names(dotargs)))
    rep_len(FALSE, length(dotargs))
  else (names(dotargs) != "")
  if (any(named))
    warning("the following arguments to 'anova.mrbglm' are invalid and dropped: ",
            paste(deparse(dotargs[named]), collapse = ", "))
  dotargs <- dotargs[!named]
  is.mrbglm <- vapply(dotargs, function(x) inherits(x, "mrbglm"),
                   NA)
  dotargs <- dotargs[is.mrbglm]


  stop("not ready!")


  if (length(dotargs))
    return(anova.mrbglmlist(c(list(object), dotargs), dispersion = dispersion,
                         test = test))


  doscore <- !is.null(test) && test == "Rao"
  varlist <- attr(object$terms, "variables")
  x <- if (n <- match("x", names(object), 0L))
    object[[n]]
  else model.matrix(object)
  varseq <- attr(x, "assign")
  nvars <- max(0, varseq)
  resdev <- resdf <- NULL
  if (doscore) {
    score <- numeric(nvars)
    method <- object$method
    y <- object$y
    fit <- eval(call(if (is.function(method)) "method" else method,
                     x = x[, varseq == 0, drop = FALSE], y = y, weights = object$prior.weights,
                     start = object$start, offset = object$offset, family = object$family,
                     control = object$control))
    r <- fit$residuals
    w <- fit$weights
    icpt <- attr(object$terms, "intercept")
  }
  if (nvars > 1 || doscore) {
    method <- object$method
    y <- object$y
    if (is.null(y)) {
      mu.eta <- object$family$mu.eta
      eta <- object$linear.predictors
      y <- object$fitted.values + object$residuals * mu.eta(eta)
    }
    for (i in seq_len(max(nvars - 1L, 0))) {
      fit <- eval(call(if (is.function(method)) "method" else method,
                       x = x[, varseq <= i, drop = FALSE], y = y, weights = object$prior.weights,
                       start = object$start, offset = object$offset,
                       family = object$family, control = object$control))
      if (doscore) {
        zz <- eval(call(if (is.function(method)) "method" else method,
                        x = x[, varseq <= i, drop = FALSE], y = r,
                        weights = w, intercept = icpt))
        score[i] <- zz$null.deviance - zz$deviance
        r <- fit$residuals
        w <- fit$weights
      }
      resdev <- c(resdev, fit$deviance)
      resdf <- c(resdf, fit$df.residual)
    }
    if (doscore) {
      zz <- eval(call(if (is.function(method)) "method" else method,
                      x = x, y = r, weights = w, intercept = icpt))
      score[nvars] <- zz$null.deviance - zz$deviance
    }
  }
  resdf <- c(object$df.null, resdf, object$df.residual)
  resdev <- c(object$null.deviance, resdev, object$deviance)
  table <- data.frame(c(NA, -diff(resdf)), c(NA, pmax(0, -diff(resdev))),
                      resdf, resdev)
  tl <- attr(object$terms, "term.labels")
  if (length(tl) == 0L)
    table <- table[1, , drop = FALSE]
  dimnames(table) <- list(c("NULL", tl), c("Df", "Deviance",
                                           "Resid. Df", "Resid. Dev"))
  if (doscore)
    table <- cbind(table, Rao = c(NA, score))
  title <- paste0("Analysis of Deviance Table", "\n\nModel: ",
                  object$family$family, ", link: ", object$family$link,
                  "\n\nResponse: ", as.character(varlist[-1L])[1L], "\n\nTerms added sequentially (first to last)\n\n")
  df.dispersion <- Inf
  if (is.null(dispersion)) {
    dispersion <- summary(object, dispersion = dispersion)$dispersion
    df.dispersion <- if (dispersion == 1)
      Inf
    else object$df.residual
  }
  if (!is.null(test)) {
    if (test == "F" && df.dispersion == Inf) {
      fam <- object$family$family
      if (fam == "binomial" || fam == "poisson")
        warning(gettextf("using F test with a '%s' family is inappropriate",
                         fam), domain = NA)
      else warning("using F test with a fixed dispersion is inappropriate")
    }
    table <- stat.anova(table = table, test = test, scale = dispersion,
                        df.scale = df.dispersion, n = NROW(x))
  }
  structure(table, heading = title, class = c("anova", "data.frame"))
}

anode.mrbglm <- anova.mrbglm


anova.mrbglmlist <- anova.mrbglm
