#' Run Simulation Experiment \code{B}
#'
#' This function runs a simulation experiment on Multistage Binomial Model based Regression
#'
#' @param n numeric vector of sample sizes.
#' Note that the supplied \code{n} is ignored if a non null \code{w} is
#' provided: only one sample size is then considered, namely the number of
#' rows of \code{w}.
#'
#' @param verbose numeric integer, if positive, information is printed during the running of step.
#' Larger values may give more detailed information.
#'
#' @param models character vector, specifies desired fitting models.
#' One or many of \code{'M0'} (univariate model \code{y ~ w1}),
#' \code{'M1'} (bivariate model \code{y ~ w1 + w2}),
#' \code{'M2'} (bivariate model \code{y ~ w1 + w3}), and
#' \code{'M3'} (full model \code{y ~ w1 + w2 + w3}). The shorthand
#' \code{'M0:3'} is also accepted for all the four models (\code{'M0'} to \code{'M3'}).
#'
#' The default (when \code{models = NULL}) depends on the argument \code{L}
#' (specifically \code{L[1]}): if \code{L = 1}, then \code{models = 'M0'},
#' otherwise, \code{models = 'M0:3'}.
#'
#' @param w optional design matrix of true covariate values.
#' Note that the supplied \code{n} is ignored if a non null \code{w} is provided.
#'
#' @param x optional design matrix of measurement-prone covariate values.
#'
#' @details
#' Except for \code{sigma_e.fits}, only the first value of each multiple-valued
#' argument is used.
#'
#'
# @export mbm.expB
#'
#' @export batch.expB
# @aliases mbm.expB
#'
#' @import stats
#' @import parallel
#
#
# Do NOT use \code{w3.continuous = FALSE} for \code{L < 1}: only the product of the factor corresponding to w_3 and L can be identified.
# For L = 1, allowing \code{w3.continuous = FALSE} is simply another way to have L < 1.
#
# Run a simulation experiment using 'glm.mrb'
#

# Sample the variance of ME from the uniform distribution on (0, 2*sigma_e2)
batch.expB <- function (n = c(100, 200, 300, 500, 800, 1000),
                        L = c(1, 0.9, 0.75, 0.5, 0.25, 0.1),
                        beta_1 = -c(0.5, 1, 5),
                        CD = c('norm', 'lnorm', 'unif'),
                        mu_w1 = 1,
                        MED = c('bridge', 'norm'),
                        sigma_e2 = c(0, 0.25, 0.5),
                        beta_0 = 3,
                        link = "logit",
                        Lstart = NULL,
                        n.restart = 0,
                        criterion = c('ML', "NLS"),
                        method.optim = "BFGS",
                        slope.signs = NULL,
                        fixL = FALSE,
                        B = 2000,
                        sigma_e.fits = 0,
                        seed = 167,
                        verbose = 2,
                        nb.clusters = 0,
                        cl = if (nb.clusters > 0) parallel::makeCluster(nb.clusters),
                        chunk.size = NULL) {


}
