#' Bootstrap a Model Fit
#'
#' Bootstrapping a model fit object of a class with a \code{boot} method.
#'
#' @param object R object of a class with a \code{boot} method.
#'
#' @param ... additional argument to \code{boot}. The (default) method for a \code{mrbglm} class object accepts the
#' following arguments:
#'
#' \itemize{
#' \item{\code{nb.resamples}}{: positive integer giving the number of bootstrap resamples
#' to draw, or \code{NULL} which corresponds to jackknife approximation
#' (see 'Details').}
#' \item{\code{boot.type}}{: character, one of \code{'ordinary'} (usual non-parametric
#' bootstrap based on resampling the original data used to fit the model) or
#' \code{parametric} which resample the response variable from a binomial
#' distribution (holding covariates fixed to their values in the original data
#' used to fit the model).}
#' \item{\code{simple}}{: logical, should resamples (observation indices) be
#' separately drawn for each bootstrap replication? This "is slower but uses
#' less memory" (see \link[boot]{boot}). Defaults to \code{simple = FALSE} which
#' creates an index array once for all resamples. Only used when
#' \code{boot.type = ordinary}.}
#' \item{\code{parallel,ncpus,cl}}{: arguments passed to \link[boot]{boot}, may be
#' specified to allow parallel computations (based on R package \code{parallel}
#' or \code{snow}) which can be faster on multicore plateformes (see
#' \link[boot]{boot}).}
#' }
#'
#' @details
#' The function \code{boot} is generic and methods can be written for
#' \code{object}s of a specific class, with particular additional arguments
#' (\code{...}).
#'
#' Only objects of class \code{mrbglm} (as returned by \link{glm.mrb}) currently
#' have a method (the default) in the package \code{mrbglm}. Methods will be
#' added for objects of classes \code{glm}/\code{glm.fit} for comparing MRB
#' models (see \link{sim.mrb}) with the common binomial GLM in simulation
#' settings/performance studies.
#'
#' ### Bootstrap a Multiplicative Risk Binomial Regression Model Fit ###
#'
#' The default method performs (for an object of class \code{mbrglm}) ordinary
#' bootstrapping based on \code{nb.resamples} resamples, each of the same size
#' \code{nobs} of the original dataset. When \code{nb.resamples} is set to
#' \code{nb.resamples = NULL}, jackknife estimates are computed: one observation
#' is deleted from the original dateset at a time and the model parameters are
#' estimated using the remaining \code{nobs - 1} observations.
#'
# @exportS3Method boot mrbglm
#' @export boot
#' @exportMethod boot
#'
#' @import boot
#' @import methods
#'
#' @return An object of class \code{boot} defined from package
#' \code{boot}. See \link[boot]{boot} for details.
#'
#

boot <- function(object, ...) {
  boot.mrbglm (object, ...)
}

setGeneric(name = "boot")
