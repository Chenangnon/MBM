# Bootstrap a Multiplicative Risk Binomial Regression Model Fit
boot.mrbglm <- function (object, nb.resamples = 999,
                         boot.type = "ordinary", simple = FALSE,
                         parallel = c("no", "multicore", "snow"),
                         ncpus = getOption("boot.ncpus", 1L),
                         cl = NULL, div.rm = TRUE) {

  # Using Jackknife estimates when \code{nb.resamples = NULL}
  if (is.null(nb.resamples)) {
    return(jackknife.mrb(object))
  }

  # Define a function to compute the target statistics and use 'boot::boot'
  switch(boot.type,
         parametric = { # For parametric bootstrapping

           #### Ensure the ordering of coefficients if object is 'mixed'
           if (identical(object$order.intercepts, "separate"))
             object <- mrb.switch.coef (object)

           #### Dimensions
           nb.y <- NCOL(object$fit.call$y)
           p <- NCOL(object$fit.call$x)
           pi <- sum(object$intercepts)
           q <- object$q

           #### Original data
           data <- cbind(object$fit.call$y,
                         object$fit.call$x,
                         object$fit.call$z,
                         object$fit.call$weights,
                         object$fit.call$offset)

           #### A function to extract the matrix for a specific dataset
           get.x.d <- function(data) {
             data[, (nb.y + 1):(nb.y + p), drop = FALSE]
           }

           #### A function to extract the matrix x for a specific dataset
           get.y.d <- function(data) {
             data[, 1:nb.y, drop = (nb.y == 1)]
           }

           #### A function to extract the vector/matrix z for a specific dataset
           if (length(object$fit.call$z) == 1) {
             get.z.d <- function(data) {
               object$fit.call$z
             }
           }
           else if (q == 1) {
             get.z.d <- function(data) {
               data[, (nb.y + p + 1):(nb.y + p + q), drop = TRUE]
             }
           }
           else {
             get.z.d <- function(data) {
               data[, (nb.y + p + 1):(nb.y + p + q), drop = FALSE]
             }
           }

           #### A function to extract the vector of weights for a specific dataset
           if (length(object$fit.call$weights) == 1) {
             get.weights.d <- function(data) {
               object$fit.call$weights
             }
           }
           else {
             get.weights.d <- function(data) {
               data[,nb.y + p + q + 1, drop = TRUE]
             }
           }

           #### A function to extract the vector of offset for a specific dataset
           if (length(object$fit.call$offset) == 1) {
             get.offset.d <- function(data) {
               object$fit.call$offset
             }
           }
           else {
             get.offset.d <- function(data) {
               data[,nb.y + p + q + 2, drop = TRUE]
             }
           }

           # Extract sample MLE
           theta <- c(object$coefficients, object$L.coefs)

           # Evaluation environment
           local.env <- new.env()

           #### A function to compute the vector of mrbglm coefficients
           statistic.fun.d <- function(data) {
             fit.data <- eval(call(if (is.function(object$method)) "method" else object$method,
                                   x = get.x.d (data),
                                   y = get.y.d (data),
                                   z = get.z.d (data),
                                   intercepts = object$intercepts,
                                   linkinv = object$fit.call$linkinv,
                                   weights = get.weights.d(data),
                                   start = theta,
                                   etastart = NULL, mustart = NULL,
                                   offset = get.offset.d (data),
                                   control = object$fit.call$control),
                              envir = local.env)

             res <- c(fit.data$coefficients,
                      fit.data$L.coefs,
                      conv = fit.data$converged,
                      zero.hessian = sum(diag(fit.data$hessian) == 0))

             return(res)
           }

           #### Generate a random sample from the mrbglm model
           ran.gen.fun <- function(data, mle) {
             Sim <- sim.mrb(x = get.x.d (data),
                            intercepts = object$fit.call$intercepts,
                            beta = mle[1:(p + pi)],
                            weights = get.weights.d(data),
                            z = get.z.d (data),
                            delta = mle[-c(1:(p + pi))],
                            maxp.offset = get.offset.d (data),
                            link = object$link)

             return(cbind(Sim$data,
                          Sim$weights,
                          Sim$offset))
           }

           #### Call 'boot' to do the job
           boot.object <- boot::boot (data = data,
                                      statistic = statistic.fun.d,
                                      R = nb.resamples,
                                      sim = "parametric",
                                      ran.gen = ran.gen.fun,
                                      mle = theta,
                                      parallel = parallel,
                                      ncpus = ncpus,
                                      cl = cl)

           colnames(boot.object$t) <- c(names(theta), 'cov', 'zero.hessian')

           boot.object$fit <- object
           return(boot.object)
         },
         { # For ordinary bootstrapping

           #### An index as 'data'
           data <- 1:object$nobs

           #### A function to extract the matrix for a specific sample index
           get.x <- function(index) {
             object$fit.call$x[index, , drop = FALSE]
           }

           #### A function to extract the matrix x for a specific sample index
           if (NCOL(object$fit.call$y) == 1) {
             get.y <- function(index) {
               object$fit.call$y[index]
             }
           }
           else {
             get.y <- function(index) {
               object$fit.call$y[index, , drop = FALSE]
             }
           }

           #### A function to extract the vector/matrix z for a specific sample index
           if (length(object$fit.call$z) == 1) {
             get.z <- function(index) {
               object$fit.call$z
             }
           }
           else if (NCOL(object$fit.call$z) == 1) {
             get.z <- function(index) {
               object$fit.call$z[index]
             }
           }
           else {
             get.z <- function(index) {
               object$fit.call$z[index, , drop = FALSE]
             }
           }

           #### A function to extract the vector of weights for a specific sample index
           if (length(object$fit.call$weights) == 1) {
             get.weights <- function(index) {
               object$fit.call$weights
             }
           }
           else {
             get.weights <- function(index) {
               object$fit.call$weights[index]
             }
           }

           #### A function to extract the vector of offset for a specific sample index
           if (length(object$fit.call$offset) == 1) {
             get.offset <- function(index) {
               object$fit.call$offset
             }
           }
           else {
             get.offset <- function(index) {
               object$fit.call$offset[index]
             }
           }

           # Extract sample MLE
           theta <- c(object$coefficients, object$L.coefs)

           # Evaluation environment
           local.env <- new.env()

           #### A function to compute the vector of mrbglm coefficients
           statistic.fun <- function(data, index) {
             fit.index <- eval(call(if (is.function(object$method)) "method" else object$method,
                                    x = get.x (index),
                                    y = get.y (index),
                                    z = get.z (index),
                                    intercepts = object$intercepts,
                                    linkinv = object$fit.call$linkinv,
                                    weights = get.weights(index),
                                    start = theta,
                                    etastart = NULL, mustart = NULL,
                                    offset = get.offset (index),
                                    control = object$fit.call$control),
                               envir = local.env)
             res <- c(fit.index$coefficients,
                      fit.index$L.coefs,
                      conv = fit.index$converged,
                      zero.hessian = sum(diag(fit.index$hessian) == 0))

             return(res)
           }

           #### Call 'boot' to do the job
           boot.object <- boot::boot (data = data,
                                      statistic = statistic.fun,
                                      R = nb.resamples,
                                      sim = "ordinary",
                                      stype = 'i',
                                      simple = simple,
                                      parallel = parallel,
                                      ncpus = ncpus,
                                      cl = cl)

           colnames(boot.object$t) <- c(names(theta), 'cov', 'zero.hessian')

           boot.object$fit <- object
           return(boot.object)
         }
  )

}
