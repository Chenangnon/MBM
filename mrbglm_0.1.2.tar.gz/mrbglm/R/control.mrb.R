#' Auxiliary for Controlling Binomial Model Fitting
#'
#' Auxiliary functions for a binomial model fitting (see e.g. \link{sim.mrb}
#' and \link{sim.mib}).
#' Typically only used internally by \code{\link{fit.mrb}} and \code{\link{fit.mib}},
#' but may be used to construct the control argument for \link{glm.mrb} and
#' \link{glm.mib}.
#'
#' @export control.mrb
#' @export control.mib
#'
#' @aliases control.mib
#'
#' @usage
#' control.mrb (fixLo = FALSE, fixL = FALSE, fixme = FALSE,
#'              criterion = "ML", order.intercepts = "mixed",
#'              slope.signs = NULL, nbeta.steps = 0, nother.steps = 0,
#'              beta.step = .5, other.step = 1, step.degree = 1,
#'              method = "Nelder-Mead", sequential = TRUE,
#'              final.method = "BFGS",
#'              epsilon = 1e-08, maxit = 500,
#'              trace = FALSE, cl = NULL,
#'              chunk.size = NULL)
#'
#' control.mib (fixLo = FALSE, fixL = FALSE, fixme = FALSE,
#'              criterion = "ML", slope.signs = NULL,
#'              nbeta.steps = 0, nother.steps = 0,
#'              beta.step = .5, other.step = 1, step.degree = 1,
#'              method = "Nelder-Mead", sequential = TRUE,
#'              final.method = "BFGS",
#'              epsilon = 1e-08, maxit = 500,
#'              trace = FALSE, cl = NULL,
#'              chunk.size = NULL)
#'
#' @param fixLo,fixL,fixme logical, should the parameters related to the limit
#' probability values (minimum and maximum) and standard deviations of Bergson
#' errors be kept fixed to their initial values? The default values for these
#' arguments (\code{FALSE}) means that each of these parameters is estimated
#' when present in the model.
#'
#' @param slope.signs character, indicates if the regression slopes in the model
#' should be forced to have a specific sign. One of \code{'NULL'} (the default,
#' no sign forcing), \code{'positive'} or \code{'negative'}.
#'
#' @param criterion character, criterion (i.e. objective function) to be
#' optimized to find the estimates of model parameters. Defaults to 'ML' for
#' Maximum Likelihood estimation. Currently, only the alternative 'NLS' for
#' Nonlinear Least Squares is available.
#'
#' @param order.intercepts a character, one of \code{'mixed'} (default) and
#' \code{'separate'}. The choice \code{'mixed'} means that the vector of
#' coefficients is arranged as \code{beta = [a_1, b_1, a_2, b_2, ..., a_p, b_p]}
#' where \code{a_j} and \code{b_j} are the intercept and the slope for the
#' \code{j}th predictor, and when a predictor is lacking an intercept, the
#' corresponding element is dropped from this expression of \code{beta}.
#' The choice \code{'separate'} means that the vector of coefficients is
#' arranged as \code{beta = [a_1, a_2, ..., a_p, b_1, b_2, ..., b_p]} with
#' elements corresponding to predictors lacking intercepts dropped.
#'
#' @param nbeta.steps,nother.steps integers in the range \code{[0, 10]}, indicating half
#' the number of variations to build for each of the \code{'beta'} and \code{'delta'}
#' components of the initial vector of model parameters (\code{nbeta.steps = 0}
#' and \code{nother.steps = 0} indicate no variation, meaning that only the
#' supplied or the self-initialized starting vector of model parameters will be
#' used). Any value \code{nbeta.steps} or \code{nother.steps} larger than \code{10}
#' is reset to \code{10}. See section '\code{Details}'.
#
# USE ONE "nsteps" for BETA and ONE for "delta"
# Often, we would want nbeta.steps = 0 or 1 and nother.steps = 1 to 3
#'
#' @param beta.step,other.step numeric vectors, used in the definition of a set of
#' additional starting vectors of model parameters. \code{beta.step} (\code{other.step})
#' is not used if \code{nbeta.steps = 0} (\code{nother.steps = 0}).
#' See section '\code{Details}'.
#'
#' @param step.degree positive integer in the range \code{[1, 2]}. Specifies the
#' degree of the combinations of various elements of additional initial vector
#' of model parameters to built. Any value \code{step.degree} larger than
#' \code{2} is reset to \code{step.degree = 2}. Not used if both
#' \code{nbeta.steps = 0} and \code{nother.steps = 0}.
#' See section \code{Details}'.
#'
#' @param method a character (or a vector of characters) indicating the
#' optimizer(s) to consider for the primary search of parameter estimates.
#' Currently, this can be one or many of \code{"Nelder-Mead"} (the default),
#' \code{"CG"}, \code{"BFGS"}, \code{"L-BFGS-B"}, \code{"nlm"}, \code{"nlminb"},
#' \code{"lbfgsb3c"}, \code{"Rcgmin"}, \code{"Rtnmin"}, \code{"Rvmmin"},
#' \code{"snewton"}, \code{"snewtonm"}, \code{"spg"}, \code{"ucminf"},
#' \code{"newuoa"}, \code{"bobyqa"}, \code{"nmkb"}, \code{"hjkb"}, \code{"hjn"},
#' and \code{"subplex"} (see \link[optimx]{opm} for algorithm details).
#' There is an additional pseudo-method \code{"ALL"} (capitalized), which can
#' be used to specify all available and suitable methods, except the
#' \code{final.method}.
#'
#' @param sequential logical, should the methods in \code{method} be attempted
#' sequentially? If \code{TRUE}, the next method is executed starting with the
#' best parameters found so far. Note that, in that case, the final result
#' might depend on the order of methods in \code{method}.
#'
#' @param final.method a character indicating the optimizer to consider for the
#' final search of parameter estimates. After trying all the methods specified
#' in \code{method}, this is used to attempt to refine the parameter estimates.
#' Defaults to \code{"BFGS"}. No refinement is attempted if \code{final.method = "none"}:
#' the result from the \code{method} with the lowest objective function value
#' (e.g. negative log-likelihood, sum of squares of errors) is picked as the best.
#' Note that \code{final.method} cannot be \code{"ALL"}. If \code{final.method}
#' is part of \code{method}, the \code{final.method} is removed from \code{method}.
#'
#' @param epsilon positive convergence tolerance, typically used as relative
#' tolerance (\code{reltol} for \link{optim}).
#'
#' @param maxit The maximum number of iterations. Defaults to \code{500}.
#'
#' @param trace logical indicating if output should be produced for each iteration.
#'
#' @param cl a cluster object, created by the package \code{parallel} or \code{snow}.
#' If not \code{NULL}, and many optimizations are required, they are performed
#' in parallel (if \code{sequential = FALSE}) using the function
#' \link[parallel]{parLapply} of the package \code{parallel}.
#'
#' @param chunk.size positive integer, number of invocations per parallel tasks
#' scheduling (see \link[parallel]{parLapply}).
#'
#' @details This functions are similar to the \link{glm.control} function for fitting
#' \link{glm}'s. The \code{control} argument of \link{glm.mrb} (or \link{glm.mib}) is by default passed
#' to the \code{control} argument of \link{fit.mrb} (or \link{fit.mib}), which uses its elements as
#' arguments to \code{control.mrb} (or \code{control.mib}): the latter provides defaults and
#' sanity checking to some extent (argument \code{cl} and \code{chunk.size} are
#' not checked).
#'
#' The arguments \code{nbeta.steps}, \code{nother.steps}, \code{beta.step},
#' \code{other.step}, and \code{step.degree} are used as follows. Consider a
#' supplied or self-initialized starting parameter vector
#' \code{start} \eqn{= [\beta, \delta]} (\eqn{\beta} elements are regression
#' coefficients and \eqn{\delta} elements are parameters defining the theoretical
#' maximum success probability of the response variable). Additional starting
#' parameters vectors are of the forms
#'
#' \code{newstart} \eqn{= [\beta + beta.step * k_b, \delta + other.step * k_d]}
#'
#' where \eqn{k_b} and \eqn{k_d} are positive integers (from 0 to \code{nsteps}).
#' If \code{step.degree = 1}, then only one of \eqn{k_b} and \eqn{k_d} is positive
#' for an additional vector of starting parameters. If \code{step.degree = 2},
#' then all combinations of \eqn{k_b} and \eqn{k_d} are considered, the case
#' where \eqn{k_b = 0} and \eqn{k_d = 0} corresponding to \code{newstart = start}.
#'
#' Note that the dimensions of \code{beta.step} and \code{other.step} are not
#' checked (and cannot be sanitized) by \code{control.mrb} since these dimensions
#' depend on the specific data set at hand (dimensions of \code{beta} and \code{delta},
#' i.e. numbers of model parameters/covariates). The default behavior sets scalar
#' values (\code{beta.step = 0.5} and \code{other.step = 1}) to ensure no dimension
#' compatibility issue during model fitting.
#'
#' @return A list with components named as the arguments.
#'

control.mrb <- function (fixLo = FALSE, fixL = FALSE, fixme = FALSE,
                         criterion = "ML", order.intercepts = "mixed",
                         slope.signs = NULL, nbeta.steps = 0, nother.steps = 0,
                         beta.step = .5, other.step = 1, step.degree = 1,
                         method = "Nelder-Mead", sequential = TRUE,
                         final.method = "BFGS",
                         epsilon = 1e-08, maxit = 500,
                         trace = FALSE, cl = NULL,
                         chunk.size = NULL) {

  if (!is.null(slope.signs)) {
    stopifnot(is.character(slope.signs))
    if (!all(slope.signs %in% c("positive", "negative")))
      stop("value of 'slope.signs' must one of 'NULL', 'positive' and negative'")
    slope.signs <- slope.signs[1]
  }

  stopifnot(is.character(criterion))
  if (!all(criterion %in% c("ML", "NLS")))
    stop("value of 'criterion' must one of 'ML' and NLS'")

  stopifnot(is.character(method))
  if (!all(method %in% c("Nelder-Mead", "BFGS", "CG", "L-BFGS-B", "nlm",
                      "nlminb", "lbfgsb3c", "Rcgmin", "Rtnmin", "Rvmmin", "snewton",
                      "snewtonm", "spg", "ucminf", "newuoa", "bobyqa", "nmkb",
                      "hjkb", "hjn", "subplex", "ALL")))
    stop("value of 'method' not recognized (see '?control.mrb' for a list of available methods)")
  if ("ALL" %in% method)
    method <- "ALL"

  sequential <- as.logical(sequential)
  stopifnot(is.logical(sequential))
  sequential <- sequential[1]

  stopifnot(is.character(final.method))
  final.method <- final.method[1]
  if (!all(final.method %in% c("BFGS", "CG", "Nelder-Mead", "L-BFGS-B", "nlm",
                         "nlminb", "lbfgsb3c", "Rcgmin", "Rtnmin", "Rvmmin",
                         "snewton", "snewtonm", "spg", "ucminf", "newuoa",
                         "bobyqa", "nmkb", "hjkb", "hjn", "subplex", "none")))
    stop("value of 'final.method' not recognized (see '?control.mrb' for a list of available methods)")

  rmv <- method %in% final.method
  if (any(rmv)) {
    method <- method[rmv]
  }

  if (!all(c(is.numeric(epsilon), epsilon > 0)))
    stop("value of 'epsilon' must be > 0")
  epsilon <- epsilon[1]

  if (!all(c(is.numeric(maxit), maxit > 0)))
    stop("maximum number of iterations must be > 0")
  maxit <- ceiling(maxit)[1]

  if (!all(c(is.numeric(nbeta.steps), nbeta.steps >= 0, is.numeric(nother.steps), nother.steps >= 0)))
    stop("arguments 'nbeta.steps' and 'nother.steps' must be non negative integers")
  nbeta.steps <- min(ceiling(nbeta.steps)[1], 10)
  nother.steps <- min(ceiling(nother.steps)[1], 10)

  if (!all(c(is.numeric(beta.step), sum(abs(beta.step)) > 0, is.numeric(other.step), sum(abs(other.step)) > 0)))
    stop("arguments 'beta.step' and 'other.step' must be numeric and non-null vectors")

  if (!all(c(is.numeric(step.degree), step.degree > 0)))
    stop("argument 'step.degree' must be a positive integer")
  step.degree <- max(1, min(ceiling(step.degree)[1], 2))

  list(fixLo = fixLo, fixL = fixL, fixme = fixme, slope.signs = slope.signs,
       criterion = criterion, order.intercepts = order.intercepts[1],
       nbeta.steps = nbeta.steps, nother.steps = nother.steps,
       beta.step = beta.step, other.step = other.step, step.degree = step.degree,
       method = method, sequential = sequential, final.method = final.method,
       epsilon = epsilon, maxit = maxit, trace = as.logical(trace)[1],
       cl = cl, chunk.size = chunk.size)
}
