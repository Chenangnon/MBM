
### Plot a bootstrap object from boot.mrb
curve.boot <- function (object, col = "red", lwd = 2,  ...) {
  if (object$fit$p > 1)
    stop("only implemented for 'p=1' predictor")
  curves.mrb(object$fit, col = col, lwd = lwd/2, ...)
  if (NROW(object$t) > 0)
    for (j in 1:NROW(object$t)) {
      cvec <- object$t[j,]
      col2 <- if(identical(col, "blue")) "red" else "blue"
      curves.mrb(cvec[1:length(object$fit$coefficients)],
                L = object$fit$linkinv(cvec[length(object$fit$coefficients) + 1]),
                col = col2, lwd = lwd/2, add = TRUE, ...)
    }
  curves.mrb(object$fit$coefficients,
            L = object$fit$L.values[1],
            col = col, lwd = lwd, add = TRUE, ...)
}
