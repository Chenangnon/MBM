#'
#' @export curve.mcexp
#'
#' @importFrom grDevices dev.off
#' @importFrom grDevices png
#'
### Plot a bootstrap object from boot.mrb
curve.mcexp <- function (object, linkinv = stats::plogis, add.median = TRUE, add.truth = TRUE,
                         pause = TRUE, path = "",
                         pwidth = 40, pheight = 40, units = "cm", res = 100,
                         col = "grey50", col.center = "black", col.truth = "blue",
                         lwd = 1, lty = 1, legend.x = NULL, legend.y = NULL,
                         text.width = NULL, ...) {
  p <- object$p
  if (p > 1)
    stop("only implemented for 'p=1' predictor")

  linkinv <- match.fun(linkinv)

  fixL <- object$call$fixL
  if (is.null(fixL))
    fixL <- FALSE
  saint <- sanitize.mcexp (object = object, fixL = fixL)
  xrange <- range(object$x)
  snames <- names(saint)

#  Tab.col <- as.vector(table(c(col, col.center, col.truth)))
#  if (any(Tab.col > 1)) {
#
#  }

  ### Loop over fitting settings
  for (k in 1:length(saint)) {
    resk <- saint[[k]]
    B <- NROW(resk)
    grDevices::png(filename = paste0(path, snames[k], "(", object$n, ").png"),   # The directory you want to save the file in
        width = pwidth, # The width of the plot in inches
        height = pheight, # The height of the plot in inches
        units = units, res = res)

    ### Individual replicate plots
    cvec <- resk[1,]
    curves.mrb(cvec[1:(p + 1)],
              L = linkinv(if (fixL) object$delta else cvec[p + 2]),
              col = col, lwd = lwd, lty = lty,
              from = xrange[1], to = xrange[2],
              main = paste0(snames[k], "(n=", object$n, ")"), ...)
    if (B > 1) { # Loop over repetitions
      for (j in 2:B) {
        cvec <- resk[j,]
        curves.mrb(cvec[1:(p + 1)],
                  L = linkinv(if (fixL) object$delta else cvec[p + 2]), lty = lty,
                  col = col, lwd = lwd, add = TRUE,
                  from = xrange[1], to = xrange[2], ...)
      }
    }

    ### Mean plot
    cvec <- colStats (resk, stat = 'mean')
    curves.mrb(cvec[1:(p + 1)],
              L = linkinv(if (fixL) object$delta else cvec[p + 2]), lty = lty,
              col = col.center, lwd = lwd * 5, add = TRUE,
              from = xrange[1], to = xrange[2], ...)

    ### Median plot
    if(add.median) {
      cvec <- colStats (resk, stat = 'median')
      curves.mrb(cvec[1:(p + 1)],
                L = linkinv(if (fixL) object$delta else cvec[p + 2]), lty = lty + 2,
                col = col.center, lwd = lwd * 5, add = TRUE,
                from = xrange[1], to = xrange[2], ...)
    }

    ### Truth
    # The "Truth" is the curve based on the true parameter values
    # (L = , intercept = , slope = ).
    if (add.truth) {
      curves.mrb(object$beta,
                L = linkinv(object$delta),
                col = col.truth, lwd = lwd * 5, lty = lty, add = TRUE,
                from = xrange[1], to = xrange[2], ...)
    }

    if (is.null(legend.x))
      legend.x <- xrange[1] + .8 * diff(xrange)
    if (is.null(legend.y))
      legend.y <- 1

    legend(x = legend.x, y = legend.y,
           lwd = c(lwd, if(add.median) lwd, if (add.truth) lwd) * 5,
           lty = c(lty, if(add.median) lty + 2, if (add.truth) lty),
           col = c(col.center, if(add.median) col.center, if (add.truth) col.truth),
           legend = c("Mean estimates", if(add.median) "Median estimates", if (add.truth) "Truth"),
           text.width = text.width)

    grDevices::dev.off()
  }
}


sanitize.mcexp <- function(object, fixL, negative.slope = 1) {
  if (fixL) {
    sel <- (object$TruestartML[,5] == 1) + (object$TruestartML[,6] == 0) + (negative.slope * (object$TruestartML[,2] <= 0))  == 2 + negative.slope
    TruestartML <- object$TruestartML[sel, 1:4, drop = FALSE]
    attr(TruestartML, "conv") <- mean(object$TruestartML[,5] == 1, na.rm = TRUE)
    attr(TruestartML, "zero.hessian") <- mean(object$TruestartML[,6] == 1, na.rm = TRUE)

    sel <- (object$TruestartNLS[,5] == 1) + (object$TruestartNLS[,6] == 0) + (negative.slope * (object$TruestartNLS[,2] <= 0))  == 2 + negative.slope
    TruestartNLS <- object$TruestartNLS[sel, 1:4, drop = FALSE]
    attr(TruestartNLS, "conv") <- mean(object$TruestartNLS[,5] == 1, na.rm = TRUE)
    attr(TruestartNLS, "zero.hessian") <- mean(object$TruestartNLS[,6] == 1, na.rm = TRUE)

    sel <- (object$CustomstartML[,5] == 1) + (object$CustomstartML[,6] == 0) + (negative.slope * (object$CustomstartML[,2] <= 0))  == 2 + negative.slope
    CustomstartML <- object$CustomstartML[sel, 1:4, drop = FALSE]
    attr(CustomstartML, "conv") <- mean(object$CustomstartML[,5] == 1, na.rm = TRUE)
    attr(CustomstartML, "zero.hessian") <- mean(object$CustomstartML[,6] == 1, na.rm = TRUE)

    sel <- (object$CustomstartNLS[,5] == 1) + (object$CustomstartNLS[,6] == 0) + (negative.slope * (object$CustomstartNLS[,2] <= 0))  == 2 + negative.slope
    CustomstartNLS <- object$CustomstartNLS[sel, 1:4, drop = FALSE]
    attr(CustomstartNLS, "conv") <- mean(object$CustomstartNLS[,5] == 1, na.rm = TRUE)
    attr(CustomstartNLS, "zero.hessian") <- mean(object$CustomstartNLS[,6] == 1, na.rm = TRUE)
  }
  else {
    sel <- (object$TruestartML[,9] == 1) + (object$TruestartML[,10] == 0) + (negative.slope * (object$TruestartML[,2] <= 0))  == 2 + negative.slope
    TruestartML <- object$TruestartML[sel, 1:8, drop = FALSE]
    attr(TruestartML, "conv") <- mean(object$TruestartML[,9] == 1, na.rm = TRUE)
    attr(TruestartML, "zero.hessian") <- mean(object$TruestartML[,10] == 1, na.rm = TRUE)

    sel <- (object$TruestartNLS[,9] == 1) + (object$TruestartNLS[,10] == 0) + (negative.slope * (object$TruestartNLS[,2] <= 0))  == 2 + negative.slope
    TruestartNLS <- object$TruestartNLS[sel, 1:8, drop = FALSE]
    attr(TruestartNLS, "conv") <- mean(object$TruestartNLS[,7] == 1, na.rm = TRUE)
    attr(TruestartNLS, "zero.hessian") <- mean(object$TruestartNLS[,10] == 1, na.rm = TRUE)

    sel <- (object$CustomstartML[,9] == 1) + (object$CustomstartML[,10] == 0) + (negative.slope * (object$CustomstartML[,2] <= 0))  == 2 + negative.slope
    CustomstartML <- object$CustomstartML[sel, 1:8, drop = FALSE]
    attr(CustomstartML, "conv") <- mean(object$CustomstartML[,7] == 1, na.rm = TRUE)
    attr(CustomstartML, "zero.hessian") <- mean(object$CustomstartML[,10] == 1, na.rm = TRUE)

    sel <- (object$CustomstartNLS[,9] == 1) + (object$CustomstartNLS[,10] == 0) + (negative.slope * (object$CustomstartNLS[,2] <= 0))  == 2 + negative.slope
    CustomstartNLS <- object$CustomstartNLS[sel, 1:8, drop = FALSE]
    attr(CustomstartNLS, "conv") <- mean(object$CustomstartNLS[,7] == 1, na.rm = TRUE)
    attr(CustomstartNLS, "zero.hessian") <- mean(object$CustomstartNLS[,10] == 1, na.rm = TRUE)
  }

  list(TruestartML = TruestartML,
       TruestartNLS = TruestartNLS,
       CustomstartML = CustomstartML,
       CustomstartNLS = CustomstartNLS)
}

