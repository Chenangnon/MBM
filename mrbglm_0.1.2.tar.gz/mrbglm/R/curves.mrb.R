#' Plot MRB model curve(s)
#'
#' Plot MRB model curve given an 'mrbglm' object or model coefficients/parameters
#' ADD CONFIDENCE REGION PLOT FOR AN 'mrbglm' object
#'
#' @aliases curves.mrb
#'
#' @param object an object inheriting from class \code{mrbglm} or \code{mrb.fit}
#' (as returned by \link{glm.mrb}), or a numeric vector of two elements
#' (intercept, slope), or an \link{expression} or a \link{function}.
#'
#' @param L optional numeric scalar in (0, 1]. Specifies the maximum success
#'  probability of the binary response variable.
#'
#' @param Lo optional numeric scalar in [0, 1). Specifies the minimum success
#'  probability of the binary response variable.
#'
#' @param from,to,n,add,type,col,lty,lwd,cex,xname,xlab,ylab,main See \link[graphics]{curve}.
#'
#' @param xlim,ylim,zlim optional numeric vectors of two elements. See \link[graphics]{plot}.
#'
#' @param jitter logical, should the plot be jittered? Defaults to \code{TRUE}.
#' This is only used when \code{object} is of class \code{mrbglm} or \code{mrbglm.fit}
#' and has only one covariate (2-D plot).
#'
#' @param jitter.range optional numeric scalar, range of the jitter/random noise (half
#' \code{jitter.range} below and half \code{jitter.range} above). Only used for
#' 2-D plot when \code{jitter = TRUE}.
#'
#' @param seed an integer to seed the random generator of \code{R} before using
#' the function \link{runif} to add noise to the response. Only used for 2-D plot
#' when \code{jitter = TRUE}.
#'
#' @param linkinv link function, used if \code{object} is of class \code{"numeric."}.
#'
#' @param theta,phi,expand,ltheta,shade,r,d,scale,border,box,axes,nticks,ticktype See \link{persp}.
#'
#' @param ... additional arguments to be passed to \link{curve} (1-D plot) or
#' \link{persp}.
#'
#' @details The function calls \link{curve} on a specified expression (\code{object})
#' or one derived from \code{object} if the latter is a numeric vector or an object
#' of class \code{mrbglm} or \code{mrb.fit}.
#'
#' The jitter is obtained by adding uniform noise to the response vector in the \code{mrbglm} object.
#'
#' @export curves.mrb
#' @export curves.mrbglm
#'
#' @exportS3Method curves mrbglm
#'
#' @import stats
#' @import graphics
#' @examples
#'
#' ## Example 1
#' # Plot the curve corresponding to some model parameters
#' # (intercept = 2, slope = 1, L = 0.8)
#' curves(c(2, -1), L = 0.8, col = "black", lwd = 1)
#'
#' ## Example 2
#' # Plot the data used to fit a model and add the fitted curve
#' # Simulate some data
#' set.seed(167)
#' mrbdata = sim.mrb (beta = c(2, -3),
#'                    x = cbind(ddg_fold = rlnorm(n = 250, meanlog = 0.9887002,
#'                                              sdlog = 0.7927336) - 2.142344),
#'                    delta = qlogis(0.8), yname = "Viability")$data[,1:2]
#'
#'
#' head (mrbdata)
#'
#'# Fit the model
#' mrbfit1 = glm.mrb (Viability ~ ddg_fold, data = mrbdata, intercepts = TRUE)
#'
#' # Plot the fit
#' curves (mrbfit1, jitter.range = .2, col = "red", lwd = 2)
#'
#' # Add a curve with L = 0.8 (keeping the inferred intercept and slope values)
#' curves (mrbfit1$coefficients, L = .7,
#'        from = min(mrbdata$ddg_fold),
#'        to = max(mrbdata$ddg_fold),
#'        col = "blue", lwd = 2, add = TRUE)
#'
#' # Add a legend
#' legend(x = 0.75 * max(mrbdata$ddg_fold), y = 1, c("ML fit (L = 0.93)", "ML fit but L = 0.7"),
#' col = c("red", "blue"),
#' lwd = c(2, 2),
#' lty = c(1, 1), cex = .5)
#' # End (not run)

curves.mrbglm <- function (object, Lo = 0, L = 1, from = -3, to = 8,
                          xlim = c(from, to), ylim = c(0, 1), zlim = ylim,
                          n = 51, add = FALSE, type = "l", col = NULL,
                          lty = 1, lwd = 2, cex = .1,
                          jitter = TRUE, jitter.range = .2, seed = 1,
                          xname = NULL, linkinv = stats::plogis,
                          xlab = NULL, ylab = NULL, main = " ",
                          theta = 50, phi = 10, expand = 0.8,
                          ltheta = 0, shade = 0.75, r = sqrt(3), d = 1,
                          scale = TRUE, border = NULL, box = TRUE,
                          axes = TRUE, nticks = 5, ticktype = "detailed",
                          ...) {
  if (is.expression(object) | is.function(object)) {
    if (missing(xlab))
      xlab <- "x"
    if (missing(ylab))
      ylab <- "y"
    return(graphics::curve(expr = object, from = from, to = to, n = n, add = add,
                           type = type, xname = xname, xlab = xlab, ylab = ylab,
                           log = log, xlim = xlim, col = col, ...))
  }
  if (inherits(object, "mrbglm") | inherits(object, "mrb.fit")) {
    beta <- object$coefficients
    p <- object$p
    if (missing(col))
      col <- if (p == 1) "black" else "lightblue"
    if (p == 0) {
      stop("a numeric argument 'beta' must have at least one element")
    }
    if (p > 2) {
      stop("only MRB models with at most two predictors are currently handled")
    }
    if (missing(Lo)) {
      Lo <- object$Lo.values[1]
    }
    else {
      stopifnot(is.numeric(Lo))
    }

    if (missing(L)) {
      L <- object$L.values[1]
    }
    else {
      stopifnot(is.numeric(L))
    }

    if (sum(object$intercepts) == 0) {
      beta.int <- rep(0, p)
    }
    else if (sum(object$intercepts) == 1 & p == 1) {
      beta.int <- beta[1]
      beta <- beta[2]
    }
    else if (sum(object$intercepts) == 2) {
      if (identical(object$order.intercepts, "mixed")) {
        beta.int <- beta[c(1,3)]
        beta <- beta[c(2,4)]
      }
      else {
        beta.int <- beta[1:2]
        beta <- beta[3:4]
      }
    }

    if (missing(xname) & p == 1)
      xname <- "x"

    if (p == 1) {
      Xval <- with(object$data, eval(object$call$formula[3][[1]]))
      if (missing(xlim)) {
        xlim <- range(Xval)
      }

      if (is.null(xlab))
        xlab <- deparse(object$call$formula[3][[1]])
      if (is.null(ylab))
        ylab <- deparse(object$call$formula[2][[1]])

      if (jitter) {
        stopifnot(is.numeric(jitter.range))
        if (!is.null(seed))
          set.seed(seed)
        Jitter <- runif(NROW(object$data), min = -abs(jitter.range)/2, max = abs(jitter.range)/2)
      }
      else
        Jitter <- 0

      plot(Xval,
           with(object$data, eval(object$call$formula[2][[1]])) + Jitter,
           cex = cex, xlab = xlab, ylab = ylab)
      res <- graphics::curve(L[1] * (Lo[1] + (1 - Lo[1]) * object$linkinv (beta.int[1] + beta[1] * x)),
                             from = xlim[1], to = xlim[2], ylim = ylim,
                             col = col, lty = lty, lwd = lwd, xname = "x",
                             xlab = xlab, ylab = ylab, add = TRUE, n = n, ...)
    }
    else {
      X1val <- with(object$data, eval(object$call$formula[3][[1]][[2]]))
      X2val <- with(object$data, eval(object$call$formula[3][[1]][[3]]))

      if (missing(xlim)) {
        x1lim <- range(X1val)
        x2lim <- range(X2val)
      }
      else {
        if (is.list(xlim)) {
          x1lim <- xlim[[1]]
          x2lim <- xlim[[2]]
        }
        else {
          x1lim <- x2lim <- xlim
        }
      }

      if (is.null(xlab)) {
        x1lab <- deparse(object$call$formula[3][[1]][[2]])
        x2lab <- deparse(object$call$formula[3][[1]][[3]])
      }
      else {
        if (is.list(xlab)) {
          x1lab <- xlab[[1]]
          if (length(xlab) > 1)
            x2lab <- xlab[[2]]
          else
            x2lab <- x1lab
        }
        else {
          x1lab <- x2lab <- xlab
        }
      }
      if (is.null(ylab))
        ylab <- deparse(object$call$formula[2][[1]])

      if (jitter) {
        stopifnot(is.numeric(jitter.range))
        if (!is.null(seed))
          set.seed(seed)
        Jitter <- runif(NROW(object$data), min = -abs(jitter.range)/2, max = abs(jitter.range)/2)
      }
      else
        Jitter <- 0

      yobs <- with(object$data, eval(object$call$formula[2][[1]])) + Jitter

      x1values <- seq(x1lim[1], x1lim[2], length.out = n)
      x2values <- seq(x2lim[1], x2lim[2], length.out = n)
      zvalues <- outer(x1values, x2values,
                       FUN = function(x,y) {
                         object$linkinv(beta.int[1] + beta[1] * x) *
                           object$linkinv(beta.int[2] + beta[2] * y)
                       })
      zvalues <- L[1] * (Lo[1] + (1 - Lo[1]) * zvalues)

      # op <- par(bg = "white")
      res <- persp(x1values, x2values, zvalues, theta = theta, phi = phi,
                   expand = expand, col = col, ltheta = ltheta, shade = shade,
                   main = main, xlab = x1lab, ylab = x2lab, zlab = ylab, zlim = zlim,
                   r = r, d = d, scale = scale, border = border, box = box,
                   axes = axes, nticks = nticks, ticktype = ticktype)
    }
    return(invisible(res))
  }
  stopifnot(is.numeric(object))
  beta <- object
  p <- length(beta)
  if (missing(col))
    col <- if (p == 1) "black" else "lightblue"
  stopifnot(is.numeric(L))
  if ((nb.beta <- length(beta)) > 2) {
    stop("only MRB model with one predictor is currently handled")
  }
  if (nb.beta == 0) {
    stop("a numeric argument 'beta' must have at least one element")
  }
  if (nb.beta == 1) {
    beta <- c(0, beta)
  }
  if (missing(xlab))
    xlab <- "ddg_fold"
  if (missing(ylab))
    ylab <- "Viability"

  res <- graphics::curve(L[1] * linkinv (beta[1] + beta[2] * x),
               from = xlim[1], to = xlim[2], ylim = ylim,
               col = col, lty = lty, lwd = lwd, xname = "x",
               xlab = xlab, ylab = ylab, add = add, ...)

  return(invisible(res))
}

curves.mrb <- curves.mrbglm
