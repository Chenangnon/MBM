# Density of a sum of two binomial variates
dbinsum <- function(x, size1, prob1, size2 = size1, prob2 = prob1, log = FALSE) {
  # case when the sum is binomial
  if (all(prob2 == prob1)) {
    return(dbinom(x = x, size = size1 + size2, prob = prob1, log = log))
  }
  res <- apply(cbind(x, size1, prob1, size2, prob2, size1 <= size2, log),
               MARGIN = 1, FUN = dbinsum_i)

  return(res)
}

dbinsum_i <- function(datai) {
  if (datai[6]) { # if size1 <= size2
    x1 <- 0:min(datai[1], datai[2])
    x2 <- datai[1] - x1
    sel <- x2 <= datai[4]
    if (any(sel)) {
      x1 <- x1[sel]
      x2 <- x2[sel]
    }
    else
      return(if (datai[7]) -Inf else 0)
  }
  else {
    x2 <- 0:min(datai[1], datai[4])
    x1 <- datai[1] - x2
    sel <- x1 <= datai[2]
    if (any(sel)) {
      x1 <- x1[sel]
      x2 <- x2[sel]
    }
    else
      return(if (datai[7]) -Inf else 0)
  }
  resi <- dbinom(x1, size = datai[2], prob = datai[3], log = TRUE) +
    dbinom(x2, size = datai[4], prob = datai[5], log = TRUE)
  resi <- sum(exp(resi))
  if (!datai[7])
    return(resi)
  return(logb(resi))
}
