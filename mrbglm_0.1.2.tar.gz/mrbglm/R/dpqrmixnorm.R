# TO BE COMPLETED with density, quantile and random deviate generator

#' The normal location mixture of normal distributions
#'
#' @description
#' The normal location mixture of normal distribution is the mixed normal
#' distribution obtained from continuously mixing probit probabilities using
#' a normal mixing distribution.
#'
#'
#' @export pmixnorm
#'
pmixnorm <- function (x, mean = 0, sd = 1, mix.sd = 0,
                      lower.tail = TRUE, log.p = FALSE) {
  # Pre-processing
  x <- c(x)
  x <- cbind(c(x), c(mean), c(sd), c(mix.sd))
  mean <- x[,2]
  sd <- x[,3]
  mix.sd <- x[,4]
  x <- x[,1]

  # Compute the mixed probits
  p <- pnorm (x / sqrt(1 + mix.sd^2), mean = 0,
              sd = 1, lower.tail = lower.tail,
              log.p = log.p)
  return(p)
}
