
# If mestart is given and zme = NULL, then me.offsets is not used at all

# mrb fit when Bergeson error variance is available
fit.me.mrb <- function (y, weights = 1, sample.weights = 1,
                        x, contract_eta, intercepts = TRUE, x.offsets = 0,
                        x.with.me = NULL, zme = NULL, pred.with.me = NULL,
                        me.intercepts = FALSE,
                        me.offsets = 0,
                        zminp = NULL, minp.offset = 0,
                        zmaxp = 1, maxp.offset = 0,
                        link = logit(), start = NULL,
                        mustart = NULL, etastart = NULL, # Arguments passed to glm.fit for initialization
                        mestart = NULL, gammastart = NULL,
                        Lostart = NULL, deltaostart = NULL,
                        Lstart = NULL, deltastart = NULL,
                        control = list(), ...) {
  ### Save the call
  fit.call <- match.call()

  ### Link function
  linkfun <- link$linkfun
  linkinv <- link$linkinv
  melinkinv <- link$melinkinv

  ### Dimensions and weights
  eval(memrb.dim())
  pi <- sum(intercepts)

  ### Initialization
  eval(initialize.me.mrb.fit())

  ### transpose 'x' and 'x.offsets' for convenience
  if(is.matrix(x))
    x <- t(x)
  if(is.matrix(x.offsets))
    x.offsets <- t(x.offsets)

  ### Negative log-likelihood function
  eval(make.me.mrb.nlikefun())

  ### Optimization
  nparams <- p + pi + qo * (!control$fixLo) + q * (!control$fixL) + (r+ri) * (r > 0)
  theta0 <- start
  start <- theta0[1:nparams]

  ### Bounds if required
  if (!is.null(control$slope.signs)) {
    if (identical(control$slope.signs, "positive")) {
      start[(pi + 1):(pi + p)] <- pmax(1e-10, start[(pi + 1):(pi + p)])
      lowerb <- rep(-Inf, nparams)
      lowerb[(pi + 1):(pi + p)] <- 0
      upperb <- Inf
    }
    else {
      start[(pi + 1):(pi + p)] <- pmin(-1e-10, start[(pi + 1):(pi + p)])
      lowerb <- -Inf
      upperb <- rep(Inf, nparams)
      upperb[(pi + 1):(pi + p)] <- 0
    }
  }
  else {
    lowerb = -Inf
    upperb = Inf
  }

  vmethods <- c("Nelder-Mead", "BFGS", "CG", "L-BFGS-B", "SANN", "Brent")
  vmethod <- control$method %in% vmethods
  optres0 <- NULL

  if (length(control$method) > 1 | any(!vmethod)) {

    optres0 <- optim.mrb (start = start,
                          nb.betas = pi + p,
                          nlikefun = nlikefun,
                          control = control,
                          lower = lowerb,
                          upper = upperb)

    optres <- optres0$finalresult
    control$method <- unique(c(control$final.method, control$method))
    vmethod <- control$method %in% vmethods

    if (any(vmethod)) {
      control$method <- control$method[vmethod][1]
    }
    else
      control$method <- "Nelder-Mead"
  }
  else {

    optres <- catch.conditions({
      stats::optim(par = start, fn = nlikefun,
                   method = control$method,
                   control = list(maxit = control$maxit,
                                  reltol = control$epsilon),
                   lower = lowerb,
                   upper = upperb,
                   hessian = TRUE)
    })$value
  }

  pbeta <- pi + p
  if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
    optres <- catch.conditions({
      stats::optim(par = start, fn = nlikefun,
                   method = 'Nelder-Mead',
                   control = list(maxit = 3 * control$maxit,
                                  reltol = control$epsilon))
    })$value
    if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
      if (!control$fixL) {
        start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(deltastart + 1, q)
        optres <- catch.conditions({
          stats::optim(par = start, fn = nlikefun,
                       method = control$method,
                       control = list(maxit = control$maxit,
                                      reltol = control$epsilon),
                       hessian = TRUE)
        })$value

        if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
          start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(deltastart + 2, q)
          optres <- catch.conditions({
            stats::optim(par = start, fn = nlikefun,
                         method = control$method,
                         control = list(maxit = control$maxit,
                                        reltol = control$epsilon),
                         hessian = TRUE)
          })$value
        }

        if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
          start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(-1, q)
          optres <- catch.conditions({
            stats::optim(par = start, fn = nlikefun,
                         method = control$method,
                         control = list(maxit = control$maxit,
                                        reltol = control$epsilon),
                         hessian = TRUE)
          })$value
        }

        if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
          start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(-2, q)
          optres <- catch.conditions({
            stats::optim(par = start, fn = nlikefun,
                         method = control$method,
                         control = list(maxit = control$maxit,
                                        reltol = control$epsilon),
                         hessian = TRUE)
          })$value
        }
      }

      if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
        stop(paste0("fitting failled: ",
                    optres,
                    ". Try another optimizer (see '?control.mrb')"))
      }
    }
    else {
      optres <- catch.conditions({
        stats::optim(par = optres$par, fn = nlikefun,
                     method = control$method,
                     control = list(maxit = control$maxit,
                                    reltol = control$epsilon),
                     hessian = TRUE)
      })$value
    }
  }
  else if (any(colSums(optres$hessian[1:pbeta, 1:pbeta] == 0) == pbeta) & !control$fixL) {
    start1 <- start
    start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart + 1
    optres1 <- catch.conditions({
      stats::optim(par = start1, fn = nlikefun,
                   method = control$method,
                   control = list(maxit = control$maxit,
                                  reltol = control$epsilon),
                   lower = lowerb,
                   upper = upperb,
                   hessian = TRUE)
    })$value
    if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
      invalid1 <- TRUE
    }
    else {
      invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
      if (invalid1) {
        start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart + 2
        optres1 <- catch.conditions({
          stats::optim(par = start1, fn = nlikefun,
                       method = control$method,
                       control = list(maxit = control$maxit,
                                      reltol = control$epsilon),
                       lower = lowerb,
                       upper = upperb,
                       hessian = TRUE)
        })$value
        if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
          invalid1 <- TRUE
        }
        else {
          invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
        }
      }
    }
    if (invalid1) {
      start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart - 1
      optres1 <- catch.conditions({
        stats::optim(par = start1, fn = nlikefun,
                     method = control$method,
                     control = list(maxit = control$maxit,
                                    reltol = control$epsilon),
                     lower = lowerb,
                     upper = upperb,
                     hessian = TRUE)
      })$value
      if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
        invalid1 <- TRUE
      }
      else {
        invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
        if (invalid1) {
          start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart - 2
          optres1 <- catch.conditions({
            stats::optim(par = start1, fn = nlikefun,
                         method = control$method,
                         control = list(maxit = control$maxit,
                                        reltol = control$epsilon),
                         lower = lowerb,
                         upper = upperb,
                         hessian = TRUE)
          })$value
          if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
            invalid1 <- TRUE
          }
          else {
            invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
          }
        }
      }
    }
    if (!invalid1) {
      optres <- optres1
    }
  }

  if (!is.null(optres0)) {
    optres0$finalresult <- optres
    optres$details <- optres0
  }

  iter <- optres$counts
  converged <- optres$convergence == 0
  if (length(optres$convergence) == 0) {
    optres$convergence <- NA
    converged <- FALSE
    attr(converged, 'code') <- NA
  }
  else
    attr(converged, 'code') <- conv.optim(optres$convergence)
  attr(converged, 'message') <- optres$message

  # Extracting basic results
  theta <- optres$par
  beta <- theta[1:pbeta]
  if (any(intercepts)) {
    beta.int <- theta[1:pi]
    beta.x <- theta[(pi+1):pbeta]
    eta <- beta.x * x
    eta <- contract.eta (eta, contract_eta)
    eta <- eta + x.offsets
    eta[intercepts,] <- eta[intercepts,] + beta.int
    if (!control$fixLo)
      deltao <- theta[(pbeta + 1):(pbeta + qo)]
    if (!control$fixL)
      delta <- theta[(pbeta + qo + 1):(pbeta + qo + q)]
    if (!control$fixme) {
      gamma.int <- if (ri > 0) theta[(pbeta + qo + q + 1):(pbeta + qo + q + ri)]
      gamma <- theta[(pbeta + qo + q + ri + 1):(pbeta + qo + q + ri + r)]
    }
  }
  else {
    beta.int <- NULL
    eta <- beta.x * x
    eta <- contract.eta (eta, contract_eta)
    eta <- eta + x.offsets
    if (!control$fixLo)
      deltao <- theta[(p+1):(p+qo)]
    if (!control$fixL)
      delta <- theta[(p+qo+1):(p+qo+q)]
    if (!control$fixme) {
      gamma.int <- if (ri > 0) theta[(pbeta + qo + q + 1):(pbeta + qo + q + ri)]
      gamma <- theta[(pbeta + qo + q + ri + 1):(pbeta + qo + q + ri + r)]
    }
  }
  if (!control$fixLo)
    Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
  if (!control$fixL)
    logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
  if (control$fixme) {
    sdmat <- t(sd0)
  }
  else {
    sdmat <- get.sdmat (theta, ptout = pbeta + qo + q)
  }
  sdmat.beta <- sdmat
  sdmat.beta[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
  if (any(sdmat.beta > 0))
    mu <- exp(colSums(melinkinv(eta, sd = sdmat.beta, log.p = TRUE)))
  else
    mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
  mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) * mu)
  validmu <- is.finite(mu) & (mu > 0 & mu < 1)

  ### Degrees of freedom
  df.residual <- ssize - nparams
  df.null <- ssize - 1
  if (!all(validmu) & length(weights) > 1)
    weights <- weights[validmu]
  if (identical(control$criterion, "NLS")) {
    dispersion <- sum((y[validmu] - mu[validmu])^2) / df.residual
  }
  else {
    dispersion <- 1
  }

  residual.deviance <- numeric(nobs) + NA
  switch(control$criterion,
         NLS = {
           residual.deviance[validmu] <- - 2 * stats::dnorm(y[validmu],
                                                            mean = mu[validmu] * weights,
                                                            sd = sqrt(dispersion),
                                                            log = TRUE) *
             (if (length(sample.weights) > 1) sample.weights[validmu] else sample.weights)
         },
         ML = {
           residual.deviance[validmu] <- - 2 * stats::dbinom(y[validmu], size = weights,
                                                             prob = mu[validmu],
                                                             log = TRUE) *
             (if (length(sample.weights) > 1) sample.weights[validmu] else sample.weights)
         })

  deviance <- sum(residual.deviance[validmu])
  logLike <- - .5 * deviance
  aic <- deviance + 2 * nparams
  bic <- deviance + log(ssize) * nparams

  ### Covariance matrix estimate
  hessian <- optres$hessian
  Rmat <- catch.conditions(solve(optres$hessian))$value
  if (any(class(Rmat) %in% c("simpleError", "error", "condition", "try-error"))) {
    if (all(optres$hessian == 0))
      warning("algorithm did not converge: over-parameterized model -- no covariance matrix estimate available")
    else if (any(colSums(abs(optres$hessian[1:pbeta, 1:pbeta])) == 0))
      warning("algorithm did not converge: no covariance matrix estimate available")
    else {
      Rmato <- catch.conditions(solve(optres$hessian[1:pbeta, 1:pbeta]))$value
      if (any(class(Rmato) %in% c("simpleError", "error", "condition", "try-error"))) {
        warning("algorithm did not converge: no covariance matrix estimate available")
      }
      else {
        Rmat <- matrix(0, nrow = nparams, ncol = nparams)
        Rmat[1:pbeta, 1:pbeta] <- Rmato
        warning("over-parameterized model? -- 0 or NA in covariance matrix estimate")
        Rmat <- Rmat * dispersion
        dimnames(Rmat) <- list(names(start), names(start))
      }
    }
  }
  else {
    Rmat <- Rmat * dispersion
    dimnames(Rmat) <- list(names(start), names(start))
  }

  ### Computing the null deviance (account for the criterion)
  switch(control$criterion,
         NLS = {
           nlike.null.mrb <- function(beta0) {
             mu <- exp(linkinv(beta0, log.p = TRUE)) # + logLvalues

             res <- stats::dnorm(y[validmu], mean = mu * weights,
                                 sd = sqrt(dispersion), log = TRUE)
             -sum(res * (if (length(sample.weights) > 1) sample.weights[validmu] else sample.weights),
                  na.rm = TRUE)
           }
         },
         ML = {
           nlike.null.mrb <- function(beta0) {
             mu <- exp(linkinv(beta0, log.p = TRUE)) # + logLvalues
             res <- stats::dbinom(y[validmu], size = weights, prob = mu, log = TRUE)
             -sum(res * (if (length(sample.weights) > 1) sample.weights[validmu] else sample.weights), na.rm = TRUE)
           }
         })

  null.method <- control$method
  if (!(null.method %in% c("Nelder-Mead", "BFGS", "CG", "L-BFGS-B", "SANN", "Brent")))
    null.method <- "Nelder-Mead"

  null.deviance <- catch.conditions({
    stats::optim(par = linkfun (mean(y/weights, na.rm = TRUE)), fn = nlike.null.mrb,
                 method = null.method,
                 control = list(maxit = control$maxit,
                                reltol = control$epsilon))
  })
  if (any(class(null.deviance$value) %in% c("simpleError", "error", "condition", "try-error"))) {
    warning(paste0("fitting to compute the null deviance failled: ",
                   null.deviance$value))
    null.deviance <- NA
    beta0 <- NA
  }
  else {
    beta0 <- null.deviance$value$par
    null.deviance <- 2 * null.deviance$value$value
  }

  ### Computing the residual deviance (conditional on L.values)
  ### Computing the residual deviance (conditional on L.values)
  #if (!is.na(null.deviance)) {
  #mu.null <- exp(logLvalues + linkinv(beta0, log.p = TRUE))
  #validmu <- is.finite(mu.null) & (mu.null > 0 & mu.null < 1)
  #if (!all(validmu) & length(weights) > 1)
  # weights <- weights[validmu]

  if (!is.null(zminp)) {
    if(is.null(zonames <- names(zminp))) {
      if ((zolen <- length(zminp)) == 1) {
        names(Lovalues) <- "Lo"
      }
      else {
        if (is.matrix(zminp))
          names(Lovalues) <- paste0("Lo", 1:NCOL(zminp))
        else
          names(Lovalues) <- paste0("Lo", 1:zolen)
      }
    }
    else {
      names(Lovalues) <- zonames
    }
  }
  else if (length(Lovalues) == 1) {
    names(Lovalues) <- "Lo"
  }
  L.values <- exp(logLvalues)
  if (!is.null(zmaxp)) {
    if(is.null(znames <- names(zmaxp))) {
      if ((zlen <- length(zmaxp)) == 1) {
        names(L.values) <- "L"
      }
      else {
        if (is.matrix(zmaxp))
          names(L.values) <- paste0("L", 1:NCOL(zmaxp))
        else
          names(L.values) <- paste0("L", 1:zlen)
      }
    }
    else {
      names(L.values) <- znames
    }
  }
  else if (length(L.values) == 1) {
    names(L.values) <- "L"
  }

  if(is.matrix(x))
    x <- t(x)
  if(is.matrix(x.offsets))
    x.offsets <- t(x.offsets)

  fit.call$x.offsets <- x.offsets
  fit.call$me.offsets <- me.offsets
  fit.call$minp.offset <- minp.offset
  fit.call$maxp.offset <- maxp.offset
  fit.call$zmaxp <- zmaxp
  fit.call$zminp <- zminp

  sdmat <- t(sdmat)
  rownames(sdmat) <- rownames(x)
  sdmat <- sdmat[,pred.with.me, drop = FALSE]

  structure(list(coefficients = beta,
                 Lo.coefs = deltao,
                 L.coefs = delta,
                 me.coefs = if (!control$fixme) c(gamma.int, gamma),
                 mu = mu,
                 fitted.values = mu * weights,
                 Lo.values = Lovalues,
                 L.values = L.values,
                 me.mat = sdmat, x.with.me = x.with.me,
                 beta.with.me = beta.with.me, pred.with.me = pred.with.me,
                 logLike = logLike, aic = aic, bic = bic,
                 deviance = deviance, null.deviance = null.deviance,
                 residual.deviance = residual.deviance,
                 df.residual = df.residual, df.null = df.null,
                 nobs = nobs, p = p, qo = qo, q = q, r = r, rank = nparams, ssize = ssize,
                 weights = prior.weights, sample.weights = sample.weights,
                 intercepts = intercepts, order.intercepts = "separate",
                 me.intercepts = me.intercepts, Rmat = Rmat, dispersion = dispersion,
                 hessian = hessian, start = theta0,
                 link = link, linkinv = linkinv, melinkinv = melinkinv,
                 fit.call = fit.call, control = control,
                 converged = converged, iter = iter, optres = optres,
                 nlikefun = nlikefun),
            class = c('mrb.fit', 'memrb.fit'))
}
