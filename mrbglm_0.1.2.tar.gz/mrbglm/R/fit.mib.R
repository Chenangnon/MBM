#' Fit a Multiplicative Risk Binomial Regression Model
#'
#' Add an argument to specify the sign of each slope
#'
#' USE A GRID SEARCH on \eqn{delta} a PRE-SPECIFIED INTERVAL \eqn{I = [a, b]} TO
#' FIND \eqn{\hat{delta}} (supply each grid value as an initial value)
#'
#'
#' The function \code{fit.mrb} is the workhorse for \link{glm.mrb}.
#' Not a user level routine, but should be used instead of \link{glm.mrb}
#' in a simulation framework where \code{fit.mrb} can reduce computation time.
#'
#' @param y a vector of observations of length \code{n}.
#'
#' @param x a design matrix of dimension \eqn{n * p}, covariates determining
#'  the probability to observe \code{y = 1}. The overall probability is the
#'  product of this probability, and a multiplicative intercept determined
#'  by \code{zmaxp}.
#'
#' @param contract_eta numeric vector,
#'
#' @param weights an optional numeric vector of 'sizes' giving the number of
#' trials which resulted in the number of success in each entry of \code{y}.
#' Defaults to \code{1} which is interpreted as a vector of all ones.
#'
#' @param sample.weights an optional numeric vector giving the weights of each
#' observation (row) in the data to be used for fitting. See argument definition
#' and the section 'Details' of \link{glm.mrb} for details.
#'
#' @param intercept logical vector, should an intercept be included for each predictor?
#' A unique value is interpreted as the same for all terms that can have an
#' individual intercept (see 'Details' in \link{glm.mrb}).
#'
#' @param zminp design matrix of dimension \eqn{n * qo} that determines the
#' minimum success probability for responses in \code{y}.
#'
#' @param zmaxp a design matrix of dimension \eqn{n * q} that determines the
#' multiplicative intercept, the maximum probability of success for \code{y}.
#'
#' @param zme a design matrix of dimension \eqn{n * r} that determines the
#' standard deviation of the normal mixing distribution (i.e. for Bergson
#' measurement errors).
#'
#' @param minp.offset,maxp.offset,me.offsets numeric vectors of offsets for the linear
#' predictor corresponding to \code{zminp}, \code{zmaxp}, and \code{zme}.
#' See \link{glm} for a description of what is an \code{maxp.offset}.
#'
#' @param link an object of class \code{link}, giving details of the link
#' function to be used for the fit.
#'
# @param linkfun,linkinv function, the mapping (inverse link function) from each linear
# predictor to the corresponding probability, and vise-versa (link function).
#'
#' @param start a numeric \code{p}-vector of starting values for the
#' coefficients of variables in \code{x}; or a \code{p+q}-vector of starting
#' values for the coefficients of variables in \code{x} and \code{zmaxp}.
#'
#' @param mustart,etastart arguments passed to \link{glm.fit} for initialization
#' when \code{start} is missing or \code{NULL}. See \link{glm.fit} for a
#' description. Ignored when \code{start} is not missing and not \code{NULL}.
#'
#' @param Lostart,deltaostart numeric vectors, \code{Lostart} contains starting values
#' for minimum probability values divided by the maximum. \code{deltaostart} contains the
#' coefficients of variables in \code{zminp}. Ignored if these are already
#' available in \code{start}.
#'
#' @param Lstart,deltastart numeric vectors, \code{Lostart} contains starting values
#' for minimum probability values. \code{deltastart} contains the
#' coefficients of variables in \code{zmaxp}. Ignored if these are already
#' available in \code{start}.
#'
#' @param mestart,gammastart numeric vectors, \code{mestart} contains starting
#' values of the standard deviation of the normal mixing (measurement error)
#' distribution. \code{gammastart} contains starting values of the coefficients
#' of variables in \code{zme}.
#'
#' @param me.intercepts logical vector, should an intercept be included for each
#' term in \code{me.formula}? A unique value is interpreted as the same for all
#' terms in \code{me.formula}.
#'
#' @param x.with.me logical vector, indicating numerical predictors with
#' measurement error terms. The number of \code{TRUE} values in \code{x.with.me}
#' must match the number of measurement error terms in \code{me.formula}.
#'
#' @param offset a vector of offsets for the linear predictor defined by in
#' \code{formula}. An offset here has the same meaning as an \link{offset}
#' for a \link{glm}.
#'
#' @param control a list of parameters for controlling the fitting process.
#' This is passed to \link{control.mrb}.
#'
#' @param ... further arguments passed to or from other methods.
#'
#' @export fit.mib
#' @import stats
#'
#' @details The function defines an objective function (e.g. negative log-likelihood
#' function, and residual sum of squares) and call a minimizer (e.g. \link{optim})
#' to minimize the objective function. A attempt to find starting values for all
#' model parameters is also optionnaly performed before the minimization.
#'
#' @return An object of class \code{"mrbglm.fit"}, that is a list with components:
#'
#' \code{coefficients, L.coefs, fitted.values, L.values, logLike, aic,}
#' \code{deviance, null.deviance, residual.deviance, df.residual, df.null,}
#' \code{p, q, rank, weights, intercept, Rmat, hessian, start, linkinv,}
#' \code{control, converged, iter}.
#'
#' See section "Value" in \link{glm.mrb} for descriptions of the list components.
#'
#' @seealso \link{glm.mib}.
#'
# @examples
# set.seed(167)
# mibdata = sim.mib (beta = c(1, 2, -2),
#                    x = cbind(x1 = runif(1000, min = -10, max = 5),
#                              x2 = runif(1000, min = -5, max = 10)),
#                    delta = qlogis(.66))$data
#
# head (mibdata)
# # Including only a multiplicative intercept MODEL
# MIBfit1 = fit.mib (y = mibdata$y, x = cbind(mibdata$x1, mibdata$x2))
# MIBfit1
#
# me.offsets
# USE A GRID SEARCH on \eqn{delta} a PRE-SPECIFIED INTERVAL I = [a, b]

fit.mib <- function (y, weights = 1, sample.weights = 1,
                    x, contract_eta,
                    intercept = NULL, offset = NULL,
                    x.with.me = NULL, zme = NULL,
                    me.intercepts = FALSE, me.offsets = 0,
                    zminp = NULL, minp.offset = 0,
                    zmaxp = 1, maxp.offset = 0,
                    link = logit(),
                    start = NULL,
                    mustart = NULL, etastart = NULL,
                    mestart = NULL, gammastart = NULL,
                    Lostart = NULL, deltaostart = NULL,
                    Lstart = NULL, deltastart = NULL,
                    control = list(), ...) {

  # zme and x.with.me
  if (!is.null(zme)) {
    r <- ncol(zme)
    if (r == 0)
      zme <- NULL
    else {
      if(r > ncol(x))
        stop("inconsistent arguments 'x' and 'zme': more measurement error covariates than regression covariates!")
      if(is.null(x.with.me))
        x.with.me <- rep(TRUE, r)
      else if (sum(x.with.me) != r)
        stop("inconsistent arguments 'zme' and 'x.with.me'")
    }
  }

  # me.offsets
  if (is.null(me.offsets))
    me.offsets <- 0
  else {
    stopifnot(is.numeric(me.offsets))
    if (all(me.offsets == 0))
      me.offsets <- 0
  }

  # Call "fit.mrb.be" if any Bergeson error variance is available
  if (any(c(!is.null(zme), !is.null(mestart), !all(me.offsets == 0)))) {

    # indicator of predictors with me (pred.with.me)
    if (all(me.offsets == 0)) {
      x.with.me.offsets <- rep(FALSE, nbcov)
    }
    else if (length(me.offsets) == 1) {
      x.with.me.offsets <- rep(TRUE, nbcov)
    }
    else {
      x.with.me.offsets <- colSums(as.matrix(abs(me.offsets))) > 0
    }
    pred.with.me <- x.with.me.offsets

    if (!is.null(x.with.me))
      pred.with.me <- pred.with.me | x.with.me

    if (is.matrix(mestart)) {
      x.with.mestart <- colSums(as.matrix(abs(mestart))) > 0

      pred.with.me <- pred.with.me | x.with.mestart
    }

    # gammastart needs 'zme' to be useful
    return(fit.me.mib (y = y, weights = weights, sample.weights = sample.weights,
                       x = x, contract_eta = contract_eta,
                       intercept = intercept, offset = offset,
                       x.with.me = x.with.me, zme = zme, pred.with.me = pred.with.me,
                       me.intercepts = me.intercepts, me.offsets = me.offsets,
                       zminp = zminp, minp.offset = minp.offset,
                       zmaxp = zmaxp, maxp.offset = maxp.offset,
                       link = link, start = start,
                       mustart = mustart, etastart = etastart,
                       mestart = mestart, gammastart = gammastart,
                       Lostart = Lostart, deltaostart = deltaostart,
                       Lstart = Lstart, deltastart = deltastart,
                       control = control, ...))
  }

  ### Save the call
  fit.call <- match.call()

  ### Link functions
  linkfun <- link$linkfun
  linkinv <- link$linkinv

  ### Dimensions and weights
  eval(mib.dim())
  pi <- sum(intercept)

  ### Initialization
  eval(initialize.mib.fit())

  ### Negative log-likelihood function
  eval(make.mib.nlikefun())

  ### Optimization
  nparams <- p + pi + qo * (!control$fixLo) + q * (!control$fixL)
  theta0 <- start
  start <- start[1:nparams]

  ### Bounds if required
  if (identical(control$slope.signs, "positive")) {

  }

  if (!is.null(control$slope.signs)) {
    if (identical(control$slope.signs, "positive")) {
      start[(pi + 1):(pi + p)] <- pmax(1e-10, start[(pi + 1):(pi + p)])
      lowerb <- rep(-Inf, nparams)
      lowerb[(pi + 1):(pi + p)] <- 0
      upperb <- Inf
    }
    else {
      start[(pi + 1):(pi + p)] <- pmin(-1e-10, start[(pi + 1):(pi + p)])
      lowerb <- -Inf
      upperb <- rep(Inf, nparams)
      upperb[(pi + 1):(pi + p)] <- 0
    }
  }
  else {
    lowerb = -Inf
    upperb = Inf
  }

  vmethods <- c("Nelder-Mead", "BFGS", "CG", "L-BFGS-B", "SANN", "Brent")
  vmethod <- control$method %in% vmethods
  optres0 <- NULL

  if (length(control$method) > 1 | any(!vmethod)) {

    optres0 <- optim.mrb (start = start,
                          nb.betas = pi + p,
                          nlikefun = nlikefun,
                          control = control,
                          lower = lowerb,
                          upper = upperb)

    optres <- optres0$finalresult
    control$method <- unique(c(control$final.method, control$method))
    vmethod <- control$method %in% vmethods

    if (any(vmethod)) {
      control$method <- control$method[vmethod][1]
    }
    else
      control$method <- "Nelder-Mead"
  }
  else {
    optres <- catch.conditions({
      stats::optim(par = start, fn = nlikefun,
                   method = control$method,
                   control = list(maxit = control$maxit,
                                  reltol = control$epsilon),
                   lower = lowerb,
                   upper = upperb,
                   hessian = TRUE)
    })$value
  }

  pbeta <- pi + p
  if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
    optres <- catch.conditions({
      stats::optim(par = start, fn = nlikefun,
                   method = 'Nelder-Mead',
                   control = list(maxit = 3 * control$maxit,
                                  reltol = control$epsilon),
                   lower = lowerb,
                   upper = upperb)
    })$value
    if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
      if (!control$fixL) {
        start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(deltastart + 1, q)
        optres <- catch.conditions({
          stats::optim(par = start, fn = nlikefun,
                       method = control$method,
                       control = list(maxit = control$maxit,
                                      reltol = control$epsilon),
                       lower = lowerb,
                       upper = upperb,
                       hessian = TRUE)
        })$value

        if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
          start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(deltastart + 2, q)
          optres <- catch.conditions({
            stats::optim(par = start, fn = nlikefun,
                         method = control$method,
                         control = list(maxit = control$maxit,
                                        reltol = control$epsilon),
                         lower = lowerb,
                         upper = upperb,
                         hessian = TRUE)
          })$value
        }

        if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
          start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(-1, q)
          optres <- catch.conditions({
            stats::optim(par = start, fn = nlikefun,
                         method = control$method,
                         control = list(maxit = control$maxit,
                                        reltol = control$epsilon),
                         lower = lowerb,
                         upper = upperb,
                         hessian = TRUE)
          })$value
        }

        if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
          start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(-2, q)
          optres <- catch.conditions({
            stats::optim(par = start, fn = nlikefun,
                         method = control$method,
                         control = list(maxit = control$maxit,
                                        reltol = control$epsilon),
                         lower = lowerb,
                         upper = upperb,
                         hessian = TRUE)
          })$value
        }
      }

      if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
        stop(paste0("fitting failled: ",
                    optres,
                    ". Try another optimizer (see '?control.mrb')"))
      }
    }
    else {
      optres <- catch.conditions({
        stats::optim(par = optres$par, fn = nlikefun,
                     method = control$method,
                     control = list(maxit = control$maxit,
                                    reltol = control$epsilon),
                     lower = lowerb,
                     upper = upperb,
                     hessian = TRUE)
      })$value
    }
  }
  else if (any(colSums(optres$hessian[1:pbeta, 1:pbeta] == 0) == pbeta) & !control$fixL) {
    start1 <- start
    start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart + 1
    optres1 <- catch.conditions({
      stats::optim(par = start1, fn = nlikefun,
                   method = control$method,
                   control = list(maxit = control$maxit,
                                  reltol = control$epsilon),
                   lower = lowerb,
                   upper = upperb,
                   hessian = TRUE)
    })$value
    if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
      invalid1 <- TRUE
    }
    else {
      invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
      if (invalid1) {
        start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart + 2
        optres1 <- catch.conditions({
          stats::optim(par = start1, fn = nlikefun,
                       method = control$method,
                       control = list(maxit = control$maxit,
                                      reltol = control$epsilon),
                       lower = lowerb,
                       upper = upperb,
                       hessian = TRUE)
        })$value
        if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
          invalid1 <- TRUE
        }
        else {
          invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
        }
      }
    }
    if (invalid1) {
      start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart - 1
      optres1 <- catch.conditions({
        stats::optim(par = start1, fn = nlikefun,
                     method = control$method,
                     control = list(maxit = control$maxit,
                                    reltol = control$epsilon),
                     lower = lowerb,
                     upper = upperb,
                     hessian = TRUE)
      })$value
      if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
        invalid1 <- TRUE
      }
      else {
        invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
        if (invalid1) {
          start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart - 2
          optres1 <- catch.conditions({
            stats::optim(par = start1, fn = nlikefun,
                         method = control$method,
                         control = list(maxit = control$maxit,
                                        reltol = control$epsilon),
                         lower = lowerb,
                         upper = upperb,
                         hessian = TRUE)
          })$value
          if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
            invalid1 <- TRUE
          }
          else {
            invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
          }
        }
      }
    }
    if (!invalid1) {
      optres <- optres1
    }
  }

  if (!is.null(optres0)) {
    optres0$finalresult <- optres
    optres$details <- optres0
  }

  iter <- optres$counts
  converged <- optres$convergence == 0
  if (length(optres$convergence) == 0) {
    optres$convergence <- NA
    converged <- FALSE
    attr(converged, 'code') <- NA
  }
  else
    attr(converged, 'code') <- conv.optim(optres$convergence)
  attr(converged, 'message') <- optres$message

  # Extracting basic results
  theta <- optres$par
  if (intercept) {
    beta <- theta[1:pbeta]
    beta.int <- theta[1]
    beta.x <- theta[2:pbeta]
    eta <- offset + beta.int + c(x %*% beta.x)
    if (!control$fixLo)
      deltao <- theta[(pbeta + 1):(pbeta + qo)]
    if (!control$fixL)
      delta <- theta[(pbeta + qo + 1):(pbeta + qo + q)]
  }
  else {
    beta <- theta[1:p]
    beta.int <- NULL
    eta <- offset + c(x %*% beta)
    if (!control$fixLo)
      deltao <- theta[(p+1):(p+qo)]
    if (!control$fixL)
      delta <- theta[(p+qo+1):(p+qo+q)]
  }
  if (!control$fixLo)
    Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
  if (!control$fixL)
    logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
  mu <- exp(linkinv(eta, log.p = TRUE))
  mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) * mu)
  validmu <- is.finite(mu) & (mu > 0 & mu < 1)

  ### Degrees of freedom
  df.residual <- ssize - nparams
  df.null <- ssize - 1
  if (!all(validmu) & length(weights) > 1)
    weights <- weights[validmu]
  if (identical(control$criterion, "NLS")) {
    dispersion <- sum((y[validmu] - mu[validmu])^2) / df.residual
  }
  else {
    dispersion <- 1
  }

  residual.deviance <- numeric(nobs) + NA
  switch(control$criterion,
         NLS = {
           residual.deviance[validmu] <- - 2 * stats::dnorm(y[validmu],
                                                            mean = mu[validmu] * weights,
                                                            sd = sqrt(dispersion),
                                                            log = TRUE) *
             (if (length(sample.weights) > 1) sample.weights[validmu] else sample.weights)
         },
         ML = {
           residual.deviance[validmu] <- - 2 * stats::dbinom(y[validmu], size = weights,
                                                             prob = mu[validmu],
                                                             log = TRUE) *
             (if (length(sample.weights) > 1) sample.weights[validmu] else sample.weights)
         })

  deviance <- sum(residual.deviance[validmu])
  logLike <- - .5 * deviance
  aic <- deviance + 2 * nparams
  bic <- deviance + log(ssize) * nparams

  ### Covariance matrix estimate
  hessian <- optres$hessian
  Rmat <- catch.conditions(solve(optres$hessian))$value
  if (any(class(Rmat) %in% c("simpleError", "error", "condition", "try-error"))) {
    if (all(optres$hessian == 0))
      warning("algorithm did not converge: over-parameterized model -- no covariance matrix estimate available")
    else if (any(colSums(abs(optres$hessian[1:pbeta, 1:pbeta])) == 0))
      warning("algorithm did not converge: no covariance matrix estimate available")
    else {
      Rmato <- catch.conditions(solve(optres$hessian[1:pbeta, 1:pbeta]))$value
      if (any(class(Rmato) %in% c("simpleError", "error", "condition", "try-error"))) {
        warning("algorithm did not converge: no covariance matrix estimate available")
      }
      else {
        Rmat <- matrix(0, nrow = nparams, ncol = nparams)
        Rmat[1:pbeta, 1:pbeta] <- Rmato
        warning("over-parameterized model? -- 0 or NA in covariance matrix estimate")
        Rmat <- Rmat * dispersion
        dimnames(Rmat) <- list(names(start), names(start))
      }
    }
  }
  else {
    Rmat <- Rmat * dispersion
    dimnames(Rmat) <- list(names(start), names(start))
  }

  ### Computing the null deviance (account for the criterion)
  switch(control$criterion,
         NLS = {
           nlike.null.mrb <- function(beta0) {
             mu <- exp(linkinv(beta0, log.p = TRUE)) # + logLvalues

             res <- stats::dnorm(y[validmu], mean = mu * weights,
                                 sd = sqrt(dispersion), log = TRUE)
             -sum(res * (if (length(sample.weights) > 1) sample.weights[validmu] else sample.weights),
                  na.rm = TRUE)
           }
         },
         ML = {
           nlike.null.mrb <- function(beta0) {
             mu <- exp(linkinv(beta0, log.p = TRUE)) # + logLvalues
             res <- stats::dbinom(y[validmu], size = weights, prob = mu, log = TRUE)
             -sum(res * (if (length(sample.weights) > 1) sample.weights[validmu] else sample.weights), na.rm = TRUE)
           }
         })
  null.method <- control$method
  if (!(null.method %in% c("Nelder-Mead", "BFGS", "CG", "L-BFGS-B", "SANN", "Brent")))
    null.method <- "Nelder-Mead"

  null.deviance <- catch.conditions({
    stats::optim(par = linkfun (mean(y/weights, na.rm = TRUE)), fn = nlike.null.mrb,
                 method = null.method,
                 control = list(maxit = control$maxit,
                                reltol = control$epsilon))
  })
  if (any(class(null.deviance$value) %in% c("simpleError", "error", "condition", "try-error"))) {
    warning(paste0("fitting to compute the null deviance failled: ",
                   null.deviance$value))
    null.deviance <- NA
    beta0 <- NA
  }
  else {
    beta0 <- null.deviance$value$par
    null.deviance <- 2 * null.deviance$value$value
  }

  ### Computing the residual deviance (conditional on L.values)
  ### Computing the residual deviance (conditional on L.values)
  #if (!is.na(null.deviance)) {
  #mu.null <- exp(logLvalues + linkinv(beta0, log.p = TRUE))
  #validmu <- is.finite(mu.null) & (mu.null > 0 & mu.null < 1)
  #if (!all(validmu) & length(weights) > 1)
  # weights <- weights[validmu]

  if (!is.null(zminp)) {
    if(is.null(zonames <- names(zminp))) {
      if ((zolen <- length(zminp)) == 1) {
        names(Lovalues) <- "Lo"
      }
      else {
        if (is.matrix(zminp))
          names(Lovalues) <- paste0("Lo", 1:NCOL(zminp))
        else
          names(Lovalues) <- paste0("Lo", 1:zolen)
      }
    }
    else {
      names(Lovalues) <- zonames
    }
  }
  else if (length(Lovalues) == 1) {
    names(Lovalues) <- "Lo"
  }

  L.values <- exp(logLvalues)
  if (!is.null(zmaxp)) {
    if(is.null(znames <- names(zmaxp))) {
      if ((zlen <- length(zmaxp)) == 1) {
        names(L.values) <- "L"
      }
      else {
        if (is.matrix(zmaxp))
          names(L.values) <- paste0("L", 1:NCOL(zmaxp))
        else
          names(L.values) <- paste0("L", 1:zlen)
      }
    }
    else {
      names(L.values) <- znames
    }
  }
  else if (length(L.values) == 1) {
    names(L.values) <- "L"
  }

  fit.call$offset <- offset
  fit.call$minp.offset <- minp.offset
  fit.call$maxp.offset <- maxp.offset
  fit.call$zmaxp <- zmaxp
  fit.call$zminp <- zminp

  structure(list(coefficients = beta,
                 Lo.coefs = deltao,
                 L.coefs = delta,
                 mu = mu, fitted.values = mu * weights,
                 Lo.values = Lovalues,
                 L.values = L.values,
                 logLike = logLike, aic = aic, bic = bic,
                 deviance = deviance, null.deviance = null.deviance,
                 residual.deviance = residual.deviance,
                 df.residual = df.residual, df.null = df.null,
                 nobs = nobs, p = p, qo = qo, q = q, r = 0, rank = nparams, ssize = ssize,
                 weights = prior.weights, sample.weights = sample.weights,
                 intercept = intercept,
                 Rmat = Rmat, dispersion = dispersion, hessian = hessian,
                 start = theta0, link = link,
                 linkinv = linkinv,
                 fit.call = fit.call, control = control,
                 converged = converged, iter = iter, optres = optres,
                 nlikefun = nlikefun),
            class = 'mib.fit')
}

conv.optim <- function(code) {
  paste(code, ": ",
        switch(as.character(code),
               `1` = "the iteration limit 'maxit' had been reached",
               `10` = "degeneracy of the Nelder-Mead simplex",
               `51` = "warning from the 'L-BFGS-B' method",
               `52` = "error from the 'L-BFGS-B' method",
               "successful completion"))
}
