#'
#' Fit a Multiplicative Intercept Binomial Regression Model
#'
#' This function fits a (measurement error) multiplicative intercept binomial
#' regression model specified by a symbolic description of linear predictors
#' and a description of the link function.
#'
#' @param formula an object of class \link{formula} (or one that can be coerced
#' to that class): a symbolic description of the model to be fitted.
#' The details of model specification are given under ‘Details’.
#'
#' @param link a character giving the name of the link function to be used.
#' Alternatively, \code{link} can be an object of class \code{"link"}, or a
#' function such that \code{link()} returns an object of class \code{link}.
#' Defaults to the \code{logit} link.
#'
#' @param x.with.me logical vector, indicating numerical predictors with
#' measurement error terms. The number of \code{TRUE} values in \code{x.with.me}
#' must match the number of measurement error terms in \code{me.formula}.
#'
#' @param me.formula optional one sided \link{formula} object specifying covariates in
#' the measurement errors models for numerical predictors in \code{formula}.
#' Columns corresponding to terms in \code{me.formula} in \code{data} (or in
#' the environment from which \code{glm.mib} is called if \code{data} is not
#' specified) are assumed to be non-negative (this is ensured by passing
#' these columns, if any, to \link{abs}).
#'
#' @param me.intercepts logical vector, should an intercept be included for each
#' term in \code{me.formula}? A unique value is interpreted as the same for all
#' terms in \code{me.formula}.
#'
#' @param minp.formula,maxp.formula optional one sided \link{formula} objects specifying
#' covariates to be included in the linear predictor of the minimal/maximal
#' success probability of the binomial response variable. The default formulas
#' assume that the minimum success probability is given by its offset
#' \code{minp.offset} (zero if \code{minp.offset = ~-1}, the default), and the
#' maximum success probability is given by a constant in \code{(0, 1)} to be
#' estimated and possibly an offset \code{maxp.offset} (just a constant if
#' \code{maxp.offset = ~-1}). To avoid estimating a maximum success probability
#' (fix this probability to one), set \code{maxp.formula = ~ -1}. The maximum
#' success probability can also be set to an arbitrary value \code{L} by setting
#' the argument \code{Lstart = L}, and including a named element \code{fixL}
#' in the argument \code{control} (e.g. \code{control = list(fixL = TRUE)}).
#'
#' For a model without measurement error for any predictor, any link accepted
#' by the \link[stats]{binomial} family for \link[stats]{glm} is also accepted
#' by \code{glm.mib}. When measurement errors are present, only \code{logit}
#' and \code{probit} links are currently available.
#'
#' @param data,weights,subset,na.action,etastart,mustart,offset,model,x,y same as the
#' corresponding arguments of the function \code{glm}.
#' See \link{glm} for descriptions.
#'
#' @param sample.weights an optional one sided \link{formula} object specifying
#' the weights of each observation (row) in the data to be used for fitting.
#' See "Details" for a description of \code{sample.weights}.
#'
#' @param start starting values for the parameters in the linear predictors.
#' Note that unlike for the \code{glm} function, we here have many linear
#' predictors. See "Details" for a description of \code{start}.
#'
#' @param mestart numeric vector/matrix, starting values for standard deviations
#' of predictors with measurement errors. A unique value is replicated to the correct
#' dimension of measurement errors in the model.
#'
#' @param gammastart numeric vectors of coefficients of variables in
#' \code{me.formula} with corresponding intercepts, if any. Ignored if this is
#' already available in \code{start}.
#'
#' @param Lostart,Lstart  numeric vectors, starting values for limit success
#' probability value(s) (minimum/maximum) for the response variable, ignored if
#' \code{deltaostart}/\code{deltastart} is specified.
#'
#' @param deltaostart,deltastart numeric vectors of coefficients of variables in
#' \code{minp.formula} and \code{maxp.formula}, respectively. Ignored if these
#' are already available in \code{start}.
#'
#' @param x.with.me.offsets logical vector, should a measurement error offset
#' term be included for each numerical predictor in \code{formula}? The number
#' of \code{TRUE} values in \code{x.with.me.offsets} must match the number of
#' offsets terms in \code{me.offsets}.
#'
#' @param me.offsets an optional one sided \link{formula} object specifying
#' columns in \code{data} (or in the environment from which \code{glm.mib} is
#' called) to be used as measurement error (standard deviations) offsets for
#' numerical predictors indicated in \code{x.with.me.offsets}.
#'
#' @param minp.offset,maxp.offset optional one sided \link{formula} objects
#' specifying columns in \code{data} (or in the environment from which
#' \code{glm.mib} is called) to be used as offsets in the linear predictor for
#' the minimum/maximum success probability of the response variable.
#'
#' @param control a list of parameters for controlling the fitting process.
#' This is passed to \link{fit.mib}, which then passes it to \link{control.mib}.
#'
#' @param method the method to be used in fitting the model. The default method
#' is "fit.mib" which use the \link{optim} function to minimize the negative
#' log-likelihood function of model parameters. This minimizer can be modified
#' through the \code{control} argument which also has a \code{method} list
#' element (see \link{control.mib}).
#'
#' A user defined fitting function can be provided: the function must take the
#' same named arguments as \link{fit.mib}, and return a list with the same named
#' elements as \link{fit.mib}.
#'
#' @param ... Further arguments passed to or from other methods.
#'
#' @details See \link{sim.mib} for a description of a Multiplicative Intercept
#' Binomial Regression Model, and how it compares to the classical binomial
#' \link{glm}. Measurement error terms arise from assuming that the
#' observed/measured numerical covariates in \code{formula} are error-prone.
#'
#' A typical model specification has the form \code{response ~ terms}
#' where \code{response} is the binomial response vector and \code{terms} is a
#' series of terms which specifies each a linear predictor for the success
#' probability of the response. As for a classical \code{binomial} Generalized
#' Linear Model (GLM), the response can also be specified as a \link{factor}
#' (when the first level denotes failure and all others success) or as a
#' two-column matrix with the columns giving the numbers of successes and
#' failures. A terms specification of the form \code{first + second} indicates
#' all the terms in \code{first} together with all the terms in \code{second}
#' with any duplicates removed.
#'
#' Unlike \link{glm.mrb}, the presence or absence of an (implicit) intercept term
#' in \code{formula} is NOT ignored for numerical predictors. Indeed, a terms
#' specification such as \code{first + second} (\code{first} and \code{second}
#' being numerical co-variables) is equivalent to \code{1 + first + second}
#' (and specifies an intercept and the predictors \code{first} and \code{second}).
#' A terms specification such as \code{0 + first + second} or \code{-1 + first + second}
#' indicates that there is no intercept term, as in the usual \link{glm} framework.
#'
#' Note that an interaction term, for instance from specifications such as
#' \code{first:second} or \code{first * second} (the last is the same as
#' \code{first + second + first:second}), or a higher order term, for instance
#' \code{I(first^2)} in \code{y ~ first + second + I(first^2)} is treated
#' like an independent variable as in a classical \code{binomial} GLM. The
#' appropriate interpretation of such terms beyond mere signs remains a
#' challenge. For more details on the formula interface, see for instance
#' \link{glm}.
#'
#' For the binomial family, the argument \code{weights} offers an optional way
#' to specify for the \code{i}th data point (row of \code{data}) the number of trials
#' in the experiment(s) that generated the \code{i}th response value. Indeed, for
#' a response value \eqn{y_i}, the corresponding weight \eqn{w_i} must be equal to
#' or larger than \eqn{y_i} (i.e. (\eqn{y_i \in \{0, 1, \cdots, w_i\}})).
#' If \code{weights} is not specified, it is assumed that \eqn{w_i = 1}, and
#' \eqn{y_i} is Bernoulli distributed (\eqn{y_i \in \{0, 1\}}).
#' An alternative way to the use of the argument \code{weights} is specifying a
#' two column matrix as response in the argument \code{formula}, in which case,
#' the argument \code{weights} is ignored. This interpretation of the argument
#' \code{weights} is the same used by the \link{glm} function with the
#' \link{binomial} family.
#'
#' The argument \code{sample.weights} can be used to specify sampling weights
#' for observations in \code{data}. The column indexed by the formula
#' \code{sample.weights} must contain non negative reals. These weights
#' are re-scaled to sum up to the number of rows of \code{data}, and used to
#' weight sample contributions to the log-likelihood function.
#' These weights can for instance represent sampling effort on each experimental,
#' unit, or the precision (inverse variance) of the recorded response value
#' (but not appropriate for errors in covariates). No that the sampling weights
#' specified by \code{sample.weights} play the same role as the argument
#' \code{weights} of the function \link{lm} for fitting linear models. But as
#' stated above, for the binomial glm as fitted by \link{glm}, the argument
#' \code{weights} refers to the number of trials in binomial experiments.
#'
#' To handle errors in regression covariates given in \code{formula}, consider
#' adding measurement error terms via \code{me.offset} if the standard deviations
#' of these errors are known. If the measurement errors are believed to come from
#' a linear measurement error model with positive coefficients and measurement
#' covariates, consider specifying these covariates as \code{me.formula} (use
#' \code{x.with.me} to indicate which numerical predictors in \code{formula} are
#' error prone). Also consider using \code{me.intercepts} to optionally add a
#' positive constant term to each linear measurement error model.
#'
#' The argument \code{start} can be used to supply starting values for the
#' intercept and slopes of predictors/terms specified in \code{formula}. If
#' \code{beta} denotes the vector of intercept and regression slopes,
#' \code{start} must have one of the forms:
#' \describe{
#' \item{\code{start = beta}, or}{}
#' \item{}{\code{ = [beta, deltaostart, deltastart]}, or}
#' \item{}{\code{ = [beta, deltaostart, deltastart, gammastart]}.}
#'}
#' The function \link{fit.mib} is the workhorse function: it is not normally
#' called directly but can be more efficient where the response vector and
#' design matrices have already been calculated. Note that these arguments
#' are not checked for class or size, and may run into error if not appropriate.
#'
#' @return An object of class inheriting from \code{"mibglm"} which inherits from
#' the classes \code{"mibglm.fit"} and \code{"memib.fit"}. See later in this
#' section. If a non-standard  method is used, the object will also inherit
#' from the class (if any) returned by that function.
#'
#' As for a classical \code{glm} object, \code{"mrbglm"} class objects have
#' methods \link{print} and \link{summary} to provide or print a summary of
#' the results (see \link{print.mrbglm} and \link{summary.mrbglm}).
# The function \link{anova} can likewise be used to produce an analysis of
# deviance table (see \link{anova.mrbglm}).
#' \code{"mrbglm"} class objects also have method \link{predict}
#' (\link{predict.mrbglm}).
#'
# The function \link{step} has also been extended for the class \code{"mrbglm"}
# and can be used to select predictors based on a criterion such as \code{AIC}
# or some related quantities.
#'
#' An object of class "mrbglm" is a list containing at least the following
#' components:
#' \item{coefficients}{a named vector of regression coefficients (excluding the
#' coefficients for the minimum/maximum success probability of the response, and
#' coefficients of the measurement error model, if any.)}
#'
#' \item{Lo.coefs,L.coefs}{coefficients for the minimum/maximum success
#' probability of the binary response.}
#'
#' \item{Lo.values,L.values}{minimum/maximum succes probability of the binary
#' response variable.}
#'
#' \item{mu,fitted.values}{the fitted probabilities/mean values, obtained by
#' transforming the linear predictors by the inverse of the link function.}
#'
#' \item{rank}{the numeric rank of the fitted model.}
#'
#' \item{link}{the \code{link} used for fitting (object of class \code{"link"}).}
#'
#' \item{logLike}{the maximized log-likelihood.}
#'
#' \item{deviance}{minus twice the maximized log-likelihood (this ensures that
#' a saturated model has deviance zero).}
#'
#' \item{aic,bic}{Akaike's Information Criterion, minus twice the maximized
#' log-likelihood plus twice the number of parameters (\code{aic}), and Schwarz's
#' Bayesian Information Criterion (\code{bic}) where the factor \code{2} in
#' \code{aic} is replaced by \eqn{\log{ssize}}.}
#'
#' \item{null.deviance}{the deviance for the null model, comparable with deviance.
#' Note that unlike in common GLMs fitted with \link{glm}, the \code{null.deviance}
#' in the MRB model does not account for any offset, since an offset  is closely
#' associated with the corresponding predictor, dropping the predictor means
#' dropping its offset as well.}
#'
#' \item{residual.deviance}{the deviance value for individual observations
#' (it sums to the \code{deviance} component).}
#'
#' \item{iter}{a two-element integer vector giving the number of calls to the
#' negative log-likelihood function, and to its gradient, respectively}
#'
#' \item{converged}{logical, was the fitting algorithm judged to have converged?
#' For the default fitting method \link{fit.mib}, any convergence message is also
#' returned as attribute to \code{converged}.}
#'
#' \item{weights}{the weights initially supplied, \code{1} (interpreted as a
#' vector of ones) if none was supplied.}
#'
#' \item{df.residual}{The residual degrees of freedom.}
#'
#' \item{df.null}{the residual degrees of freedom for the null model.}
#'
#' \item{p,qo,q,r,rank}{\code{p}, \code{qo}, \code{q} and \code{r} are numbers
#' of terms in the linear predictors from \code{formula}, \code{minp.formula},
#' \code{maxp.formula}, and \code{me.formula}. \code{rank} is the total number
#' of parameters estimated.}
#'
#' \item{nobs,ssize}{\code{nobs} in the number of observations. \code{ssize} is
#' the maximum of the number of non-missing observations and the sum of supplied
#' weights.}
#'
#' \item{hessian}{the hessian matrix of the negative log-likelihood function
#' evaluated at the maximum likelihood estimate.}
#'
#' \item{Rmat}{covariance matrix estimate for all estimated parameters; or the
#' error message issued by \link{solve} when trying to compute the inverse of
#' the hessian of the negative log-likelihood function evaluated at the maximum
#' likelihood estimate.}
#'
#' \item{start}{the starting parameter value used for negative log-likelihood
#' minimization.}
#'
#' \item{control}{the value of the control argument used.}
#'
#' \item{method}{the name of the fitter function used (when provided as a
#' \link{character} string to \code{glm.mib()}) or the fitter \code{function}
#' (when provided as that).}
#'
#' \item{x}{if requested (defaults to \code{FALSE}) the matrix of regressors
#' (\code{x}) used.}
#'
#' \item{y}{if requested (the default) the \code{y} vector used.}
#'
#' \item{call,fit.cal}{the matched call to \code{glm.mib}, and the matched call
#' to the fitting
#' function (indexed by) \code{method}.}
#'
#' \item{formula,me.formula}{the supplied formulas.}
#'
#' \item{minp.formula,maxp.formula}{the supplied formulas.}
#'
#' \item{terms,zmeterms}{the terms objects corresponding to supplied formulas
#' \code{formula} and \code{me.formula}.}
#'
#' \item{sample.wterms}{the terms objects corresponding to the supplied formula
#' \code{sample.weights}.}
#'
#' \item{zminpterms,zmaxpterms}{the terms objects corresponding to supplied formulas.}
#'
#' \item{xlevels,zmelevels}{(where relevant) a record of the levels of the
#' factors in \code{formula} and \code{me.formula} used in fitting.}
#'
#' \item{zminplevels,zmaxplevels}{(where relevant) a record of the levels of
#' the factors in \code{minp.formula} and \code{maxp.formula} used in fitting.}
#'
#' \item{data}{the \code{data} argument.}
#'
#' \item{na.action}{(where relevant) information returned by \link{model.frame}
#' on the special handling of NAs.}
#'
#' Additional components when the fitted model includes measurement errors:
#'
#' \item{me.coefs}{\eqn{log} coefficients for the measurement error predictors.}
#'
#' \item{me.mat}{matrix of measurement errors (standard deviations) used in the
#' fitted model.}
#'
#' \item{x.with.me,me.intercepts}{the used arguments.}
#'
#' \item{mixlinkinv}{mixture of the inverse link function corresponding to
#' \code{link}, and used for fitting.}
#'
#' @export glm.mib
#' @import stats
#' @examples
#'
# ### Examples with an upper bound on success probability
#' ## Simulate some data
#' library(mrbglm)
#' set.seed(NULL)
#' mibdata = sim.mrb (beta = c(-2, -1),
#'                    x = cbind(x1 = runif(10000, min = -5, max = 10),
#'                              x2 = runif(10000, min = -5, max = 10)),
#'                    delta = qlogis(.6))$data[,c("y", "x1", "x2")]
#'
#' head (mibdata)
#'
#' ## Logistic fit with upper limit of the success probability to 1
#' MIBfit0 = glm (y ~ x1 + x2,
#'                family = binomial(probit),
#'                data = mibdata)
#' MIBfit0
#'
#' summary(MIBfit0)
#'
#' ## Including a maximum success probability (default)
#' MIBfit1 = glm.mib (y ~ x1 + x2,
#'                    data = mibdata)
#'
#' summary(MIBfit1)
#'
#' ## AIC and R-squared
#' AIC(MIBfit0, MIBfit1)
#' NagelkerkeR2(MIBfit0, MIBfit1)
#'
#' ## Contour plot of probability levels
#' contour(MIBfit1, xlim = c(-2, 3),
#'         colorkey = list(at = c(0, 0.2, 0.4, 0.6, 0.8)))
#'
#' ##3-D plot of the probability surface using 'curves'
#' # ('curves' is only available for one or two predictors)
#' curves(MIBfit1, xlim = c(-3, 4))
#'
# ## Add measurement errors to covariates
# mibdata$Err1 <- abs(rnorm(length(mibdata$x1), sd = 2))
# mibdata$Err2 <- abs(rnorm(length(mibdata$x2), sd = 2))
# mibdata$x1err <- mibdata$x1 + rnorm(length(mibdata$x1), sd = mibdata$Err1)
# mibdata$x2err <- mibdata$x2 + rnorm(length(mibdata$x2), sd = mibdata$Err2)
#
# ## Ignoring the measurement errors
# MIBfite0 = glm.mib (y ~ x1err + x2err,
#                     data = mibdata)
#
# summary(MIBfite0)
#
# ## Including measurement errors (known constants)
# MIBfite1 = glm.mib (y ~ x1err + x2err,
#                     x.with.me = c(TRUE, TRUE),
#                     me.offsets = ~ Err1 + Err2,
#                     data = mibdata)
#
# summary(MIBfite1)
#
# ## AIC and R-squared
# AIC(MIBfite0, MIBfite1)
# NagelkerkeR2(MIBfite0, MIBfite1)
#
#
# ### Produce a heatmap of the predicted probabilities as a widget in viewer
# ## Load libraries
# library(ggplot2)
# library(hrbrthemes)
# library(plotly)
#
# ## Create plot data
# x <- y <- seq(from = -5, to = 5, length.out = 1000)
# data <- expand.grid(x1=x, x2=y)
# data$Viability <- predict(MIBfit1, newdata = data)
#
# ## Add text for tooltip:
# data <- data %>%
#   mutate(text = paste0("x1: ", round(x1,6), "\n", "x2: ", round(x2,6), "\n", "Viability: ",round(Viability,8)))
#
# ## ggplot, with text in aes
# p <- ggplot(data, aes(x1, x2, fill= Viability, text=text)) +
#   geom_tile() +
#   theme_ipsum() +
#   xlab('x1') + ylab('x2')
#
# ggplotly(p, tooltip="text")
#
#' ## End

# Check that the function works with a 2-column response
glm.mib <- function(formula,
                    link = logit,
                    x.with.me = NULL,
                    me.formula   = ~ -1,
                    minp.formula = ~ -1,
                    maxp.formula = ~  1,
                    data, weights, subset,
                    na.action = getOption("na.action"),
                    sample.weights = ~ 1,
                    start = NULL,  etastart, mustart, offset,
                    mestart = NULL, gammastart = NULL,
                    Lostart = NULL, deltaostart = NULL,
                    Lstart = NULL, deltastart = NULL,
                    me.intercepts = FALSE,
                    x.with.me.offsets = NULL, me.offsets  = ~ -1,
                    minp.offset = ~ -1,
                    maxp.offset = ~ -1,
                    method = 'fit.mib',
                    control = list(),
                    model = FALSE,
                    x = FALSE, y = TRUE,
                    ...) {
  ### Save the call
  cal <- match.call()

  ### Get Binomial link function
  if (is.character(link))
    link <- get(link, mode = "function", envir = parent.frame())
  if (is.function(link))
    link <- link()
  if (is.null(link$link)) {
    print(link)
    stop("'link' not recognized")
  }

  ### Control argument
  control <- do.call("control.mib", control)

  ### Was data argument missing?
  mis.data <- missing(data)

  ### Get data, model frames, model terms and weights; also get mustart and etastart
  if (mis.data)
    data <- environment(formula)
  eval(mib.frame())

  fit <- eval(call(if (is.function(method)) "method" else method,
                   x = X, y = Y, intercept = intercept,
                   x.with.me = x.with.me, zme = Zme, me.intercepts = me.intercepts,
                   zminp = Zminp, zmaxp = Zmaxp,
                   me.offsets = Me.offsets,
                   minp.offset = Minp.offset, maxp.offset = Maxp.offset,
                   contract_eta = contract_eta, link = link,
                   weights = weights, sample.weights = sample.weights,
                   start = start, etastart = etastart, mustart = mustart, offset = offset,
                   mestart = mestart, gammastart = gammastart,
                   Lostart = Lostart, deltaostart = deltaostart,
                   Lstart = Lstart, deltastart = deltastart,
                   control = control))
  if (x)
    fit$x <- X
  if (y)
    fit$y <- Y

  if (!is.null(fit$pred.with.me)) {
    colnames(fit$me.mat) <- attr(mt,"term.labels")[fit$pred.with.me]
  }

  out <- structure(c(fit,
                     list(call = cal, formula = formula,
                          minp.formula = minp.formula,
                          maxp.formula = maxp.formula,
                          me.formula = me.formula,
                          link = link,
                          terms = mt, contract_eta = contract_eta,
                          zminpterms = mtZminp, zmaxpterms = mtZmaxp,
                          zmeterms = mtZme, sample.wterms = mtw,
                          data = data, na.action = na.action, method = method,
                          xlevels = stats::.getXlevels(mt, mf),
                          zminplevels = if (!is.null(mtZminp)) stats::.getXlevels(mtZminp, mfZminp),
                          zmaxplevels = if (!is.null(mtZmaxp)) stats::.getXlevels(mtZmaxp, mfZmaxp),
                          zmelevels = if (!is.null(mtZme)) stats::.getXlevels(mtZme, mfZme))),
                   class = c("mibglm", class(fit)))

  if (model) {
    out$model <- list(mf = mf,
                      mf.me = mfZme,
                      mf.minp = mfZminp,
                      mf.maxp = mfZmaxp,
                      mf.meoffsets = mfme.offsets,
                      mf.minpoffset = mfminp.offset,
                      mf.maxpoffset = mfmaxp.offset,
                      mf.samplew = mfw)
  }

  return(out)
}
