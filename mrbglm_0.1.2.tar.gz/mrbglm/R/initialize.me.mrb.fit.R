# x.with.me.offsets

initialize.me.mrb.fit <- function() {
  expression({
    ### Initialization
    gstart <- 0 # Use -745.13 ? or -log(100) ?
    control <- do.call("control.mrb", control)
    #  if (identical(control$method, 'ucminf'))
    #    stop("fitting method 'ucminf' not yet implemented: use 'BFGS' or 'CG'")

    if (missing(start) | is.null(start)) {
      if (control$trace) {
        cat("      # Initialization using 'glm.fit'. \n")
      }

      if (all(intercepts)) {
        start <- catch.conditions({
          stats::glm.fit(x = cbind(`(Intercept)` = 1, x), y = cbind(y, rep(weights, length.out = nobs)),
                         offset = if (is.matrix(x.offsets)) rowSums(x.offsets) else x.offsets,
                         family = stats::binomial(link = link$link),
                         start = NULL, mustart = mustart, etastart = etastart,
                         control = list(epsilon = control$epsilon, maxit = control$maxit,
                                        trace = control$trace))
        })$value

        if (any(is.na(start$coefficients))) {
          start$coefficients[is.na(start$coefficients)] <- 0
        }

        start <- c(rep(start$coefficients[1]/pi, pi), start$coefficients[-1])
      }
      else {
        start <- catch.conditions({
          stats::glm.fit(x = cbind(x), y = cbind(y, rep(weights, length.out = nobs)),
                         offset = if (is.matrix(x.offsets)) rowSums(x.offsets) else x.offsets,
                         family = stats::binomial(link = link$link),
                         start = NULL, mustart = mustart, etastart = etastart,
                         control = list(epsilon = control$epsilon, maxit = control$maxit,
                                        trace = control$trace))
        })$value

        if (any(is.na(start$coefficients))) {
          start$coefficients[is.na(start$coefficients)] <- 0
        }

        if (any(intercepts)) {
          start <- c(rep(0, pi), start$coefficients)
        }
        else {
          start <- start$coefficients
        }
      }
    }
    else {
      if (all(length(start) != c(p, p + qo + q, p + pi, p + pi + qo + q, p + pi + qo + q + r + ri)))
        stop("argument 'start' must have 'p', 'p+qo+q', 'p+pi', 'p+pi+qo+q', or 'p+pi+qo+q+r+ri' elements, 'p,qo,q,r' = number of columns of 'x','zminp','zmaxp','zme', pi = sum(intercepts), and ri = sum(me.intercepts)")
    }

    zmenames <- zonames <- znames <- NULL
    if (is.null(zminp)) {
      deltao <- deltaostart <- NULL
      control$fixLo <- TRUE
      if (is.null(Lostart))
        Lostart <- 0
      Lo0 <- Lostart
    }

    if (is.null(zmaxp)) {
      delta <- deltastart <- NULL
      control$fixL <- TRUE
      if (is.null(Lstart))
        Lstart <- 1
      L0 <- Lstart
    }

    if (is.null(zme)) {
      gammastart <- gamma.int <- NULL
      control$fixme <- TRUE
      if (is.null(mestart)) {
        mestart <- me.offsets
      }
      else {
        stopifnot(is.numeric(mestart))
      }
      if (length(mestart) == 1) {
        mestart <- matrix(mestart, nrow = nobs, ncol = nbcovs)
      }
      else {
        stopifnot (is.matrix(mestart))
        stopifnot(all(dim(mestart) == c(nobs, nbcovs)))
      }

      if (any(!pred.with.me))
      mestart[, !pred.with.me] <- 0

      sd0 <- mestart
    }

    # x.with.me
    if ((lenstart <- length(start)) == pi + p + qo + q + ri + r) {
      if (r > 0) {
        gamma.int <- if (ri > 0) start[(pi+p+qo+q+1):(pi+p+qo+q+ri)]
        gammastart <- start[(p+pi+qo+q+ri+1):(p+pi+qo+q+ri+r)]
        sd0 <- matrix(0, nrow = nobs, ncol = nbcovs) + me.offsets
        if (control$fixme) {
          if (length(zme) > 1) {
            meterm <- exp(gammastart) * t(zme)
            if (ri > 0)
              meterm[me.intercepts,] <- meterm[me.intercepts,] + exp(gamma.int)
            sd0[, x.with.me] <- sd0[, x.with.me, drop = FALSE] + t(meterm); rm(meterm)
          }
          else {
            meterm <- exp(gammastart) * zme
            if (ri > 0)
              meterm <- meterm + exp(gamma.int)
            sd0[, x.with.me] <- sd0[, x.with.me, drop = FALSE] + meterm; rm(meterm)
          }
        }
        zmenames <- colnames(zme)
        if (is.null(zmenames)) {
          if (r == 1) {
            zmenames <- 'sd'
          }
          else {
            zmenames <- paste0('sd', 1:r)
          }
        }
        else {
          zmenames <- paste0('sd.', zmenames)
        }
        if (ri > 0) {
          zmenames <- c(paste0('(Intercept).', zmenames[me.intercepts]), zmenames)
        }
        gammastart <- c(gamma.int, gammastart)
        if (length(names(gammastart)) < length(gammastart)) {
          names(gammastart) <- zmenames
        }
      }

      if (qo > 0) {
        deltaostart <- start[(pi+p+1):(pi+p+qo)]
        Lo0 <- linkinv(minp.offset + c(zminp %*% deltaostart), log.p = FALSE)
        #zonames <- names(deltaostart)
      }

      if (q > 0) {
        deltastart <- start[(pi+p+qo+1):(pi+p+qo+q)]
        L0 <- linkinv(maxp.offset + c(zmaxp %*% deltastart), log.p = FALSE)
        #znames <- names(deltastart)
      }
    }
    else {
      if (r > 0) {
        if (is.null(zmenames)) {
          if (r == 1) {
            zmenames <- 'sd'
          }
          else {
            zmenames <- paste0('sd', 1:r)
          }
        }
        else {
          zmenames <- paste0('sd.', zmenames)
        }

        if (ri > 0) {
          zmenames <- c(paste0('(Intercept).', zmenames[me.intercepts]), zmenames)
        }
        if (length(names(gammastart)) < length(gammastart)) {
          names(gammastart) <- zmenames
        }
        gammastart <- c(gamma.int, gammastart)

        if (is.null(gammastart) | all(c(ri > 0, (lgm <- length(gammastart)) == ri, r != ri))) {
          if (!is.null(gammastart)) {
            gamma.int <- gammastart
          }
          else {
            gamma.int <- if (ri > 0) rep(gstart, ri)
          }
          if (is.null(mestart)) {
            gamma <- gammastart <- gstart
            if (r > 1)
              gamma <- gammastart <- rep(gammastart, r)
            sd0 <- matrix(0, nrow = nobs, ncol = nbcovs) + me.offsets
          }
          else {
            mestart <- abs(mestart)
            gammastart <- mestart - me.offsets
            if (all(gammastart >= 0) & any(gammastart > 0)) {
              if (r > 1)
                gamma <- gammastart <- logb(colMeans(gammastart, na.rm = TRUE) / colMeans(zme[zme>0]))
              else
                gamma <- gammastart <- logb(mean(gammastart, na.rm = TRUE) / mean(zme[zme>0]))
            }
            else
              gamma <- gammastart <- rep(gstart, r)
            sd0 <- matrix(0, nrow = nobs, ncol = nbcovs) + mestart
          }

          if (ri > 0 & is.null(names(gamma.int))) {
            names(gamma.int) <- paste0('(Intercept).sd', 1:ri)
          }

          if (r > 0) {
            if (r > 1) {
              names(gammastart) <- paste0('sd', 1:r)
            }
            else
              names(gammastart) <- 'sd'
          }
        }
        else {
          if (all(lgm != c(1, r, r + ri)))
            stop("argument 'gammastart' must have one, 'ri', r' or r+ri elements, 'r' = number of columns of 'zme' and ri = sum(me.intercepts)")
          if (lgm == 1) {
            gammastart <- rep(gammastart, length.out = r)
            gamma.int <- if (ri > 0) rep(gstart, ri)
          }
          else if (lgm == r) {
            gamma.int <- if (ri > 0) rep(gstart, ri)
          }
          else {
            gamma.int <- gammastart[1:ri]
            gammastart <- gammastart[(ri+1):(ri+r)]
          }
          sd0 <- matrix(0, nrow = nobs, ncol = nbcovs)
          if (control$fixme) {
            if (length(zme) > 1) {
              meterm <- exp(gammastart) * t(zme)
              if (ri > 0)
                meterm[me.intercepts,] <- meterm[me.intercepts,] + exp(gamma.int)
              sd0[, x.with.me] <- sd0[, x.with.me, drop = FALSE] + t(meterm); rm(meterm)
            }
            else {
              meterm <- exp(gammastart) * zme
              if (ri > 0)
                meterm <- meterm + exp(gamma.int)
              sd0[, x.with.me] <- sd0[, x.with.me, drop = FALSE]
            }
          }
          else {
            sd0 <- sd0 + me.offsets
          }
        }
      }

      if (r > 0) {
        zmenames <- colnames(zme)
        if (is.null(zmenames)) {
          if (r == 1) {
            zmenames <- 'sd'
          }
          else {
            zmenames <- paste0('sd', 1:r)
          }
        }
        else {
          zmenames <- paste0('sd.', zmenames)
        }

        if (ri > 0) {
          zmenames <- c(paste0('(Intercept).', zmenames[me.intercepts]), zmenames)
        }
        if (length(names(gammastart)) < length(gammastart)) {
          names(gammastart) <- zmenames
        }
        gammastart <- c(gamma.int, gammastart)
      }

      if (lenstart == pi + p + qo + q) {
        if (qo > 0) {
          deltaostart <- start[(pi+p+1):(pi+p+qo)]
          Lo0 <- linkinv(minp.offset + c(zminp %*% deltaostart), log.p = FALSE)
          zonames <- names(deltaostart)
        }

        if (q > 0) {
          deltastart <- start[(p+pi+qo+1):(p+pi+qo+q)]
          L0 <- linkinv(maxp.offset + c(zmaxp %*% deltastart), log.p = FALSE)
          znames <- names(deltastart)
        }
      }
      else if (lenstart %in% c(p, pi + p)) {
        if (!is.null(zminp)) {
          if (is.null(deltaostart)) {
            if (is.null(Lostart)) {
              deltao <- deltaostart <- 0 # -709.7                #############   Default INITIAL Lo VALUE
              if (qo > 1)
                deltao <- deltaostart <- c(deltaostart, rep(0, qo - 1))
              Lo0 <- plogis(deltao[1])
            }
            else {
              deltao <- deltaostart <- mean(linkfun (Lostart) - minp.offset, na.rm = TRUE) / zminp[zminp != 0][1]
              if (qo > 1)
                deltao <- deltaostart <- c(deltaostart, rep(0, qo - 1))
              Lo0 <- Lostart
            }
          }
          else {
            if (all(length(deltaostart) != c(1, qo)))
              stop("argument 'deltaostart' must have one or 'qo' elements, 'qo' = number of columns of 'zminp'")
            deltao <- deltaostart <- rep(deltaostart, length.out = qo)
            Lo0 <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
          }

          zonames <- colnames(zminp)
          if (is.null(zonames)) {
            if (qo == 1)
              zonames <- paste0(link$link, '(Lo)')
            else if (qo > 1)
              zonames <- paste0(link$link, '(Lo).', 1:qo)
          }
          else {
            zonames <- paste0(link$link, '(Lo).', zonames)
          }

          if (length(names(deltaostart)) < length(deltaostart)) {
            names(deltaostart) <- zonames
          }
        }
        deltao <- deltaostart

        if (!is.null(zmaxp)) {
          if (is.null(deltastart)) {
            if (is.null(Lstart)) {
              delta <- deltastart <- rep(0, q)               #############   Default INITIAL L VALUE
              L0 <- .5
            }
            else {
              delta <- deltastart <- mean(linkfun (Lstart) - maxp.offset, na.rm = TRUE) / zmaxp[zmaxp != 0][1]
              if (q > 1)
                delta <- deltastart <- c(deltastart, rep(0, q - 1))
              L0 <- Lstart
            }
          }
          else {
            if (all(length(deltastart) != c(1, q)))
              stop("argument 'deltastart' must have one or 'q' elements, 'q' = number of columns of zmaxp'")
            delta <- deltastart <- rep(deltastart, length.out = q)
            L0 <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = FALSE)
          }

          znames <- colnames(zmaxp)
          if (is.null(znames)) {
            if (q == 1)
              znames <- paste0(link$link, '(L)')
            else
              znames <- paste0(link$link, '(L).', 1:q)
          }
          else {
            znames <- paste0(link$link, '(L).', znames)
          }

          if (length(names(deltastart)) < length(deltastart)) {
            names(deltastart) <- znames
          }
        }
        delta <- deltastart

        if (length(start) == p + pi) {
          start <- c(start, deltaostart, deltastart)
        }
        else {
          if (any(intercepts)) {
            start <- c(rep(0, pi), start)
          }
          start <- c(start, deltaostart, deltastart)
        }
      }
      else if (lenstart == p + qo + q) {
        if (qo > 0) {
          deltaostart <- start[(p+1):(p+qo)]  # ignore 'deltaostart' and 'Lo0'
          Lo0 <- linkinv(minp.offset + c(zminp %*% deltaostart), log.p = FALSE)
          zonames <- names(deltaostart)
        }

        if (q > 0) {
          deltastart <- start[(p+qo+1):(p+qo+q)]  # ignore 'deltastart' and 'L0'
          L0 <- linkinv(maxp.offset + c(zmaxp %*% deltastart), log.p = FALSE)
          znames <- names(deltastart)
        }

        if (any(intercepts)) {
          start <- c(rep(0, pi), start)
        }
      }
      else {
        stop("should not get here: something went wrong")
      }
    }

    xnames <- colnames(x)
    if (is.null(xnames)) {
      xnames <- paste0('x', 1:p)
    }

    if (any(intercepts)) {
      if (p == 1)
        tnames <- c("(Intercept)",
                    xnames,
                    if (qo > 0) zonames,
                    if (q > 0) znames,
                    if (r > 0) zmenames)
      else {
        if (is.null(names(intercepts))) {
          names(intercepts) <- if(length(intercepts) == p)
            paste0("(Intercept).", xnames[intercepts])
          else
            paste0("(Intercept).",
                   sapply(1:nbcovss, FUN = function(j) {
                     ot <- xnames[which(contract_eta == j)[1]]
                     return(ot)
                   }))
        }

        tnames <- c(names(intercepts)[intercepts],
                    xnames,
                    if (qo > 0) zonames,
                    if (q > 0) znames,
                    if (r > 0) zmenames)
      }

      if (length(tnames) == pi+p+qo+q+ri+r)
        names(start) <- tnames
    }
    else {
      tnames <- c(xnames,
                  if (qo > 0) zonames,
                  if (q > 0) znames,
                  if (r > 0) zmenames)
      if (length(tnames) == p+qo+q+ri+r)
        names(start) <- tnames
    }
  })
}
