
initialize.mib.fit <- function() {
  expression({
    ### Initialization
    control <- do.call("control.mib", control)
    #  if (identical(control$method, 'ucminf'))
    #    stop("fitting method 'ucminf' not yet implemented: use 'BFGS' or 'CG'")

    if (missing(start) | is.null(start)) {
      if (control$trace) {
        cat("      # Initialization using 'glm.fit'. \n")
      }

      if (intercept) {
        start <- catch.conditions({
          stats::glm.fit(x = cbind(`(Intercept)` = 1, x), y = cbind(y, rep(weights, length.out = nobs)),
                         offset = offset,
                         family = stats::binomial(link = link$link),
                         start = NULL, mustart = mustart, etastart = etastart,
                         control = list(epsilon = control$epsilon, maxit = control$maxit,
                                        trace = control$trace))
        })$value

        if (any(is.na(start$coefficients))) {
          start$coefficients[is.na(start$coefficients)] <- 0
        }
        start <- start$coefficients
      }
      else {
        start <- catch.conditions({
          stats::glm.fit(x = cbind(x), y = cbind(y, rep(weights, length.out = nobs)),
                         offset = offset,
                         family = stats::binomial(link = link$link),
                         start = NULL, mustart = mustart, etastart = etastart,
                         control = list(epsilon = control$epsilon, maxit = control$maxit,
                                        trace = control$trace))
        })$value

        if (any(is.na(start$coefficients))) {
          start$coefficients[is.na(start$coefficients)] <- 0
        }
        start <- start$coefficients
      }
    }
    else {
      if (all(length(start) != c(p, p + qo + q, pi + p, pi + p + qo + q)))
        stop("argument 'start' must have 'p', 'p+qo+q', 'pi+p', or 'pi+p+qo+q' elements, 'p,qo,q' = number of columns of 'x','zminp','zmaxp' and pi = sum(intercept)")
    }

    zonames <- znames <- NULL
    if (is.null(zminp)) {
      deltao <- deltaostart <- NULL
      control$fixLo <- TRUE
      if (is.null(Lostart))
        Lostart <- 0
      Lo0 <- Lostart
    }

    if (is.null(zmaxp)) {
      delta <- deltastart <- NULL
      control$fixL <- TRUE
      if (is.null(Lstart))
        Lstart <- 1
      L0 <- Lstart
    }

    if ((lenstart <- length(start)) == pi + p + qo + q) {
      if (qo > 0) {
        deltaostart <- start[(p+pi+1):(p+pi+qo)]
        Lo0 <- linkinv(minp.offset + c(zminp %*% deltaostart), log.p = FALSE)
        zonames <- names(deltaostart)
      }

      if (q > 0) {
        deltastart <- start[(p+pi+qo+1):(p+pi+qo+q)]
        L0 <- linkinv(maxp.offset + c(zmaxp %*% deltastart), log.p = FALSE)
        znames <- names(deltastart)
      }
    }
    else if (lenstart %in% c(p, pi + p)) {
      if (!is.null(zminp)) {
        if (is.null(deltaostart)) {
          if (is.null(Lostart)) {
            deltao <- deltaostart <- 0 # -709.7                #############   Default INITIAL Lo VALUE
            if (qo > 1)
              deltao <- deltaostart <- c(deltaostart, rep(0, qo - 1))
            Lo0 <- plogis(deltao[1])
          }
          else {
            deltao <- deltaostart <- mean(linkfun (Lostart) - minp.offset, na.rm = TRUE) / zminp[zminp != 0][1]
            if (qo > 1)
              deltao <- deltaostart <- c(deltaostart, rep(0, qo - 1))
            Lo0 <- Lostart
          }
        }
        else {
          if (all(length(deltaostart) != c(1, qo)))
            stop("argument 'deltaostart' must have one or 'qo' elements, 'qo' = number of columns of 'zminp'")
          deltao <- deltaostart <- rep(deltaostart, length.out = qo)
          Lo0 <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
        }

        zonames <- colnames(zminp)
        if (is.null(zonames)) {
          if (qo == 1)
            zonames <- paste0(link$link, '(Lo)')
          else if (qo > 1)
            zonames <- paste0(link$link, '(Lo).', 1:qo)
        }
        else {
          zonames <- paste0(link$link, '(Lo).', zonames)
        }

        if (length(names(deltaostart)) < length(deltaostart)) {
          names(deltaostart) <- zonames
        }
      }
      deltao <- deltaostart

      if (!is.null(zmaxp)) {
        if (is.null(deltastart)) {
          if (is.null(Lstart)) {
            delta <- deltastart <- rep(0, q)               #############   Default INITIAL L VALUE
            L0 <- .5
          }
          else {
            delta <- deltastart <- mean(linkfun (Lstart) - offset, na.rm = TRUE) / zmaxp[zmaxp != 0][1]
            if (q > 1)
              delta <- deltastart <- c(deltastart, rep(0, q - 1))
            L0 <- Lstart
          }
        }
        else {
          if (all(length(deltastart) != c(1, q)))
            stop("argument 'deltastart' must have one or 'q' elements, 'q' = number of columns of zmaxp'")
          delta <- deltastart <- rep(deltastart, length.out = q)
          L0 <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = FALSE)
        }

        znames <- colnames(zmaxp)
        if (is.null(znames)) {
          if (q == 1)
            znames <- paste0(link$link, '(L)')
          else
            znames <- paste0(link$link, '(L).', 1:q)
        }
        else {
          znames <- paste0(link$link, '(L).', znames)
        }

        if (length(names(deltastart)) < length(deltastart)) {
          names(deltastart) <- znames
        }
      }
      delta <- deltastart

      if (length(start) == p + pi) {
        start <- c(start, deltaostart, deltastart)
      }
      else {
        if (intercept) {
          start <- c(0, start)
        }
        start <- c(start, deltaostart, deltastart)
      }
    }
    else if (lenstart == p + qo + q) {
      if (qo > 0) {
        deltaostart <- start[(p+1):(p+qo)]  # ignore 'deltaostart' and 'Lo0'
        Lo0 <- linkinv(minp.offset + c(zminp %*% deltaostart), log.p = FALSE)
        #zonames <- names(deltaostart)
      }

      if (q > 0) {
        deltastart <- start[(p+qo+1):(p+qo+q)]  # ignore 'deltastart' and 'L0'
        L0 <- linkinv(maxp.offset + c(zmaxp %*% deltastart), log.p = FALSE)
        #znames <- names(deltastart)
      }

      if (intercept) {
        start <- c(0, start)
      }
    }
    else {
      stop("should not get here: something went wrong")
    }

    xnames <- colnames(x)
    if (is.null(xnames)) {
      xnames <- paste0('x', 1:p)
    }

    tnames <- c(xnames,
                if (qo > 0) zonames,
                if (q > 0) znames)

    if (intercept) {
      tnames <- c("(Intercept)", tnames)
    }

    if (length(tnames) == pi+p+qo+q)
      names(start) <- tnames

  })
}
