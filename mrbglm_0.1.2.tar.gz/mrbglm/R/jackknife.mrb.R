# Jackknife a Model Fit
jackknife.mrb <- function(object) {
  # For ordinary bootstrapping

  #### An index as 'data'
  data <- 1:object$nobs

  #### A function to extract the matrix for a specific sample index
  get.x <- function(index) {
    object$fit.call$x[index, , drop = FALSE]
  }

  #### A function to extract the matrix x for a specific sample index
  if (NCOL(object$fit.call$y) == 1) {
    get.y <- function(index) {
      object$fit.call$y[index]
    }
  }
  else {
    get.y <- function(index) {
      object$fit.call$y[index, , drop = FALSE]
    }
  }

  #### A function to extract the vector/matrix z for a specific sample index
  if (length(object$fit.call$z) == 1) {
    get.z <- function(index) {
      object$fit.call$z
    }
  }
  else if (NCOL(object$fit.call$z) == 1) {
    get.z <- function(index) {
      object$fit.call$z[index]
    }
  }
  else {
    get.z <- function(index) {
      object$fit.call$z[index, , drop = FALSE]
    }
  }

  #### A function to extract the vector of weights for a specific sample index
  if (length(object$fit.call$weights) == 1) {
    get.weights <- function(index) {
      object$fit.call$weights
    }
  }
  else {
    get.weights <- function(index) {
      object$fit.call$weights[index]
    }
  }

  #### A function to extract the vector of offset for a specific sample index
  if (length(object$fit.call$offset) == 1) {
    get.offset <- function(index) {
      object$fit.call$offset
    }
  }
  else {
    get.offset <- function(index) {
      object$fit.call$offset[index]
    }
  }

  # Extract sample MLE
  theta <- c(object$coefficients, object$L.coefs)

  # Evaluation environment
  local.env <- new.env()

  #### A function to compute the vector of mrbglm coefficients
  statistic.fun <- function(data, index) {
    fit.index <- eval(call(if (is.function(object$method)) "method" else object$method,
                           x = get.x (-index[1]),
                           y = get.y (-index[1]),
                           z = get.z (-index[1]),
                           intercepts = object$intercepts,
                           linkinv = object$fit.call$linkinv,
                           weights = get.weights(-index[1]),
                           start = theta,
                           etastart = NULL, mustart = NULL,
                           offset = get.offset (-index[1]),
                           control = object$fit.call$control),
                      envir = local.env)
    return(c(fit.index$coefficients,
             fit.index$L.coefs,
             conv = fit.index$converged,
             zero.hessian = sum(diag(fit.index$hessian) == 0)))
  }

  #### Do the job
  boot.object <- t(sapply(data, FUN = function(i) {
    statistic.fun (data, i)
  }))

  colnames(boot.object) <- c(names(theta), 'cov', 'zero.hessian')

  boot.object <- list(t0 = theta,
                      t = boot.object,
                      R = object$nobs - 1,
                      data = data,
                      seed = 0,
                      statistic = statistic.fun,
                      sim = 'jackknife',
                      stype = 'i',
                      call = NULL,
                      strata = NULL,
                      weights = NULL,
                      pred.i = NULL,
                      L = NULL,
                      ran.gen = NULL)

  boot.object$fit <- object
  return(structure(boot.object, class = "boot"))
}
