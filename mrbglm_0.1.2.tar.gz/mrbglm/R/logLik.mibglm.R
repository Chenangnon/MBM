
#' @exportS3Method logLik mibglm
#' @export logLik.mibglm

logLik.mibglm <- function (object, ...) {
  if (is.null(object$logLike))
    NA
  else
    structure(object$logLike,
              nobs = object$nobs,
              df = object$rank,
              class = 'logLik')
}

logLik.mibglm -> logLik.mib.fit
