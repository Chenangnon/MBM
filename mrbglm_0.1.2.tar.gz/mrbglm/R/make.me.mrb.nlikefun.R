
# A routine to generate negative log-likelihood function for mrb fit
make.me.mrb.nlikefun <- function() {

  expression({
    # beta.with.me
    beta.with.me <- beta.with.me.index (contract_eta, pred.with.me = pred.with.me)

    if (control$fixme) {
      switch(control$criterion,
             NLS = {
               if (control$fixLo) {
                 Lovalues <- Lo0
                 if (all(Lovalues == 0)) {
                   if (control$fixL)  {
                     logLvalues <- log(L0)
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         #if (!all(validmu)) {
                         #  if (length(weights) > 1)
                         #     weights <- weights[validmu]
                         #  if (length(sample.weights) > 1) {
                         #   sample.weights <- sample.weights[validmu]
                         #    validsweights <- validsweights[validmu]
                         #   }
                         #}

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                      sd = 1, log = TRUE)


                         res <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                   else {
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         delta <- theta[(pi + p + 1):(pi + p + q)]
                         mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(mu + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         delta <- theta[(p+1):(p+q)]
                         mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(mu + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                 }
                 else {
                   if (control$fixL)  {
                     logLvalues <- log(L0)
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                   else {
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         delta <- theta[(pi + p + 1):(pi + p + q)]
                         logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         delta <- theta[(p+1):(p+q)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                 }
               }
               else {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       deltao <- theta[(pi + p + 1):(pi + p + qo)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       sdmat <- t(sd0)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       deltao <- theta[(p + 1):(p + qo)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       sdmat <- t(sd0)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                 }
                 else {
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       deltao <- theta[(pi + p + 1):(pi + p + qo)]
                       delta <- theta[(pi + p + qo + 1):(pi + p + qo + q)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       sdmat <- t(sd0)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       deltao <- theta[(p + 1):(p + qo)]
                       delta <- theta[(p + qo + 1):(p + qo + q)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       sdmat <- t(sd0)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                 }
               }
             },
             ML = {
               if (control$fixLo) {
                 Lovalues <- Lo0
                 if (all(Lovalues == 0)) {
                   if (control$fixL)  {
                     logLvalues <- log(L0)
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                   else {
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         delta <- theta[(pi + p + 1):(pi + p + q)]
                         mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(mu + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         delta <- theta[(p+1):(p+q)]
                         mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(mu + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                 }
                 else {
                   if (control$fixL)  {
                     logLvalues <- log(L0)
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                   else {
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         delta <- theta[(pi + p + 1):(pi + p + q)]
                         logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         delta <- theta[(p+1):(p+q)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         sdmat <- t(sd0)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                 }
               }
               else {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       deltao <- theta[(pi + p + 1):(pi + p + qo)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       sdmat <- t(sd0)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       deltao <- theta[(p + 1):(p + qo)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       sdmat <- t(sd0)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                 }
                 else {
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       deltao <- theta[(pi + p + 1):(pi + p + qo)]
                       delta <- theta[(pi + p + qo + 1):(pi + p + qo + q)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       sdmat <- t(sd0)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       deltao <- theta[(p + 1):(p + qo)]
                       delta <- theta[(p + qo + 1):(p + qo + q)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       sdmat <- t(sd0)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                 }
               }
             })
    }
    else {
      # A routine to extract sdmat
      get.sdmat <- function (theta, ptout) {
        gamma.int <- if (ri > 0) theta[(ptout + 1):(ptout + ri)]
        gamma <- theta[(ptout + ri + 1):(ptout + ri + r)]
        sdmat <- matrix(0, nrow = nobs, ncol = nbcovs) + me.offsets
        sdmat <- t(sdmat)

        if (length(zme) > 1) {
          meterm <- exp(gamma) * t(zme)
          if (ri > 0)
            meterm[me.intercepts,] <- meterm[me.intercepts,] + exp(gamma.int)
          sdmat[x.with.me,] <- sdmat[x.with.me, , drop = FALSE] + meterm
        }
        else {
          meterm <- exp(gamma) * zme
          if (ri > 0)
            meterm <- meterm + exp(gamma.int)
          sdmat[x.with.me,] <- sdmat[x.with.me, , drop = FALSE] + meterm
        }
        return(sdmat)
      }

      switch(control$criterion,
             NLS = {
               if (control$fixLo) {
                 Lovalues <- Lo0
                 if (all(Lovalues == 0)) {
                   if (control$fixL)  {
                     logLvalues <- log(L0)
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         sdmat <- get.sdmat (theta, ptout = p+pi)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         sdmat <- get.sdmat (theta, ptout = p)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                   else {
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         delta <- theta[(pi + p + 1):(pi + p + q)]
                         mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         sdmat <- get.sdmat (theta, ptout = pi + p + q)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(mu + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         delta <- theta[(p+1):(p+q)]
                         mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         sdmat <- get.sdmat (theta, ptout = p+q)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(mu + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                 }
                 else {
                   if (control$fixL)  {
                     logLvalues <- log(L0)
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         sdmat <- get.sdmat (theta, ptout = pi+p)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         sdmat <- get.sdmat (theta, ptout = p)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                   else {
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         delta <- theta[(pi + p + 1):(pi + p + q)]
                         logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         sdmat <- get.sdmat (theta, ptout = pi + p + q)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         delta <- theta[(p+1):(p+q)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         sdmat <- get.sdmat (theta, ptout = p + q)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                             sd = 1, log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                 }
               }
               else {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       deltao <- theta[(pi + p + 1):(pi + p + qo)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       sdmat <- get.sdmat (theta, ptout = pi + p + qo)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       deltao <- theta[(p + 1):(p + qo)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       sdmat <- get.sdmat (theta, ptout = p + qo)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                 }
                 else {
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       deltao <- theta[(pi + p + 1):(pi + p + qo)]
                       delta <- theta[(pi + p + qo + 1):(pi + p + qo + q)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       sdmat <- get.sdmat (theta, ptout = pi + p + qo + q)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       deltao <- theta[(p + 1):(p + qo)]
                       delta <- theta[(p + qo + 1):(p + qo + q)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       sdmat <- get.sdmat (theta, ptout = p + qo + q)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                 }
               }
             },
             ML  = {
               if (control$fixLo) {
                 Lovalues <- Lo0
                 if (all(Lovalues == 0)) {
                   if (control$fixL)  {
                     logLvalues <- log(L0)
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         sdmat <- get.sdmat (theta, ptout = pi + p)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         sdmat <- get.sdmat (theta, ptout = p)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                   else {
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         delta <- theta[(pi + p + 1):(pi + p + q)]
                         mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         sdmat <- get.sdmat (theta, ptout = pi + p + q)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(mu + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         delta <- theta[(p+1):(p+q)]
                         mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         sdmat <- get.sdmat (theta, ptout = p + q)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(mu + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                 }
                 else {
                   if (control$fixL)  {
                     logLvalues <- log(L0)
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         sdmat <- get.sdmat (theta, ptout = pi+p)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         sdmat <- get.sdmat (theta, ptout = p)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                   else {
                     nlikefun <- if (any(intercepts)) {
                       function(theta) {
                         beta.int <- theta[1:pi]
                         beta <- theta[(pi+1):(pi+p)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         eta[intercepts,] <- eta[intercepts,] + beta.int
                         delta <- theta[(pi + p + 1):(pi + p + q)]
                         logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         sdmat <- get.sdmat (theta, ptout = pi + p + q)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                     else {
                       function(theta) {
                         beta <- theta[1:p]
                         delta <- theta[(p+1):(p+q)]
                         eta <- beta * x
                         eta <- contract.eta (eta, contract_eta)
                         eta <- eta + x.offsets
                         logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                         sdmat <- get.sdmat (theta, ptout = p+q)
                         sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                         if (any(sdmat > 0))
                           mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                         else
                           mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                         mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                         validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                         res <- numeric(nobs) + log(1e-323)

                         if (length(weights) > 1 & !all(validmu))
                           weights <- weights[validmu]

                         res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                         if (!all(validsweights) & length(sample.weights) > 1) {
                           sample.weights <- sample.weights[validsweights]
                           res <- res[validsweights]
                         }
                         -sum(res * sample.weights)
                       }
                     }
                   }
                 }
               }
               else {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       deltao <- theta[(pi + p + 1):(pi + p + qo)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       sdmat <- get.sdmat (theta, ptout = pi + p + qo)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       deltao <- theta[(p + 1):(p + qo)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       sdmat <- get.sdmat (theta, ptout = p + qo)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                 }
                 else {
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       deltao <- theta[(pi + p + 1):(pi + p + qo)]
                       delta <- theta[(pi + p + qo + 1):(pi + p + qo + q)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       sdmat <- get.sdmat (theta, ptout = pi + p + qo + q)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       deltao <- theta[(p + 1):(p + qo)]
                       delta <- theta[(p + qo + 1):(p + qo + q)]
                       Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       sdmat <- get.sdmat (theta, ptout = p + qo + q)
                       sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                       if (any(sdmat > 0))
                         mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                       else
                         mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }
                       -sum(res * sample.weights)
                     }
                   }
                 }
               }
             })
    }
  })
}


beta.with.me.index <- function (contract_eta, pred.with.me) {
  # If a unique predictor in one column
  if (length(pred.with.me) == 1)
    return(pred.with.me)

  # A child function to return TRUE/FALSEs per predictor
  cfun <- function(j) {
    # Number of slopes for predictor 'j' appears in beta
    nbj <- sum(contract_eta == j)

    if (nbj > 1) {
      return(rep(FALSE, nbj)) # Factors have no measurement error term
    }
    else {
      pred.with.me[j]
    }

  }

  # For each predictor, return TRUEs/FALSEs
  beta.with.me <- lapply(1:length(pred.with.me),
                         FUN = cfun)
  beta.with.me <- unlist(beta.with.me, recursive = TRUE)
  beta.with.me <- which(beta.with.me)

  return(beta.with.me)

}
