
# A routine to generate negative log-likelihood function for mrb fit
make.mib.nlikefun <- function() {
  expression({

    switch(control$criterion,
           NLS = {
             if (control$fixLo) {
               Lovalues <- Lo0
               if (all(Lovalues == 0)) {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   nlikefun <- if (intercept) {
                     function(theta) {
                       eta <- offset + theta[1] + c(x %*% theta[2:(1+p)])
                       mu <- exp(logLvalues + linkinv(eta, log.p = TRUE))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)
                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       eta <- offset + c(x %*% theta[1:p])
                       mu <- exp(logLvalues + linkinv(eta, log.p = TRUE))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
                 else {
                   nlikefun <- if (intercept) {
                     function(theta) {
                       eta <- offset + theta[1] + c(x %*% theta[2:(1+p)])
                       delta <- theta[(pi + p + 1):(pi + p + q)]
                       mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       mu <- exp(mu + linkinv(eta, log.p = TRUE))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       eta <- offset + c(x %*% theta[1:p])
                       delta <- theta[(p+1):(p+q)]
                       mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       mu <- exp(mu + linkinv(eta, log.p = TRUE))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
               }
               else {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   nlikefun <- if (intercept) {
                     function(theta) {
                       eta <- offset + theta[1] + c(x %*% theta[2:(1+p)])
                       mu <- exp(linkinv(eta, log.p = TRUE))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       eta <- offset + c(x %*% theta[1:p])
                       mu <- exp(linkinv(eta, log.p = TRUE))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
                 else {
                   nlikefun <- if (intercept) {
                     function(theta) {
                       eta <- offset + theta[1] + c(x %*% theta[2:(1+p)])
                       delta <- theta[(pi + p + 1):(pi + p + q)]
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       mu <- exp(linkinv(eta, log.p = TRUE))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       eta <- offset + c(x %*% theta[1:p])
                       delta <- theta[(p+1):(p+q)]
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       mu <- exp(linkinv(eta, log.p = TRUE))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
               }
             }
             else {
               if (control$fixL)  {
                 logLvalues <- log(L0)
                 nlikefun <- if (intercept) {
                   function(theta) {
                     eta <- offset + theta[1] + c(x %*% theta[2:(1+p)])
                     deltao <- theta[(pi + p + 1):(pi + p + qo)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     mu <- exp(linkinv(eta, log.p = TRUE))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                  sd = 1, log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
                 else {
                   function(theta) {
                     eta <- offset + c(x %*% theta[1:p])
                     deltao <- theta[(p + 1):(p + qo)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     mu <- exp(linkinv(eta, log.p = TRUE))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                  sd = 1, log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
               }
               else {
                 nlikefun <- if (intercept) {
                   function(theta) {
                     eta <- offset + theta[1] + c(x %*% theta[2:(1+p)])
                     deltao <- theta[(pi + p + 1):(pi + p + qo)]
                     delta <- theta[(pi + p + qo + 1):(pi + p + qo + q)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                     mu <- exp(linkinv(eta, log.p = TRUE))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                  sd = 1, log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
                 else {
                   function(theta) {
                     eta <- offset + c(x %*% theta[1:p])
                     deltao <- theta[(p + 1):(p + qo)]
                     delta <- theta[(p + qo + 1):(p + qo + q)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                     mu <- exp(linkinv(eta, log.p = TRUE))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                  sd = 1, log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
               }
             }
           },
           ML = {
             if (control$fixLo) {
               Lovalues <- Lo0
               if (all(Lovalues == 0)) {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   nlikefun <- if (intercept) {
                     function(theta) {
                       eta <- offset + theta[1] + c(x %*% theta[2:(1+p)])
                       mu <- exp(logLvalues + linkinv(eta, log.p = TRUE))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)
                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       eta <- offset + c(x %*% theta[1:p])
                       mu <- exp(logLvalues + linkinv(eta, log.p = TRUE))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
                 else {
                   nlikefun <- if (intercept) {
                     function(theta) {
                       eta <- offset + theta[1] + c(x %*% theta[2:(1+p)])
                       delta <- theta[(pi + p + 1):(pi + p + q)]
                       mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       mu <- exp(mu + linkinv(eta, log.p = TRUE))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)

                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       eta <- offset + c(x %*% theta[1:p])
                       delta <- theta[(p+1):(p+q)]
                       mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       mu <- exp(mu + linkinv(eta, log.p = TRUE))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
               }
               else {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   nlikefun <- if (intercept) {
                     function(theta) {
                       eta <- offset + theta[1] + c(x %*% theta[2:(1+p)])
                       mu <- exp(linkinv(eta, log.p = TRUE))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       eta <- offset + c(x %*% theta[1:p])
                       mu <- exp(linkinv(eta, log.p = TRUE))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
                 else {
                   nlikefun <- if (intercept) {
                     function(theta) {
                       eta <- offset + theta[1] + c(x %*% theta[2:(1+p)])
                       delta <- theta[(pi + p + 1):(pi + p + q)]
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       mu <- exp(linkinv(eta, log.p = TRUE))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       eta <- offset + c(x %*% theta[1:p])
                       delta <- theta[(p+1):(p+q)]
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       mu <- exp(linkinv(eta, log.p = TRUE))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
               }
             }
             else {
               if (control$fixL)  {
                 logLvalues <- log(L0)
                 nlikefun <- if (intercept) {
                   function(theta) {
                     eta <- offset + theta[1] + c(x %*% theta[2:(1+p)])
                     deltao <- theta[(pi + p + 1):(pi + p + qo)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     mu <- exp(linkinv(eta, log.p = TRUE))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
                 else {
                   function(theta) {
                     eta <- offset + c(x %*% theta[1:p])
                     deltao <- theta[(p + 1):(p + qo)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     mu <- exp(linkinv(eta, log.p = TRUE))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
               }
               else {
                 nlikefun <- if (intercept) {
                   function(theta) {
                     eta <- offset + theta[1] + c(x %*% theta[2:(1+p)])
                     deltao <- theta[(pi + p + 1):(pi + p + qo)]
                     delta <- theta[(pi + p + qo + 1):(pi + p + qo + q)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                     mu <- exp(linkinv(eta, log.p = TRUE))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
                 else {
                   function(theta) {
                     eta <- offset + c(x %*% theta[1:p])
                     deltao <- theta[(p + 1):(p + qo)]
                     delta <- theta[(p + qo + 1):(p + qo + q)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                     mu <- exp(linkinv(eta, log.p = TRUE))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
               }
             }
           })
  })
}
