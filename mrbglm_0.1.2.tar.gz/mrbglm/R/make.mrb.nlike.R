
# A routine to generate negative log-likelihood function for mrb fit
make.mrb.nlikefun <- function() {
  expression({

    switch(control$criterion,
           NLS = {
             if (control$fixLo) {
               Lovalues <- Lo0
               if (all(Lovalues == 0)) {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       #if (!all(validmu)) {
                       #  if (length(weights) > 1)
                       #    weights <- weights[validmu]
                       #  if (length(sample.weights) > 1) {
                       #   sample.weights <- sample.weights[validmu]
                       #     validsweights <- validsweights[validmu]
                       #  }
                       #}

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
                 else {
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       delta <- theta[(pi + p + 1):(pi + p + q)]
                       mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       delta <- theta[(p+1):(p+q)]
                       mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
               }
               else {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
                 else {
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       delta <- theta[(pi + p + 1):(pi + p + q)]
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       delta <- theta[(p+1):(p+q)]
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                           sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
               }
             }
             else {
               if (control$fixL)  {
                 logLvalues <- log(L0)
                 nlikefun <- if (any(intercepts)) {
                   function(theta) {
                     beta.int <- theta[1:pi]
                     beta <- theta[(pi+1):(pi+p)]
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     eta[intercepts,] <- eta[intercepts,] + beta.int
                     deltao <- theta[(pi + p + 1):(pi + p + qo)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                         sd = 1, log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
                 else {
                   function(theta) {
                     beta <- theta[1:p]
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     deltao <- theta[(p + 1):(p + qo)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                         sd = 1, log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
               }
               else {
                 nlikefun <- if (any(intercepts)) {
                   function(theta) {
                     beta.int <- theta[1:pi]
                     beta <- theta[(pi+1):(pi+p)]
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     eta[intercepts,] <- eta[intercepts,] + beta.int
                     deltao <- theta[(pi + p + 1):(pi + p + qo)]
                     delta <- theta[(pi + p + qo + 1):(pi + p + qo + q)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                         sd = 1, log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
                 else {
                   function(theta) {
                     beta <- theta[1:p]
                     deltao <- theta[(p + 1):(p + qo)]
                     delta <- theta[(p + qo + 1):(p + qo + q)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                         sd = 1, log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
               }
             }
           },
           ML = {
             if (control$fixLo) {
               Lovalues <- Lo0
               if (all(Lovalues == 0)) {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
                 else {
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       delta <- theta[(pi + p + 1):(pi + p + q)]
                       mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)


                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       delta <- theta[(p+1):(p+q)]
                       mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
               }
               else {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
                 else {
                   nlikefun <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       delta <- theta[(pi + p + 1):(pi + p + q)]
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       delta <- theta[(p+1):(p+q)]
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       -sum(res * sample.weights)
                     }
                   }
                 }
               }
             }
             else {
               if (control$fixL)  {
                 logLvalues <- log(L0)
                 nlikefun <- if (any(intercepts)) {
                   function(theta) {
                     beta.int <- theta[1:pi]
                     beta <- theta[(pi+1):(pi+p)]
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     eta[intercepts,] <- eta[intercepts,] + beta.int
                     deltao <- theta[(pi + p + 1):(pi + p + qo)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
                 else {
                   function(theta) {
                     beta <- theta[1:p]
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     deltao <- theta[(p + 1):(p + qo)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu]<- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
               }
               else {
                 nlikefun <- if (any(intercepts)) {
                   function(theta) {
                     beta.int <- theta[1:pi]
                     beta <- theta[(pi+1):(pi+p)]
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     eta[intercepts,] <- eta[intercepts,] + beta.int
                     deltao <- theta[(pi + p + 1):(pi + p + qo)]
                     delta <- theta[(pi + p + qo + 1):(pi + p + qo + q)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
                 else {
                   function(theta) {
                     beta <- theta[1:p]
                     deltao <- theta[(p + 1):(p + qo)]
                     delta <- theta[(p + qo + 1):(p + qo + q)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     -sum(res * sample.weights)
                   }
                 }
               }
             }
           })
  })
}

# Function to contract eta so that a factor has one linear predictor
# Also, for grouped covariates, ensure one linear predictor per group
contract.eta <- function (eta, contract_eta) {

  # No contraction needed
  if (missing(contract_eta))
    return(eta)

  # number of groups
  covgroup <- unique(contract_eta)
  ngroups <- length(covgroup)

  # If each row in eta is a group, no contraction needed
  if (ngroups == length(contract_eta))
    return(eta)

  # A child function to return one row per group
  cfun <- function(j) {

    contract_etaj <- which(contract_eta == j)
    etaj <- eta[contract_etaj,]

    if (length(contract_etaj) == 1) {
      # If one row group

      return(etaj)

    }
    else {
      # If more row in the group

      return(colSums(etaj))

    }

  }

  # For each group, return one row
  out <- sapply(covgroup, FUN = cfun)

  if (ngroups == 1)
    return(out)
  else
    return(t(out))

}
