# A routine to generate observation-wise log-likelihood for mrb fit
# (so observation scores can be obtained for sandwich variance estimation)
make.mrb.likefun_i <- function() {
  expression({

    switch(control$criterion,
           NLS = {
             if (control$fixLo) {
               Lovalues <- Lo0
               if (all(Lovalues == 0)) {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   likefun_i <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       #if (!all(validmu)) {
                       #  if (length(weights) > 1)
                       #    weights <- weights[validmu]
                       #  if (length(sample.weights) > 1) {
                       #   sample.weights <- sample.weights[validmu]
                       #     validsweights <- validsweights[validmu]
                       #  }
                       #}

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                 }
                 else {
                   likefun_i <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       delta <- theta[(pi + p + 1):(pi + p + q)]
                       mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       delta <- theta[(p+1):(p+q)]
                       mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                 }
               }
               else {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   likefun_i <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                 }
                 else {
                   likefun_i <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       delta <- theta[(pi + p + 1):(pi + p + q)]
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       delta <- theta[(p+1):(p+q)]
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                    sd = 1, log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                 }
               }
             }
             else {
               if (control$fixL)  {
                 logLvalues <- log(L0)
                 likefun_i <- if (any(intercepts)) {
                   function(theta) {
                     beta.int <- theta[1:pi]
                     beta <- theta[(pi+1):(pi+p)]
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     eta[intercepts,] <- eta[intercepts,] + beta.int
                     deltao <- theta[(pi + p + 1):(pi + p + qo)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                  sd = 1, log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     res * sample.weights
                   }
                 }
                 else {
                   function(theta) {
                     beta <- theta[1:p]
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     deltao <- theta[(p + 1):(p + qo)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                  sd = 1, log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     res * sample.weights
                   }
                 }
               }
               else {
                 likefun_i <- if (any(intercepts)) {
                   function(theta) {
                     beta.int <- theta[1:pi]
                     beta <- theta[(pi+1):(pi+p)]
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     eta[intercepts,] <- eta[intercepts,] + beta.int
                     deltao <- theta[(pi + p + 1):(pi + p + qo)]
                     delta <- theta[(pi + p + qo + 1):(pi + p + qo + q)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                  sd = 1, log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     res * sample.weights
                   }
                 }
                 else {
                   function(theta) {
                     beta <- theta[1:p]
                     deltao <- theta[(p + 1):(p + qo)]
                     delta <- theta[(p + qo + 1):(p + qo + q)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                                  sd = 1, log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     res * sample.weights
                   }
                 }
               }
             }
           },
           ML = {
             if (control$fixLo) {
               Lovalues <- Lo0
               if (all(Lovalues == 0)) {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   likefun_i <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                 }
                 else {
                   likefun_i <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       delta <- theta[(pi + p + 1):(pi + p + q)]
                       mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)


                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       delta <- theta[(p+1):(p+q)]
                       mu <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(mu + colSums(linkinv(eta, log.p = TRUE)))
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                 }
               }
               else {
                 if (control$fixL)  {
                   logLvalues <- log(L0)
                   likefun_i <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                 }
                 else {
                   likefun_i <- if (any(intercepts)) {
                     function(theta) {
                       beta.int <- theta[1:pi]
                       beta <- theta[(pi+1):(pi+p)]
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       eta[intercepts,] <- eta[intercepts,] + beta.int
                       delta <- theta[(pi + p + 1):(pi + p + q)]
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                   else {
                     function(theta) {
                       beta <- theta[1:p]
                       delta <- theta[(p+1):(p+q)]
                       logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                       eta <- beta * x
                       eta <- contract.eta (eta, contract_eta)
                       eta <- eta + x.offsets
                       mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                       mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                       validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                       res <- numeric(nobs) + log(1e-323)

                       if (length(weights) > 1 & !all(validmu))
                         weights <- weights[validmu]

                       res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                       if (!all(validsweights) & length(sample.weights) > 1) {
                         sample.weights <- sample.weights[validsweights]
                         res <- res[validsweights]
                       }

                       res * sample.weights
                     }
                   }
                 }
               }
             }
             else {
               if (control$fixL)  {
                 logLvalues <- log(L0)
                 likefun_i <- if (any(intercepts)) {
                   function(theta) {
                     beta.int <- theta[1:pi]
                     beta <- theta[(pi+1):(pi+p)]
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     eta[intercepts,] <- eta[intercepts,] + beta.int
                     deltao <- theta[(pi + p + 1):(pi + p + qo)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     res * sample.weights
                   }
                 }
                 else {
                   function(theta) {
                     beta <- theta[1:p]
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     deltao <- theta[(p + 1):(p + qo)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu]<- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     res * sample.weights
                   }
                 }
               }
               else {
                 likefun_i <- if (any(intercepts)) {
                   function(theta) {
                     beta.int <- theta[1:pi]
                     beta <- theta[(pi+1):(pi+p)]
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     eta[intercepts,] <- eta[intercepts,] + beta.int
                     deltao <- theta[(pi + p + 1):(pi + p + qo)]
                     delta <- theta[(pi + p + qo + 1):(pi + p + qo + q)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     res * sample.weights
                   }
                 }
                 else {
                   function(theta) {
                     beta <- theta[1:p]
                     deltao <- theta[(p + 1):(p + qo)]
                     delta <- theta[(p + qo + 1):(p + qo + q)]
                     Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
                     logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                     eta <- beta * x
                     eta <- contract.eta (eta, contract_eta)
                     eta <- eta + x.offsets
                     mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                     mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                     validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                     res <- numeric(nobs) + log(1e-323)

                     if (length(weights) > 1 & !all(validmu))
                       weights <- weights[validmu]

                     res[validmu] <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                     if (!all(validsweights) & length(sample.weights) > 1) {
                       sample.weights <- sample.weights[validsweights]
                       res <- res[validsweights]
                     }

                     res * sample.weights
                   }
                 }
               }
             }
           })

  })
}
