
# interaction terms no longer allowed for glm.mrb (July 01, 2023)

mib.frame <- function() {
  expression({
    # model frame for regressors
    mf <- match.call(expand.dots = FALSE)
    m <- match(c("formula", "data", "subset", "weights", "na.action",
                 "etastart", "mustart", "offset"), names(mf), 0L)
    mf <- mf[c(1L, m)]
    mf$drop.unused.levels <- TRUE
    mf[[1L]] <- quote(stats::model.frame)

    if (!mis.data) {
      if (is.matrix(data))
        mf[[3L]] <- as.data.frame(data)
      else
        mf[[3L]] <- data
    }

    # model frame for measurement error terms
    if (missing(me.formula)) {
      mfZme <- NULL
    }
    else if (is.null(me.formula)) {
      mfZme <- NULL
    }
    else {
      mfZme <- mf
      mfZme$formula <- me.formula
      mfZme <- eval(mfZme, parent.frame())
    }

    # model frame for minimum success probability
    if (missing(minp.formula)) {
      mfZminp <- NULL
    }
    else if (is.null(minp.formula)) {
      mfZminp <- NULL
    }
    else {
      mfZminp <- mf
      mfZminp$formula <- minp.formula
      mfZminp <- eval(mfZminp, parent.frame())
    }

    # model frame for maximum success probability
    if (missing(maxp.formula)) {
      mfZmaxp <- NULL
    }
    else if (is.null(maxp.formula)) {
      mfZmaxp <- NULL
    }
    else {
      mfZmaxp <- mf
      mfZmaxp$formula <- maxp.formula
      mfZmaxp <- eval(mfZmaxp, parent.frame())
    }

    # model frame for offsets of measurement error terms
    if (missing(me.offsets)) {
      mfme.offsets <- NULL
    }
    else if (is.null(me.offsets)) {
      mfme.offsets <- NULL
    }
    else {
      mfme.offsets <- mf
      mfme.offsets$formula <- me.offsets
      mfme.offsets <- eval(mfme.offsets, parent.frame())
    }

    # model frame for offset for minimum success probability
    if (missing(minp.offset)) {
      mfminp.offset <- NULL
    }
    else if (is.null(minp.offset)) {
      mfminp.offset <- NULL
    }
    else {
      mfminp.offset <- mf
      mfminp.offset$formula <- minp.offset
      mfminp.offset <- eval(mfminp.offset, parent.frame())
    }

    # model frame for offset for maximum success probability
    if (missing(maxp.offset)) {
      mfmaxp.offset <- NULL
    }
    else if (is.null(maxp.offset)) {
      mfmaxp.offset <- NULL
    }
    else {
      mfmaxp.offset <- mf
      mfmaxp.offset$formula <- maxp.offset
      mfmaxp.offset <- eval(mfmaxp.offset, parent.frame())
    }

    # model frame for sample weights
    if (missing(sample.weights)) {
      mfw <- NULL
    }
    else if (is.null(sample.weights)) {
      mfw <- NULL
    }
    else {
      mfw <- mf
      mfw$formula <- sample.weights
      mfw <- eval(mfw, parent.frame())
    }

    # model terms for the response
    mf <- eval(mf, parent.frame())
    mt <- attr(mf, "terms")
    Y <- model.response(mf, "any")
    if (length(dim(Y)) == 1L) {
      nm <- rownames(Y)
      dim(Y) <- NULL
      if (!is.null(nm))
        names(Y) <- nm
    }
    intercept <- attr(mt, 'intercept')

    # Checking the size of Y
    Classattr <- attr(mt,"dataClasses")
    if (!identical(Classattr[1], "numeric")) { # when 'Y' is a matrix
      if (NCOL(Y) > 2) {
        warning(gettextf("more than two column for a %s glm!: using only the first two columns",
                         "binomial"), domain = NA)
        Y <- Y[,1:2, drop = FALSE]
      }
    }

    # Model terms for regressors
    X <- if (!is.empty.model(mt))
      stats::model.matrix(mt, mf)
    else matrix(, NROW(Y), 0L)
    p <- NCOL(X)

    # Indicator of columns corresponding to a unique covariate
    contract_eta <- attr(X, "assign")

    # Check that the argument 'intercepts' is consistent with 'formula'
    Classattr <- Classattr[-1]
    factors <- Classattr %in% c("factor", "character")
    orders <- attr(mt,"order")
    high.orders <- orders > 1

    nbcov <- length(factors)
    nonfactors <- !factors
    max_me <- sum(nonfactors & (!high.orders))

    # Remove intercept column, if any
    if (intercept) {
      p <- p - 1
      X <- X[,-1, drop = FALSE]
      contract_eta <- contract_eta[-1]
    }

    # model terms for measurement error terms x.with.me
    if (!is.null(mfZme)) {
      mtZme <- attr(mfZme, "terms")
      if (!is.empty.model(mtZme)) {
        Zme <- stats::model.matrix(mtZme, mfZme)

        if (attr(mtZme, "intercept") > 0L) {
          Zme <- Zme[,-1, drop = FALSE]
        }

        n.zme <- ncol(Zme)
        if (n.zme > max_me) {
          stop("'me.formula' has too many terms: more than numeric predictors in 'formula' (excluding factors and high order terms)")
        }

        # Which x has offset?
        Nb.x.me <- length(x.with.me)
        if (Nb.x.me) {
          if (any(factors)) {
            if (Nb.x.me ==1 && all(x.with.me)) {
              x.with.me <- nonfactors
            }
            else if (Nb.x.me > 1) {
              if (Nb.x.me > nbcov) {
                stop("the length of argument 'x.with.me' must be equal to or less than the number of predictors in 'formula'")
              }
              if (Nb.x.me > max_me) {
                stop("unexpected length of argument 'x.with.me': either specify no measurement error ('FALSE') for all factor predictors and high order terms, or do not specify any for them")
              }
            }
          }
          else {
            if (Nb.x.me == 1) {
              x.with.me <- rep(x.with.me, length.out = max_me)
            }
          }
        }
        else {
          if (n.zme == max_me)
            x.with.me <- rep(TRUE, n.zme)
          else {
            stop("specify 'x.with.me' to indicate which regression covariates have measurement error terms")
          }
        }

        # Consistency of 'x.with.me' and formula 'me.formula'
        if (sum(x.with.me) != n.zme)
          stop("inconsistent formula 'me.formula' and argument 'x.with.me'")

        # intercepts for measurement errors (me.intercepts)
        if (!missing(me.intercepts)) {
          stopifnot(is.logical(me.intercepts))
          Nb.int <- length(me.intercepts)
          if (Nb.int > 1) {
            if (Nb.int > n.zme) {
              stop("the length of argument 'me.intercepts' must be equal to or less than the number of right hand side terms in 'me.formula'")
            }
            if (Nb.int < n.zme) {
              me.intercepts <- c(me.intercepts, rep(FALSE, n.zme - Nb.int))
            }
          }
        }
        else {
          me.intercepts <- rep(FALSE, n.zme)
        }
      }
      else {
        Zme <- NULL
        me.intercepts <- FALSE
      }
    }
    else {
      n.zme <- 0
      Zme <- mtZme <- x.with.me <- NULL
      me.intercepts <- FALSE
    }

    # model terms for minimum success probability
    if (!is.null(mfZminp)) {
      mtZminp <- attr(mfZminp, "terms")
      Zminp <- if (!is.empty.model(mtZminp))
        stats::model.matrix(mtZminp, mfZminp)
      else NULL
    }
    else {
      mtZminp <- NULL
      Zminp <- NULL
    }

    # model terms for maximum success probability
    if (!is.null(mfZmaxp)) {
      mtZmaxp <- attr(mfZmaxp, "terms")
      Zmaxp <- if (!is.empty.model(mtZmaxp))
        stats::model.matrix(mtZmaxp, mfZmaxp)
      else NULL
    }
    else {
      mtZmaxp <- NULL
      Zmaxp <- 1
    }

    # model terms for offsets of measurement error terms
    if (!is.null(mfme.offsets)) {
      mtme.offsets <- attr(mfme.offsets, "terms")
      if (!is.empty.model(mtme.offsets)) {
        Me.offsets <- stats::model.matrix(mtme.offsets, mfme.offsets)
        if (attr(mtme.offsets, "intercept") > 0L) {
          Me.offsets <- Me.offsets[,-1, drop = FALSE]
        }

        n.meoffset <- NCOL(Me.offsets)
        if (n.meoffset) {
          if (n.meoffset > max_me) {
            stop("'me.offsets' has too many terms (more than numeric predictors in 'formula')")
          }

          # Which x has me offset?
          Nb.me.offsets <- length(x.with.me.offsets)
          if (Nb.me.offsets) {
            if (Nb.me.offsets ==1 && all(x.with.me.offsets)) {
              x.with.me.offsets <- nonfactors
            }
            else if (Nb.me.offsets ==1) {
              x.with.me.offsets <- rep(FALSE, nbcov)
            }
            else if (Nb.me.offsets > 1) {
              if (Nb.me.offsets > nbcov) {
                stop("the length of argument 'x.with.me.offsets' must be equal to or less than the number of predictors in 'formula'")
              }
              if (Nb.me.offsets == max_me) {
                me.with.offsets0 <- x.with.me.offsets
                x.with.me.offsets <- nonfactors
                x.with.me.offsets[nonfactors] <- me.with.offsets0
              }
              else {
                x.with.me.offsets <- c(x.with.me.offsets, rep(FALSE, nbcov - Nb.me.offsets))
              }
            }
          }
          else {
            if (n.meoffset == max_me)
              x.with.me.offsets <- rep(TRUE, n.meoffset)
            else {
              stop("specify 'x.with.me.offsets' to indicate which measurement error covariates have 'offsets'")
            }
          }

          # Consistency of 'x.with.me.offsets' and formula 'me.offsets'
          if (sum(x.with.me.offsets) != n.meoffset)
            stop("inconsistent formula 'me.offsets' and argument 'x.with.me.offsets'")

          # Fill the matrix of offsets
          Me.offsets0 <- Me.offsets
          Me.offsets <- matrix(0, nrow = NROW(X), ncol = nbcov)
          Me.offsets[, which(x.with.me.offsets)] <- Me.offsets0; rm(Me.offsets0)

          # Is the offsets constant across variables and observations?
          if (all(Me.offsets == Me.offsets[1]))
            Me.offsets <- Me.offsets[1] # Simplify if Yes
        }
        else {
          Me.offsets <- 0
        }
      }
      else
        Me.offsets <- 0
    }
    else {
      x.with.me.offsets <- NULL
      Me.offsets <- 0
    }

    # model terms for offsets of minimum success probability
    if (!is.null(mfminp.offset)) {
      mtminp.offset <- attr(mfminp.offset, "terms")
      if (!is.empty.model(mtminp.offset)) {
        Minp.offset <- stats::model.matrix(mtminp.offset, mfminp.offset)
        if (attr(mtminp.offset, "intercept") > 0L) {
          Minp.offset <- Minp.offset[,-1, drop = FALSE]
        }
        Minp.offset <- rowSums(Minp.offset)
        if (all(Minp.offset == Minp.offset[1]))
          Minp.offset <- Minp.offset[1]
      }
      else
        Minp.offset <- 0
    }
    else {
      Minp.offset <- 0
    }

    # model terms for offsets of maximum success probability
    if (!is.null(mfmaxp.offset)) {
      mtmaxp.offset <- attr(mfmaxp.offset, "terms")
      if (!is.empty.model(mtmaxp.offset)) {
        Maxp.offset <- stats::model.matrix(mtmaxp.offset, mfmaxp.offset)
        if (attr(mtmaxp.offset, "intercept") > 0L) {
          Maxp.offset <- Maxp.offset[,-1, drop = FALSE]
        }
        Maxp.offset <- rowSums(Maxp.offset)
        if (all(Maxp.offset == Maxp.offset[1]))
          Maxp.offset <- Maxp.offset[1]
      }
      else 0
    }
    else {
      Maxp.offset <- 0
    }

    # model terms for offsets of sample weights (i.e. weights for log-likelihood contributions)
    if (!is.null(mfw)) {
      mtw <- attr(mfw, "terms")
      if (!is.empty.model(mtw)) {
        sample.weights <- stats::model.matrix(mtw, mfw)
        if (attr(mtw, "intercept") > 0L && NCOL(sample.weights) > 1) {
          sample.weights <- sample.weights[,2, drop = TRUE]
        }
        else {
          sample.weights <- sample.weights[,1, drop = TRUE]
        }
        invalidsw <- sample.weights <= 0
        if (all(invalidsw)) {
          stop("invalid column specified in the formula 'sample.weights': no positive weight found")
        }
      }
      else
        sample.weights <- 1
    }
    else {
      mtw <- NULL
      sample.weights <- 1
    }

    # Weights (number of trials) for the binomial distribution
    weights <- as.vector(model.weights(mf))
    if (is.null(weights))
      weights <- 1
    else {
      if (!is.numeric(weights))
        stop("'weights' must be a numeric vector")
      if (any(weights < 0))
        stop("negative weights not allowed")
    }

    offset <- as.vector(model.offset(mf))
    if (!is.null(offset)) {
      if (length(offset) != NROW(Y))
        stop(gettextf("number of offsets is %d should equal %d (number of observations)",
                      length(offset), NROW(Y)), domain = NA)
    }

    mustart <- stats::model.extract(mf, "mustart")
    etastart <- stats::model.extract(mf, "etastart")
  })
}
