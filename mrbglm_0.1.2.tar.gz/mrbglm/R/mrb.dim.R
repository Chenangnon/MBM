
mrb.dim <- function() {
  expression({
    ### Dimensions and weights
    x <- as.matrix(x)
    nobs <- NROW(x)
    p <- NCOL(x)
    nbcovs <- length(unique(contract_eta))
    zero.x.var <- apply(x, MARGIN = 2, var) == 0
    if (any(zero.x.var)) {
      warning(paste0("constant columns in 'x' declared as non-intercept: ",
                     paste((1:p)[zero.x.var], collapse = ', '), "."))
    }

    if (is.null(x.offsets))
      x.offsets <- 0
    else {
      if (NCOL(x.offsets) != p & length(x.offsets) > 1)
        stop("'x.offsets' must be a scalar or have the same size as 'x'")
    }

    qo <- if(is.null(zminp)) 0 else NCOL(zminp)
    if (qo > 0) {
      if (all(zminp == 1)) {
        zminp <- fit.call$zminp <-  1
        qo <- 1
      }
    }
    q <- if(is.null(zmaxp)) 0 else NCOL(zmaxp)
    if (q > 0) {
      if (all(zmaxp == 1)) {
        zmaxp <- fit.call$zmaxp <- 1
        q <- 1
      }
    }

    validsweights <- !is.na(sample.weights) & (sample.weights > 0)
    if (length(sample.weights) > 1) {
      sample.weights <- nobs * sample.weights / sum(sample.weights, na.rm = TRUE)
    }
    else {
      sample.weights <- 1
    }
    ssize <- max(nobs, sum(weights)) # Just in case weights = 1
    prior.weights <- weights
    if (!is.na(var.w <- var(weights))) {
      if (var.w == 0) {
        weights <- weights[1]
      }
    }

    # Checking 'y'
    if (NCOL(y) == 1) {
      if (is.factor(y))
        y <- y != levels(y)[1L]
      y[weights == 0] <- 0
      if (any(y < 0 | y > weights))
        stop("y values must be 0 <= y <= weights")
      if (is.null(mustart))
        mustart <- (weights * y + 0.5)/(weights + 1)
      m <- weights * y
      if (any(abs(m - round(m)) > 0.001))
        warning(gettextf("non-integer #successes in a %s glm!",
                         "binomial"), domain = NA)
    }
    else if (NCOL(y) == 2) {
      if (any(abs(y - round(y)) > 0.001))
        warning(gettextf("non-integer counts in a %s glm!",
                         "binomial"), domain = NA)
      ntrials <- (y1 <- y[, 1L]) + y[, 2L]
      y <- y1
      if (any(n0 <- ntrials == 0))
        y[n0] <- 0
      weights <- weights * ntrials
      if (is.null(mustart))
        mustart <- (y + 0.5)/(ntrials + 1)
    }
    else stop(gettextf("for the '%s' family, y must be a vector of 0 and 1's\nor a 2 column matrix where col 1 is no. successes and col 2 is no. failures",
                       "binomial"), domain = NA)

    # Intercepts or not?
    if (length(intercepts) != nbcovs) {
      if (length(intercepts) == 1) {
        intercepts <- rep(intercepts[1], nbcovs)
      }
      else
        stop("inconsistent arguments 'contract_eta' and 'intercepts'")
    }
  })
}
