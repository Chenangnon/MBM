#' Log-Likelihood of a Multiplicative Risk Binomial Model
#'
#' Compute the negative log-likelihood for a multiplicative risk binomial model
#'
#' @param theta numeric vector of model parameters at which the function is to be evaluated.
#'
#' @param y numeric vector of binomial responses.
#'
#' @param weights numeric integer vector of sizes (number of trials) for
#' the response/observations in \code{y}.
#'
#' @param x numeric matrix of predictors for the expected value of the response
#' \code{y}.
#'
#' @param intercepts logical vector, indicating for each column of \code{x}
#' whether an intercept should be added in the corresponding linear predictor
#' or not.
#'
#' @param z numeric matrix of predictors for the limit success probability of
#' the response \code{y}.
#'
#' @param offset numeric vector of offsets for the linear predictor he limit
#' success probability of the response \code{y}.
#'
#' @param linkinv function, the inverse link function to be used to convert each
#' linear predictor into a probability value.
#'
#' @param overall logical, should the sum of the negative log-likelihood values
#' over all individual responses be rerurned? Defaults to \code{overall = TRUE}.
#'
#' @export nlike.mrb
#' @import stats
#'
#' @return If \code{overall = TRUE}, a scalar: the negative log-likelihood value
#' of the  whole sample in \code{y}.
#'
#' If \code{overall = FALSE}, a numeric vector of the negative log-likelihood
#' value of the individual responses in \code{y}.
#'

nlike.mrb <- function(theta, y, weights = 1,
                      x, intercepts, z = 1, offset = 0,
                      linkinv = stats::plogis,
                      overall = TRUE) {
  #-------- Covariates and regression coefficients ---------#
  x <- as.matrix(x)
  p <- NCOL(x)
  nobs <- NROW(x)
  if (length(weights) > 1) {
    if (length(weights)  != nobs)
      stop("inconsistent sizes of arguments 'x' and 'weights'")
  }
  z <- as.matrix(z)
  if (!missing(z)) {
    z <- as.matrix(z)
    q <- NCOL(z)
  }
  else {
    q <- 1
  }
  n.coefs <- length(theta)
  if (!missing(intercepts)) {
    return(nlike.mrb.pi (theta = theta, y = y, weights = weights,
                      x = x, intercepts = intercepts > 0, z = z,
                      nobs = nobs, p = p, q = q, n.coefs = n.coefs,
                      offset = offset, linkinv = linkinv,
                      overall = overall))
  }
  if (n.coefs == p + q) {
    full.intercepts <- FALSE
    beta <- theta[1:p]
    delta <- theta[(p+1):(p+q)]
  }
  else if (n.coefs == (2 * p + q)) {
    full.intercepts <- TRUE
    x.intercepts <- rep(1, nobs)
    beta.int <- theta[seq(1, 2 * p - 1, 2)]
    beta <- theta[seq(2, 2 * p, 2)]
    delta <- theta[(2 * p + 1):(2 * p + q)]
  }
  else if (n.coefs == (2 * (p - 1) + q)) {
    full.intercepts <- TRUE
    x.intercepts <- x[,1]
    p <- p - 1
    x <- x[,-1, drop = FALSE]
    beta.int <- theta[seq(1, 2 * p - 1, 2)]
    beta <- theta[seq(2, 2 * p, 2)]
    delta <- theta[(2 * p + 1):(2 * p + q)]
  }
  else
    stop("inconsistent sizes of arguments 'theta', 'x', and 'z'")

  #-------- Asymptotic limit of the response success prob. ---------#
  mu <- linkinv(offset + c(z %*% delta), log.p = TRUE)

  #-------- Response success prob. ---------------------------------#
  if (!full.intercepts) {
    eta <- beta * t(x)
    mu <-  exp(mu + colSums(linkinv(eta, log.p = TRUE)))
  }
  else {
    eta <- outer(beta.int, x.intercepts)
    eta <- eta + beta * t(x)
    mu <-  exp(mu + colSums(linkinv(eta, log.p = TRUE)))
  }

  #-------- Log-likelihood value -----------------------------------#
  validmu <- is.finite(mu) & (mu > 0 & mu < 1)
  if (!all(validmu) & length(weights) > 1)
    weights <- weights[validmu]
  res <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
  if (!overall)
    return(-res)
  -sum(res)
}

# The function when 'intercepts' is supplied
nlike.mrb.pi <- function(theta, y, weights = 1,
                         x, intercepts, z = 1, offset = 0,
                         nobs = NROW(x), p = NCOL(x), q, n.coefs,
                         linkinv = stats::plogis,
                         overall = TRUE) {
  #-------- Covariates and regression coefficients ---------#
  if (length(intercepts) != p) {
    if (length(intercepts) == 1) {
      intercepts <- rep(intercepts[1], p)
    }
    else
      stop("inconsistent arguments 'x', 'intercepts'")
  }
  pi <- sum(intercepts)
  full.intercepts <- pi > 0
  zero.x.var <- apply(x, MARGIN = 2, var) == 0
  if (!full.intercepts) {
    if (n.coefs == p + q) {
      beta <- theta[1:p]
      delta <- theta[(p+1):(p+q)]
      x.intercepts <- 1
    }
    else if (n.coefs == p + q - 1) {
      zero.x.var <- apply(x, MARGIN = 2, var) == 0
      if (sum(zero.x.var) == 1) {
        warning(paste0("removing a constant columns from 'x': ",
                       paste((1:p)[zero.x.var], collapse = ', '), "."))
        x.intercepts <- x[,zero.x.var, drop = FALSE]
        x <- x[,!zero.x.var, drop = FALSE]
        p <- p - 1
        beta <- theta[1:p]
        delta <- theta[(p+1):(p+q)]
      }
      else {
        stop("inconsistent arguments 'x', 'intercepts' and 'beta'")
      }
    }
    else
      stop("inconsistent arguments 'x', 'intercepts' and 'beta'")
  }
  else {
    if (n.coefs == p + pi + q) {
      x.intercepts <- 1
      if (any(zero.x.var)) {
        warning(paste0("constant columns in 'x' declared as non-intercept: ",
                       paste((1:p)[zero.x.var], collapse = ', '), "."))
      }
      beta <- theta[1:(p + pi)]
      delta <- theta[(p + pi + 1):(p + pi + q)]
    }
    else if (n.coefs == p + pi - 1) {
      if (sum(zero.x.var) == 1) {
        warning(paste0("removing a constant columns from 'x': ",
                       paste((1:p)[zero.x.var], collapse = ', '), "."))
        x.intercepts <- x[,zero.x.var, drop = FALSE]
        x <- x[,!zero.x.var, drop = FALSE]
        p <- p - 1
        beta <- theta[1:(p + pi)]
        delta <- theta[(p + pi + 1):(p + pi + q)]
      }
      else {
        stop("inconsistent arguments 'x', 'intercepts' and 'beta'")
      }
    }
    else {
      stop("inconsistent arguments 'x', 'intercepts' and 'beta'")
    }
  }

  #-------- Asymptotic limit of the response success prob. ---------#
  mu <- linkinv(offset + c(z %*% delta), log.p = TRUE)

  #-------- Response success prob. ---------------------------------#
  if (!full.intercepts) {
    eta <- beta * t(x)
    mu <-  exp(mu + colSums(linkinv(eta, log.p = TRUE)))
  }
  else {
    if (!all(intercepts)) {
      cintercepts <- cumsum(intercepts)
      eta <- sapply(1:p, FUN = function(j) {
        j1 <- j + cintercepts[j]
        if (intercepts[j])
          beta[j1-1] * x.intercepts + beta[j1] * x[,j]
        else
          beta[j1] * x[,j]
      })
      mu <-  exp(mu + rowSums(linkinv(eta, log.p = TRUE)))
    }
    else {
      beta.int <- beta[seq(1, n.coefs - 1, 2)]
      beta <- beta[seq(2, n.coefs, 2)]
      eta <- if (length(x.intercepts) > 1)
        outer(beta.int, x.intercepts)
      else beta.int
      eta <- eta + beta * t(x)
      mu <-  exp(mu + colSums(linkinv(eta, log.p = TRUE)))
    }
  }

  #-------- Log-likelihood value -----------------------------------#
  validmu <- is.finite(mu) & (mu > 0 & mu < 1)
  if (!all(validmu) & length(weights) > 1)
    weights <- weights[validmu]
  res <- stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
  if (!overall)
    return(-res)
  -sum(res)
}
