
### method "lbfgs" has been excluded

## Wrap opm (in mrbglm) over a set of starting parameter vectors

optim.mrb <- function (start,
                       nb.betas,          # integer, number of regression parameters (intercepts and slopes)
                       nlikefun,          # negative log-likelihood function, taking one scalar or numeric vector argument and returning a scalar.
                       control = list(),  # list of control argument, as returned by 'control.mrb'
                       lower = -Inf,
                       upper = Inf,
                       cl = NULL) {       # an optional a cluster object for parallel computing using the package 'parallel'

  ### Save the call
  mcall <- match.call()

  ### Check arguments
  control <- do.call("control.mrb", control)
  method <- unique(control$method)
  stopifnot(all(method %in% c("BFGS", "CG", "Nelder-Mead", "L-BFGS-B", "nlm",
                              "nlminb", "lbfgsb3c", "Rcgmin", "Rtnmin", "Rvmmin", "snewton",
                              "snewtonm", "spg", "ucminf", "newuoa", "bobyqa", "nmkb",
                              "hjkb", "hjn", "subplex", "ALL")))
  if ("ALL" %in% method)
    method <- "ALL"

  ### Preparing a list of starting parameter values
  # Varying values of beta in the supplied 'start' argument
  nparams <- length(start)
  nb.others <- nparams - nb.betas # Number of all other parameters
  stopifnot(nb.others >= 0)
  start.matrix <- rbind(start = start)

  if (control$nbeta.steps + control$nother.steps > 0) {
    if (control$trace) {
      cat("\n*         Generating additional starting parameter vectors.\n")
    }

    if (nb.betas > 0 & control$nbeta.steps > 0) {
      bsteps <- c(-c(control$nbeta.steps:1), 1:control$nbeta.steps)
      stopifnot(length(control$beta.step) %in% c(1, nb.betas))
      control$beta.step <- rep(control$beta.step, length.out = nb.betas)
      betastart <- start[1:nb.betas]
      add.beta <- replicate (control$nbeta.steps * 2, start)
      add.beta[1:nb.betas,] <- replicate(control$nbeta.steps * 2, betastart) +
        outer(control$beta.step, bsteps)
      add.beta <- t(add.beta)
      rownames(add.beta) <- c(paste0("start.b_", control$nbeta.steps:1),
                              paste0("start.b", 1:control$nbeta.steps))
      start.matrix <- rbind(start.matrix,
                            add.beta)
    }

    # Varying values of delta in the supplied 'start' argument
    if ((nb.others > 0 & !control$fixL) & control$nother.steps > 0) {
      dsteps <- c(-c(control$nother.steps:1), 1:control$nother.steps)
      stopifnot(length(control$other.step) %in% c(1, nb.others))
      control$other.step <- rep(control$other.step, length.out = nb.others)
      deltastart <- start[(nb.betas + 1):nparams]
      add.other <- replicate (control$nother.steps * 2, start)
      add.other[(nb.betas + 1):nparams,] <- replicate(control$nother.steps * 2, deltastart) +
        outer(control$other.step, dsteps)
      add.other <- t(add.other)
      rownames(add.other) <- c(paste0("start.o_", control$nother.steps:1),
                               paste0("start.o", 1:control$nother.steps))
      start.matrix <- rbind(start.matrix,
                            add.other)
    }

    # Varying values of both beta and delta in the supplied 'start' argument
    if (all(c(control$step.degree > 1, nb.betas > 0, nb.others > 0 , !control$fixL,
              control$nbeta.steps > 0, control$nother.steps > 0))) {
      dnames0 <- c(paste0(".d_", control$nother.steps:1),
                   paste0(".d", 1:control$nother.steps))
      bnames0 <- rownames(add.beta)
      add.beta2 <- matteLapply(X = bsteps,
                               FUN = function(k) {
                                 j <- k + control$nbeta.steps  + if (k < 0) 1 else 0
                                 add.betaj <- add.beta[j,]
                                 res <- t(rbind(replicate(control$nother.steps * 2, add.betaj[1:nb.betas]),
                                                t(add.other[,(nb.betas + 1):nparams, drop = FALSE])))
                                 if (k < 0) {
                                   bnames <- paste0("start.b",  "_", -k, dnames0)
                                 }
                                 else {
                                   bnames <- paste0("start.b", k, dnames0)
                                 }
                                 rownames(res) <- bnames
                                 res
                               },
                               cl = control$cl,
                               chunk.size = control$chunk.size)
      add.beta2 <- do.call('rbind', add.beta2)
      add.delta2 <- matteLapply(X = dsteps,
                                FUN = function(k) {
                                  j <- k + control$nother.steps  + if (k < 0) 1 else 0
                                  add.deltaj <- add.other[j,]
                                  res <- t(rbind(t(add.beta[,1:nb.betas, drop = FALSE]),
                                                 replicate(control$nbeta.steps * 2, add.deltaj[(nb.betas + 1):nparams])))
                                  if (k < 0) {
                                    dnames <- paste0(bnames0, ".o",  "_", -k)
                                  }
                                  else {
                                    dnames <- paste0(bnames0, ".o", k)
                                  }
                                  rownames(res) <- dnames
                                  res
                                },
                                cl = control$cl,
                                chunk.size = control$chunk.size)
      add.delta2 <- do.call('rbind', add.delta2)
      start.matrix <- rbind(start.matrix,
                            add.beta2,
                            add.delta2)
      rm(add.beta2, add.delta2)
    }

    npars.add <- NROW(start.matrix)
    if (control$trace) {
      cat(paste0("\n          ", npars.add - 1, " additional starting parameter vectors generated.\n"))
    }

    ### Next call the 'opm' function from package 'optimx' for each row of 'start.matrix'
    if (control$trace) {
      cat("\n*         Running 'optimx::opm' over the set of starting parameter vectors.\n")
    }
  }

  results <- catch.conditions({
    matteApply(start.matrix,
               MARGIN = 1,
               FUN = opm,
               fn = nlikefun,
               # gr = NULL, hess = NULL,
               lower = lower, upper = upper,
               method = method,
               hessian = identical(control$final.method, "none"),
               control = control,
               simplify = FALSE,
               cl = control$cl,
               chunk.size = control$chunk.size)
  })$value

  details <- results

  bestresult <- NULL
  main <- NULL
  if (any(class(results) %in% c("simpleError", "error", "condition", "try-error"))) {
    cat("\n Oups ... \n")

    print(results)

  }
  else {

    main <- sapply(results, FUN = function(x) {
      x$main[1,]
    })

    if(is.matrix(main))
      main <- t(main)
    else
      main <- rbind(main)

    best.par.row.index <- main[, nparams + 1]

    best.par.row.index[!is.na(main[, nparams + 1])] <- Inf

    best.par.row.index <- which(best.par.row.index == min(best.par.row.index))

    par <- main[best.par.row.index[1], 1:nparams]

    if (is.null(control$final.method)) {
      control$final.method <- "Nelder-Mead"
    }
    else if (!control$final.method %in%
        c("Nelder-Mead", "BFGS", "CG", "L-BFGS-B", "SANN", "Brent")) {
      control$final.method <- "Nelder-Mead"
    }

    bestresult <- catch.conditions({
      stats::optim(par = par, fn = nlikefun,
                   method = control$final.method,
                   control = list(maxit = control$maxit,
                                  reltol = control$epsilon),
                   hessian = TRUE)
    })$value

  }

  return(list(main = main, finalresult = bestresult, details = results, call = mcall))
}
