
# Internal routine
# First generate (and save into the package namespace) a matrix
# of the function values for eta (rows) and sd (columns) values.
# Use pracma::barylag2d to interpolate
# Save the pracma::barylag2d returned object to build an
# interpolating function: DONE

plogis.menorm.interp <- function(eta, abs.tol = 1e-8) {

}
