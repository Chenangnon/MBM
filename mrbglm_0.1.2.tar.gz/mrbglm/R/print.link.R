
#'
# @param x description
#'
#' @exportS3Method print link
#'
#'
print.link <- function(x, ...) {
  cat("\nFamily:", x$family)
  cat("\nLink function:", x$link, "\n")
  mefamilyname <- switch(x$mefamilyname,
                         norm   = "Gaussian",
                         logis  = "Logistic",
                         bridge = "Bridge",
                         x$mefamilyname)
  cat("Measurement error family:", mefamilyname, "\n\n")
  invisible(x)
}
