#' Print the summary of a Multiplicative Risk Binomial Regression Model Fit
#'
#' Printing the summary of a Multiplicative Risk Binomial Regression Model Fit.
#' This is a method for class \code{summary.mrbglm}.
#'
#' @param x an object of class \code{"summary.mrbglm"}, typically, a result of a call to
#' \link{summary.mrbglm}.
#'
#' @param digits the number of significant digits to use when printing.
#'
#' @param symbolic.cor logical, if \code{TRUE}, print the correlations in a symbolic form (see \link{symnum}) rather than as numbers.
#'
#' @param signif.stars logical. If \code{TRUE}, ‘significance stars’ are printed for each coefficient.
#'
#' @param me logical, should a summary of measurement errors be printed, if any?
#'
#' @param ... further arguments passed to or from other methods.
#'
#' @details The function \code{print.summary.mrbglm} is a slight modification of
#' \code{print.summary.glm}.
#'
#' @return invisibly \code{x}, after printing the main features of the object.
#'
#' @exportS3Method print summary.mrbglm
#' @export print.summary.mrbglm
#'
#' @examples
#' # Example 1
#' set.seed(10)
#' mrbdata = sim.mrb (beta = c(1, -2),
#'                    x = cbind(x1 = runif(100, min = -10, max = 5),
#'                              x2 = runif(100, min = -5, max = 10)),
#'                    delta = qlogis(.66))$data
#'
#' MRBfit = glm.mrb (y ~ x1 + x2, data = mrbdata)
#'
#' summary(MRBfit)
#'
print.summary.mrbglm <- function (x, digits = max(3L, getOption("digits") - 3L),
                                  symbolic.cor = x$symbolic.cor,
                                  signif.stars = getOption("show.signif.stars"),
                                  me = FALSE, ...)
{
  cat("\nCall:\n", paste(deparse(x$call), sep = "\n", collapse = "\n"),
      "\n\n", sep = "")
  cat("Deviance Residuals: \n")
  if (x$df.residual > 5) {
    x$deviance.resid <- setNames(quantile(x$deviance.resid,
                                          na.rm = TRUE),
                                 c("Min", "1Q", "Median", "3Q", "Max"))
  }
  xx <- zapsmall(x$deviance.resid, digits + 1L)
  print.default(xx, digits = digits, na.print = "", print.gap = 2L)
  if (length(x$aliased) == 0L) {
    cat("\nNo Coefficients\n")
  }
  else {
    df <- if ("df" %in% names(x))
      x[["df"]]
    else NULL
    if (!is.null(df) && (nsingular <- df[3L] - df[1L]))
      cat("\nCoefficients: (", nsingular, " not defined because of singularities)\n",
          sep = "")
    else cat("\nCoefficients:\n")
    coefs <- x$coefficients
    if (!is.null(aliased <- x$aliased) && any(aliased)) {
      cn <- names(aliased)
      coefs <- matrix(NA, length(aliased), 4L, dimnames = list(cn,
                                                               colnames(coefs)))
      coefs[!aliased, ] <- x$coefficients
    }
    printCoefmat(coefs, digits = digits, signif.stars = signif.stars,
                 na.print = "NA", ...)
  }
  if (identical(x$criterion, "NLS"))
    cat("\n(Dispersion parameter for the Gaussian family taken to be ",
        format(x$dispersion, digits = digits), ")\n")
  else
    cat("\n(Dispersion parameter for the binomial family taken to be ",
        format(x$dispersion), ")\n")

  cat("\nSuccess probability limits")
  Lo <- x$Lo.values * x$L.values
  if (length(Lo) == 1 & length(x$L.values) == 1) {
    cat(": (")
    cat(format(c(Minimum = Lo[1]), digits = digits))
    cat(",  ")
    cat(format(c(Maximum = x$L.values[1]), digits = digits))
    cat(") ")
  }
  else {
    cat("\n     Minimum: ")
    if (all(Lo == Lo[1]))
      cat(format(c(Minimum = Lo[1]), digits = digits))
    else {
      cat("\n ")
      print.default(format(summary(Lo), digits = digits),
                    print.gap = 2, quote = FALSE)
    }
    cat("\n     Maximum: ")
    if (all(x$L.values == x$L.values[1]))
      cat(format(c(Maximum = x$L.values[1]), digits = digits))
    else {
      cat("\n ")
      print.default(format(summary(x$L.values), digits = digits),
                    print.gap = 2, quote = FALSE)
    }
  }

  if (length(x$me.mat) & me) {
    cat("\n\nStandard deviation(s) of measurement error(s): ")
    cat("\n ")
    print.default(format(summary(x$me.mat), digits = digits),
                  print.gap = 2, quote = FALSE)
  }

  cat("\n\n", apply(cbind(paste(format(c("Null", "Residual"),
                                       justify = "right"), "deviance:"),
                          format(unlist(x[c("null.deviance", "deviance")]),
                                 digits = max(5L, digits + 1L)),
                          " on", format(unlist(x[c("df.null", "df.residual")])),
                          " degrees of freedom\n"),
                    1L, paste, collapse = " "), sep = "")
  if (nzchar(mess <- naprint(x$na.action)))
    cat("  (", mess, ")\n", sep = "")
  cat("AIC: ", format(x$aic, digits = max(4L, digits + 1L)),
      "\n\n", sep = "")
  correl <- x$correlation
  if (!is.null(correl)) {
    p <- NCOL(correl)
    if (p > 1) {
      cat("\nCorrelation of Coefficients:\n")
      if (is.logical(symbolic.cor) && symbolic.cor) {
        print(symnum(correl, abbr.colnames = NULL))
      }
      else {
        correl <- format(round(correl, 2L), nsmall = 2L,
                         digits = digits)
        correl[!lower.tri(correl)] <- ""
        print(correl[-1, -p, drop = FALSE], quote = FALSE)
      }
    }
  }
  cat("\n")
  invisible(x)
}
