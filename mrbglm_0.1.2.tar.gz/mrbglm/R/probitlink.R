# make.me.family; return class me-family

#' Link Objects for Model Fitting
#'
#' Link objects provide a convenient way to specify the details of the links
#' used by model fitting functions such as \link{glm.mrb}.
#'
#' @param me.family a specification for the measurement error model family.
#' This can be a name/expression, a literal character string, a length-one
#' character vector, or an object of class \code{"me-family"} (such as generated
#' by \link{make.me.family}) provided it is not specified \code{via} one of the
#' standard names given next.
#'
#' The default \code{me.family = "canonical"} picks the natural (or conjugate)
#' measurement distribution family for a given link function \code{link}: that is
#' the distribution \code{distr} such that the mixture of the inverse link function
#' (which is a cdf) by \code{distr} is of the same family as this inverse link
#' function. For the \code{probit} link, the conjugate family is the Gaussian
#' (\code{"norm"}), and for the \code{logit} link, the conjugate family is the
#' Bridge (\code{bridge}).
#'
#' Both \code{probit} and \code{logit} links accepts the families (as names)
#' \code{norm}, \code{logis} and \code{bridge} (corresponding to the Gaussian,
#' Logistic and Bridge distribution families, respectively).
#'
#' @param object the function \code{link} accesses the link of objects which are
#' stored within objects created by modelling functions (e.g., \code{glm.mrb}).
#'
#' @param ... Additional arguments passed to or from other methods.
#'
#' @usage
#' link(object, ...)
#'
#' probit(me.family = "canonical")
#'
#' logit(me.family = "canonical")
#'
#' @details
#' \code{link} is a generic function with methods for classes \code{"mrbglm"} and
#' \code{"memrb.fit"}.
#'
#' @return An object of class \code{"link"} (which has a concise \code{print}
#' method). This is a list with elements
#'
#' \item{family}{character: the family name of the response (i.e. \code{"binomial"}).}
#' \item{link}{character: the link name.}
#' \item{linkfun}{function: the link.}
#' \item{linkinv}{function: the inverse of the link function.}
#' \item{mefamilyname}{character: the measurement error distribution family name.}
#' \item{mefamily}{a measurement error family, object of class \code{"me-family"}
#' as returned by \link{make.me.family}}
#' \item{melinkinv}{function: the inverse link function accounting for
#' measurement errors.}
#' \item{variance,dev.resids}{Same as for \link{family}.}
#' \item{aic,mu.eta,simulate}{Same as for \link{family}.}
#'
#' @author The design was inspired by \code{R}'s \link{family} functions.
#'
#' @export probit
#' @export logit
#' @export link
#'
#' @aliases link logit
#'
#' @exportMethod link
#'
#' @import stats
#'
#' @seealso
#' \link{make.me.family}.
#'

probit <- function (me.family = "canonical") {
  familytemp <- substitute(me.family)
  if (!is.character(familytemp))
    familytemp <- deparse(familytemp)
  okFams <- c("canonical", "norm", "logis", "bridge")
  link <- "probit"
  if (familytemp %in% okFams[-1]) {
    familystats <- make.me.family (familytemp)
  }
  else if (identical(me.family, "canonical")) {
    familytemp <- "norm"
    familystats <- make.me.family (familytemp)
  }
  else if (is.character(me.family)) {
    familystats <- make.me.family (me.family)
  }
  else {
    if (inherits(me.family, "me-family")) {
      familystats <- me.family
    }
    else {
      stop(gettextf("me.family \"%s\" not available for %s link; available me.families are %s",
                    me.family, link, paste(sQuote(okFams), collapse = ", ")),
           domain = NA)
    }
  }

  if (is.null(familystats$name))
    familystats$name <- familytemp

  linkfun <- function(mu, lower.tail = TRUE, log.p = FALSE) {
    qnorm(mu, lower.tail = lower.tail, log.p = log.p)
  }

  linkinv <- function(eta, lower.tail = TRUE, log.p = FALSE) {
    thresh <- -qnorm(.Machine$double.eps)
    eta <- pmin(pmax(eta, -thresh), thresh)
    pnorm (eta, lower.tail = lower.tail, log.p = log.p)
  }
  environment(linkfun) <- environment(linkinv) <- asNamespace("stats")

  if (familytemp %in% c("canonical", "norm")) {
    melinkinv <- function (eta, sd = 1, lower.tail = TRUE, log.p = FALSE) {
      SD <- sqrt(1 + sd^2)
      thresh <- -qnorm(.Machine$double.eps) * SD
      eta <- pmin(pmax(eta, -thresh), thresh)
      pnorm (eta / SD, lower.tail = lower.tail, log.p = log.p)
    }
    environment(melinkinv) <- asNamespace("stats")
  }
  else if (identical(familytemp, "logis")) {
    melinkinv <- function (eta, sd = 1, lower.tail = TRUE, log.p = FALSE) {
      invbit.me (eta, sd = sd, lower.tail = lower.tail, log.p = log.p,
                 family = "logis")
    }
    environment(melinkinv) <- asNamespace("mrbglm")
  }
  else if (identical(familytemp, "bridge")) {
    melinkinv <- function (eta, sd = 1, lower.tail = TRUE, log.p = FALSE) {
      invbit.me (eta, sd = sd, lower.tail = lower.tail, log.p = log.p,
                 family = "bridge")
    }
    environment(melinkinv) <- asNamespace("mrbglm")
  }
  else {
    stop("not yet implemented for families other than 'norm', 'logis', and 'bridge'")
  }

  Bin = binomial(link = 'probit')
  mu.eta <- Bin$mu.eta
  variance <- Bin$variance
  dev.resids <- Bin$dev.resids
  aic <- Bin$aic
  simfun <- Bin$simulate

  structure(list(family = "binomial",
                 link = link,
                 linkfun = linkfun,
                 linkinv = linkinv,
                 mefamilyname = familystats$name,
                 mefamily = familystats,
                 melinkinv = melinkinv,
                 variance = variance,
                 dev.resids = dev.resids,
                 aic = aic, mu.eta = mu.eta,
                 simulate = simfun),
            class = "link")
}

invbit.me <- function (eta, sd = 1, lower.tail = TRUE, log.p = FALSE,
                             family = "logis") {
  # Use the dimension of eta for the result
  fres <- eta

  # Change to the dimension of sd if required
  if (is.matrix(sd) & !is.matrix(eta))
    fres <- sd

  # Re-cycle vectors if required
  n <- max(length(eta), length(sd))
  eta <- rep(c(eta), length.out = n)
  sd <- rep(c(sd), length.out = n)

  # truncate eta (as in standard binomial GLM) and use pnorm.melogis
  thresh <- -qnorm(.Machine$double.eps) * sqrt(1 + sd^2)
  eta <- pmin(pmax(eta, -thresh), thresh)
  res <- apply (cbind(eta, sd), MARGIN = 1,
                FUN =   switch(family,
                               logis = pnorm.melogis,
                               bridge = pnorm.mebridge))

  if (!lower.tail)
    res <- 1 - res

  if (log.p)
    res <- log(res)

  fres[] <- res

  return(fres)
}

pnorm.melogis <- function(eta, abs.tol = 1e-8) {
  sd <- eta[2]
  eta <- eta[1]

  if (sd <= 0) {
    return(pnorm(eta))
  }

  if (eta == 0) {
    return(0.5)
  }

  invsdlogit <- sqrt(3)/pi
  p <- catch.conditions({
    integrate (f = function(x) {
      pnorm (x, mean = 0, sd = 1,
             lower.tail = TRUE, log.p = FALSE) *
        dlogis(x, location = eta, scale = sd * invsdlogit)
    },
    lower = -Inf, upper = Inf, abs.tol = abs.tol)$value
  })$value

  if (any(class(p) %in% c("simpleError", "error", "condition"))) {
    p <- catch.conditions({
      integrate (f = function(u) {
        pnorm (sd * u, mean = 0, sd = 1,
               lower.tail = TRUE, log.p = FALSE) *
          dlogis(u, location = eta/sd, scale = invsdlogit)
      },
      lower = -Inf, upper = Inf, abs.tol = abs.tol)$value
    })$value

    if (any(class(p) %in% c("simpleError", "error", "condition")) &
        (abs.tol < .Machine$double.eps^0.25)) {
      p <- catch.conditions({
        integrate (f = function(u) {
          pnorm (sd * u, mean = 0, sd = 1,
                 lower.tail = TRUE, log.p = FALSE) *
            dlogis(u, location = eta/sd, scale = invsdlogit)
        },
        lower = -Inf, upper = Inf, abs.tol = .Machine$double.eps^0.25)$value
      })$value

      if (any(class(p) %in% c("simpleError", "error", "condition")))
        return(NA)
    }
  }

  return(p)
}

pnorm.mebridge <- function(eta, abs.tol = 1e-8) {
  sd <- eta[2]
  eta <- eta[1]

  if (sd <= 0) {
    return(pnorm(eta))
  }

  if (eta == 0) {
    return(0.5)
  }

  p <- catch.conditions({
    integrate (f = function(x) {
      pnorm (x, mean = 0, sd = 1,
             lower.tail = TRUE, log.p = FALSE) *
        dbridge (x, location = eta, scale = pi / sqrt(3 * sd^2 + pi^2))
    },
    lower = -Inf, upper = Inf, abs.tol = abs.tol)$value
  })$value

  if (any(class(p) %in% c("simpleError", "error", "condition"))) {
    p <- catch.conditions({
      integrate (f = function(u) {
        pnorm (sd * u, mean = 0, sd = 1,
               lower.tail = TRUE, log.p = FALSE) *
          dbridge (u, location = eta/sd, scale = pi / sqrt(3 + pi^2))
      },
      lower = -Inf, upper = Inf, abs.tol = abs.tol)$value
    })$value

    if (any(class(p) %in% c("simpleError", "error", "condition")) &
        (abs.tol < .Machine$double.eps^0.25)) {
      p <- catch.conditions({
        integrate (f = function(u) {
          pnorm (sd * u, mean = 0, sd = 1,
                 lower.tail = TRUE, log.p = FALSE) *
            dbridge (u, location = eta/sd, scale = pi / sqrt(3 + pi^2))
        },
        lower = -Inf, upper = Inf, abs.tol = .Machine$double.eps^0.25)$value
      })$value

      if (any(class(p) %in% c("simpleError", "error", "condition")))
        return(NA)
    }
  }

  return(p)
}
