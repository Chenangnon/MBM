#'
#' Select Multiplicative Risk Offset Components
#'
#' Fit a series of Multiplicative Risk Binomial (MRB) models with various
#' Multiplicative Risk Offset Constant (MOC) to find the best MOC in the sens of
#' minimum residual deviance or some information criteria.
#'
#' @param measure either a function, a character naming a function (in the
#' calling environment), or a designated character (one of \code{'deviance'},
#' \code{'KL'}, \code{'AIC'}, \code{'BIC'}, \code{'HQC'}). If \code{measure}
#' is a character naming a function, it should be different from any of the
#' designated characters, otherwise it is taken to be a designated character.
#'
#' The argument \code{measure} is made general to allow flexibility in the criterion
#' for selecting the model fit with the best multiplicative risk offset(s). The
#' available designated characters offer a variety of choices: \code{'deviance'}
#' and \code{'KL'} are equivalent, using the residual deviance (which is the
#' Kullback-Leibler divergence from perfect fit) of the fits, \code{'AIC'} and
#' \code{'BIC'} use the most common information criteria (\link{AIC} and \link{BIC}),
#' whereas \code{'HQC'} uses the alternative Hannan–Quinn information criterion
#' \link{HQC}.
#'
#' @details
#' This function performs a grid search over the components of the multiplicative
#' risk offset in MRB models.
#'
#'
#' @export select.mrcomp
#'
#' @examples
#' require(mrbglm)
#'
#' # Simulate some data
#' set.seed(167)
#' mrbdata = sim.mrb (beta = c(2, -2),
#'                    x = cbind(x1 = runif(1000, min = -10, max = 5),
#'                              x2 = runif(1000, min = -5, max = 10)),
#'                    delta = qlogis(.66))$data
#'
#' # Fit bivariate MRB model
#' MRBfit = glm.mrb (y ~ x1 + x2, data = mrbdata)
#'
#' Listfit = select.mrcomp (y ~ x1 + x2, data = mrbdata)
#'
# A routine to estimate (here select) risk offset parameters for an mrb or mib model
# There must be only one parameter to be estimated for L (same holds for Lo)
# Can fix either of Lo and L to the starting value during fitting, through the argument 'control'
# Make that the default
select.mrcomp <- function (formula,
                           deltaostart = -Inf,
                           deltastart = qlogis(seq(0.1, 1, 0.1)),
                           Lostart = NULL,     # Not used, here to prevent from passing Lostart to glm.mrb using ...
                           Lstart = NULL,      # Idem
                           link = logit,
                           x.with.me = NULL,
                           me.formula   = ~ -1,
                           minp.formula = ~ -1,
                           maxp.formula = ~  1,
                           data, weights, subset,
                           na.action = getOption("na.action"),
                           sample.weights = ~ 1,
                           start = NULL,  etastart, mustart,
                           mestart = NULL, gammastart = NULL,
                           intercepts = TRUE, # Rename 'intercepts' as 'x.with.intercepts' ??
                           me.intercepts = FALSE,
                           x.with.offsets  = NULL, x.offsets   = ~ -1, # similar to 'intercepts'
                           x.with.me.offsets = NULL, me.offsets  = ~ -1, # similar to 'intercepts'
                           minp.offset = ~ -1,
                           maxp.offset = ~ -1,
                           method = 'fit.mrb',
                           control = list(fixLo = TRUE, fixL = TRUE),
                           model = FALSE,
                           x = FALSE, y = TRUE,
                           ..., # any other (named) arguments passed to glm.mrb, e.g. data, link, control
                           measure = c('deviance', 'KL', 'AIC', 'BIC', 'HQC'),
                           cl = NULL,
                           chunk.size = NULL) {
  ## Check arguments deltaostart and deltastart
  stopifnot(all(deltaostart < Inf))
  stopifnot(all(deltastart > -Inf))

  ## Measure
  measurefun <- NULL
  if (!is.function(measure)) {
    stopifnot(is.character(measure))

    available_measures <- c('deviance', 'dev',
                            'KL', 'kl',
                            'AIC', 'aic',
                            'BIC', 'bic',
                            'HQC', 'hqc')
    valid_measure <- measure %in% available_measures

    if (any(valid_measure)) {
      measure <- tolower(measure[valid_measure][1])

      if (measure %in% c('deviance', 'dev', 'kl')) {
        measurefun <- function(fit) {
          fit$deviance
        }
      }
      else if (measure %in% c('aic', 'bic', 'hqc')) {
        switch(measure,
               aic = {
                 measurefun <- function(fit) {
                   fit$aic
                 }
               },
               bic = {
                 measurefun <- function(fit) {
                   fit$bic
                 }
               },
               hqc = {measurefun <- function(fit) {
                 -2 * fit$logLike + 2 * fit$rank * log(log(fit$nobs))
               }
               })
      }
      else {
        stop('something went wrong')
      }

    }
    else {
      measure <- get(measure, mode = "function", envir = parent.frame())
      if (!is.function(measure)) {
        print(measure)
        stop("'measure' not recognized")
      }
    }
  }

  if (is.null(measurefun)) {
    measurefun <- function(fit) {
      catch.conditions({
        measure (fit)
      })$value
    }
  }

  ## Define a grid of deltaostart and deltastart
  deltagrid <- expand.grid(deltao = deltaostart, delta = deltastart)

  ## Fit models for each row of 'deltagrid'
  fitj <- function (deltas) {
    fiti <- catch.conditions({
      glm.mrb(formula = formula,
              deltaostart = deltas[1],
              deltastart = deltas[2],
              Lostart = NULL,
              Lstart = NULL,
              link = link,
              x.with.me = x.with.me,
              me.formula   = me.formula,
              minp.formula = minp.formula,
              maxp.formula =  maxp.formula,
              data = data, weights = weights, subset = subset,
              na.action = na.action,
              sample.weights = sample.weights,
              start = start,  etastart = etastart, mustart = mustart,
              mestart = mestart, gammastart = gammastart,
              intercepts = intercepts, # Rename 'intercepts' as 'x.with.intercepts' ??
              me.intercepts = me.intercepts,
              x.with.offsets  = x.with.offsets, x.offsets   = x.offsets, # similar to 'intercepts'
              x.with.me.offsets = x.with.me.offsets, me.offsets  = me.offsets, # similar to 'intercepts'
              minp.offset = minp.offset,
              maxp.offset = maxp.offset,
              method = method,
              control = control,
              model = model,
              x = x, y = y)
    })$value

    return(fiti)

  }
  fitlist <- matteApply(deltagrid,
                        MARGIN = 1,
                        FUN = fitj,
                        cl = cl,
                        chunk.size = chunk.size)

  ## Get measures
  measures <- sapply(fitlist,
                     FUN = measurefun)

  ## Output
  out <- list(fitlist = fitlist,
              measures = measures)

  ## Find the best fit
  best <- which.min(measures)
  if (!all(c(length(best) > 0, !is.na(best), is.finite(best)))) {
    warning('no best fit found')

    out <- list(bestfit = NULL,
                which.best = NA,
                measures = measures,
                fitlist = fitlist)

  }
  else {

    out <- list(bestfit = fitlist[[tail(best, 1)]],
                which.best = best,
                measures = measures,
                fitlist = fitlist)

  }

  return(out)

}
