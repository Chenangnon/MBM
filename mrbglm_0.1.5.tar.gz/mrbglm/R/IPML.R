
#' IML = Iterative (Penalized) ML
#'
#' @export IPML
#'
# Check that the function works with a 2-column response
IPML <- function(formula,
                link = logit,
                x.with.me = NULL,
                me.formula   = ~ -1,
                minp.formula = ~ -1,
                maxp.formula = ~  1,
                data, weights, subset,
                na.action = getOption("na.action"),
                sample.weights = ~ 1,
                start = NULL, etastart, mustart,
                mestart = NULL, gammastart = NULL,
                Lostart = NULL, deltaostart = NULL,
                Lstart = NULL, deltastart = NULL,
                intercepts = TRUE,
                me.intercepts = FALSE,
                x.with.offsets = NULL, x.offsets   = ~ -1, # similar to 'intercepts'
                x.with.me.offsets = NULL, me.offsets  = ~ -1, # similar to 'intercepts'
                minp.offset = ~ -1,
                maxp.offset = ~ -1,
                method = 'fit.mrb',
                control = list(),
                model = FALSE,
                x = FALSE, y = TRUE,
                ...) {
  ### Save the call
  cal <- match.call()

  ### Get Binomial link function
  if (is.character(link))
    link <- get(link, mode = "function", envir = parent.frame())
  if (is.function(link))
    link <- link()
  if (is.null(link$link)) {
    print(link)
    stop("'link' not recognized")
  }

  ### Control argument
  control_it <- control <- do.call("control.mrb", control)
  control_it$fixL <- TRUE

  ### Was data argument missing?
  mis.data <- missing(data)

  ### Get data, model frames, model terms and weights; also get mustart and etastart
  if (mis.data)
    data <- environment(formula)
  eval(mrb.frame())

  ### Initialization (Aim: get initial beta estimates)
  Linfer <- infer.lambda(x = X, y = Y)
  mu_ab <- Linfer$lambda
  pick <- Linfer$which
  npick <- length(pick)

  mu_ab <- mean(Y)
  npick <- length(Y)
  pick <- 1:npick

  if (is.null(Lstart)) {
    Lstart <- mu_ab
  }
  fit0 <- eval(call(if (is.function(method)) "method" else method,
                   x = X, y = Y, intercepts = intercepts,
                   x.with.me = x.with.me, zme = Zme, me.intercepts = me.intercepts,
                   zminp = Zminp, zmaxp = Zmaxp, x.offsets = X.offsets,
                   me.offsets = Me.offsets,
                   minp.offset = Minp.offset, maxp.offset = Maxp.offset,
                   contract_eta = contract_eta, link = link,
                   weights = weights, sample.weights = sample.weights,
                   start = start, etastart = etastart, mustart = mustart,
                   mestart = mestart, gammastart = gammastart,
                   Lostart = Lostart, deltaostart = deltaostart,
                   Lstart = Lstart, deltastart = deltastart,
                   control = control))
  Lhat0 <- Lhat <- fit0$L.values

  if (length(Lhat0) == 1) {
    ### First, estimate lambda
    hvalues <- fit0$mu[pick] / fit0$L.values
    omega_ab <- mean(hvalues)
    omega2_ab <- var(hvalues) / npick
    outiter <- 1
    stopcriterion <- NA
    Lhat <- max(min(mu_ab / (omega_ab - omega2_ab), 1-1e-8), 1e-8)
    maxoutiter <- max(2, ceiling(control$maxit/10))

    while (outiter < maxoutiter) {
      outiter <- outiter + 1
      fit <- eval(call(if (is.function(method)) "method" else method,
                       x = X, y = Y, intercepts = intercepts,
                       x.with.me = x.with.me, zme = Zme, me.intercepts = me.intercepts,
                       zminp = Zminp, zmaxp = Zmaxp, x.offsets = X.offsets,
                       me.offsets = Me.offsets,
                       minp.offset = Minp.offset, maxp.offset = Maxp.offset,
                       contract_eta = contract_eta, link = link,
                       weights = weights, sample.weights = sample.weights,
                       start = start, etastart = etastart, mustart = mustart,
                       mestart = mestart, gammastart = gammastart,
                       Lostart = Lostart, deltaostart = deltaostart,
                       Lstart = Lhat, deltastart = deltastart,
                       control = control_it))

      hvalues <- fit$mu[pick] / fit$L.values
      omega_ab_new <- mean(hvalues)
      omega2_ab_new <- var(hvalues) / npick
      Lhat_new <- max(min(mu_ab/(omega_ab_new - omega2_ab_new), 1-control$epsilon), control$epsilon)
      stopcriterion <- abs(Lhat - Lhat_new)
      Lhat <- Lhat_new
      if (stopcriterion < control$epsilon)
        break
    }

    #fit$Linfer <- Linfer
    fit$mu_ab <- mu_ab
    fit$omega_ab <- omega_ab_new
    fit$stopcriterion <- stopcriterion

  }
  else {
    stop("not implemented for unit dependent asymptotes")
  }

  fit$Lhat0 <- Lhat0
  fit$Lhat <- Lhat

  if (x)
    fit$x <- X
  if (y)
    fit$y <- Y

  if (!is.null(fit$pred.with.me)) {
    colnames(fit$me.mat) <- attr(mt,"term.labels")[fit$pred.with.me]
  }

  out <- structure(c(fit,
                     list(call = cal, formula = formula,
                          minp.formula = minp.formula,
                          maxp.formula = maxp.formula,
                          me.formula = me.formula,
                          link = link,
                          terms = mt, contract_eta = contract_eta,
                          zminpterms = mtZminp, zmaxpterms = mtZmaxp,
                          zmeterms = mtZme, sample.wterms = mtw,
                          data = data, na.action = na.action, method = method,
                          xlevels = stats::.getXlevels(mt, mf),
                          zminplevels = if (!is.null(mtZminp)) stats::.getXlevels(mtZminp, mfZminp),
                          zmaxplevels = if (!is.null(mtZmaxp)) stats::.getXlevels(mtZmaxp, mfZmaxp),
                          zmelevels = if (!is.null(mtZme)) stats::.getXlevels(mtZme, mfZme))),
                   class = c("mrbglm", class(fit)))

  if (model) {
    out$model <- list(mf = mf,
                      mf.me = mfZme,
                      mf.minp = mfZminp,
                      mf.maxp = mfZmaxp,
                      mf.xoffsets = mfx.offsets,
                      mf.meoffsets = mfme.offsets,
                      mf.minpoffset = mfminp.offset,
                      mf.maxpoffset = mfmaxp.offset,
                      mf.samplew = mfw)
  }

  if (!identical(fit$control$order.intercepts, fit$order.intercepts)) {
    out <- mrb.switch.coef (out)
  }

  return(out)
}
