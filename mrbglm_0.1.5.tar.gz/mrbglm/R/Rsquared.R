#'
#' @title Calculate Pseudo \eqn{R^2}
#'
#' @description
#' Calculate generalized \eqn{R^2} statistics to assess the goodness of fit (explanative
#' power) of generalized linear-like models.
#'
#' @aliases rsquared
#' @aliases rsquared.default
#' @aliases NagelkerkeR2
#'
#' @param object an object of (or inheriting from) class
#' \code{"mrbglm"}, \code{"mibglm"} or \code{"glm"}, or a list of such objects.
#'
#' @param ... optionally more fitted model objects of a class with a
#' \code{rsquared} method.
#'
#' @param method character indicating the desired pseudo R squared statistic(s).
#' The default method accepts \code{'KL'} (for Kullback–Leibler divergence based
#' \eqn{R^2}, equivalent to the deviance reduction ratio achieved by the predictors
#' in a fitted model as compared to a model with no predictor) and
#' \code{'Nagelkerke'} (Nagelkerke's \eqn{R^2}).
#'
#' @param adjust.size logical, should the pseudo R-squared statistic be adjusted
#' for model complexity (number of free parameters)? If \code{TRUE}, the returned
#' pseudo R-squared statistic is \eqn{1 - \frac{n-1}{n-p} (1 - R^2)} where
#' \eqn{R^2} is the unadjusted statistic, \eqn{n} is the sample size (number of
#' observations) and \eqn{p} is the number of free model parameters.
#'
#' @usage
#' rsquared (object, ..., method = 'KL', adjust.size = FALSE)
#' NagelkerkeR2 (object, ..., adjust.size = FALSE)
#'
#' @export rsquared
#' @export NagelkerkeR2
#' @export rsquared.default
#' @import Rdpack
#'
#' @details
#' Note that arguments after \code{...} must be matched exactly (by their names).
#'
#' The function \code{rsquared} computes deviance based pseudo-R squared such as
#' the deviance reduction ratio or the Nagelkerke's \eqn{R^2}. This is a generic
#' function for which methods can be defined.
#'
#' The default method for \code{rsquared} handles objects of classes
#' \code{'glm'}, \code{'mrbglm'}, and \code{'mibglm'}. It computes by default
#' the deviance based pseudo-\eqn{R^2} of \insertCite{cameron1996r;textual}{mrbglm}.
#' It also allows to obtain \insertCite{nagelkerke1991note;textual}{mrbglm}'s
#' R-squared through the argument \code{method = 'Nagelkerke'}.
#'
#' The function \code{NagelkerkeR2} also computes Nagelkerke's R-squared.
#' It extends \link[fmsb]{NagelkerkeR2} of library \code{fmsb} to
#' handle objects of classes \code{'mrbglm'} and \code{'mibglm'} in addition to
#' \code{'glm'} class objects.
#'
#' @note
#' The original function \link[fmsb]{NagelkerkeR2} was written by Minato Nakazawa.
#'
#' @return A \code{'data.frame'} with rows corresponding to the supplied
#' \code{objects} (including \code{...} if any), and a column of \code{R2} for
#' each provided method, and two additional columns including \code{N} (number
#' of observations), \code{df} (number of free model parameters).
#'
#' As such, \code{NagelkerkeR2} always return a three-column \code{data.frame}.
#'
#' @references
#' \insertAllCited{}
#'
#' @examples
#' ## Logistic regression fit
#' GLMres <- glm (case ~ spontaneous,
#'             data = infert,
#'             family = binomial())
#'
#' summary(GLMres)
#'
#' # Kullback–Leibler divergence based R^2 (the default)
#' rsquared (GLMres)
#'
#' ## MRB model fit with a maximum probability limit
#' require(mrbglm)
#' MRBres <- glm.mrb (case ~ spontaneous,
#'                    maxp.formula = ~ 1,
#'                    data = infert)
#'
#' summary(MRBres)
#'
#' # Nagelkerke's R^2 for the two fits
#' NagelkerkeR2 (GLMres, MRBres)
#'
#' # Nagelkerke's R^2 and Kullback–Leibler divergence based R^2 for the two fits
#' rsquared (GLMres, MRBres, method = c('Nagelkerke', 'KL'))
#
rsquared.default <-
  function (object, ..., method = 'KL', adjust.size = FALSE) {
    # Save the call (for naming purposes)
    Call <- match.call()

    # If many methods, return a named list with one call to 'rsquared' per supplied method
    method <- unique(method)
    if (length(method) > 1) {
      Lresults <- lapply(method,
                         FUN = function(method_i) {
                           out <- rsquared.default (object, ..., method = method_i, adjust.size = adjust.size)
                           return(out)
                         })
      out <- Lresults[[1]]
      out <- cbind(as.numeric(out[,1]),
                   sapply(Lresults[-1], FUN = function (outi) {
                     as.numeric(outi[,1])
                   }),
                   as.numeric(out[,2]),
                   as.numeric(out[,3]))
      colnames(out) <- c(method, 'N', 'df')
      rownames(out) <- as.character(Call[-1L])[1:NROW(out)]

      return(out)
    }

    # Select the function for a specified method
    get.R2VAL <- switch(toupper(method),
                        KL = get.KLR2VAL,
                        NAGELKERKE = get.NR2VAL,
                        N = get.NR2VAL)

    # List of classes with a method
    availclasses <- c("glm", "mrbglm", 'mibglm')

    # Argument adjust.size: coerce to be logical
    adjust.size <- as.logical(adjust.size[1])

    # List of additional object, if any
    objects <- list(...)

    if (length(objects) == 0) { # If no additional object provided through  ...

      if (any(class(object) %in% availclasses)) { # If object is of a class with an available method

        if (inherits(object, "glm")) {
          n <- nrow(object$model)
          rank <- object$df.null - object$df.residual + 1
        }
        else {
          n <- object$nobs
          rank <- object$rank
        }

        R2 <- get.R2VAL (object = object, n = n, rank = rank, adjust.size = adjust.size)

        RVAL <- data.frame(rbind(c(R2 = R2, N = n, df = rank)))
        colnames(RVAL) <- c(method, 'N', 'df')
        row.names(RVAL) <- as.character(Call[-1L])[1]

        return(RVAL)
      }
      else {
        if (is.list(object)) {
          nm <- names(object)

          clobject <- sapply(object,
                             FUN = function(x) any(class(x) %in% availclasses))
          if (all(!clobject)) {
            cat("\n classes with a default 'rsquared' method are: \n")
            cat(availclasses)
            cat(" \n")
            stop("object(s) of a class not handled")
          }
          res <- matrix(NA, nrow = length(clobject), ncol = 3)

          RVAL <- sapply(object[clobject],
                         FUN = function(objectj) {
                           if (inherits(objectj, "glm")) {
                             nj <- nrow(objectj$model)
                             rankj <- objectj$df.null - objectj$df.residual + 1
                           }
                           else {
                             nj <- objectj$nobs
                             rankj <- objectj$rank
                           }

                           R2j <- get.R2VAL (object = objectj, n = nj, rank = rankj, adjust.size = adjust.size)

                           return(c(R2 = R2j, N = nj, df = rankj))
                         })
          res[clobject,] <- if (sum(clobject) > 0) t(RVAL) else RVAL
          RVAL <- data.frame(R2 = res[,1], N = res[,2], df = res[,3])
          colnames(RVAL) <- c(method, 'N', 'df')

          if (!is.null(nm))
            row.names(RVAL) <- nm

          return(RVAL)
        }

        stop(paste0(" object of a class not handled by 'rsquared.default'. Available classes are: ",
                    paste(availclasses, collapse = ', '), '.'))
      }
    }
    else {
      objects <- list(object, ...)
      out <- rsquared.default(objects, method = method, adjust.size = adjust.size)
      row.names(out) <- as.character(Call[-1L])[1:NROW(out)]
      return(out)
    }
  }

setGeneric(name = 'rsquared',
           def = rsquared.default)

get.KLR2VAL <- function (object, n, rank, adjust.size) {

  R2 <- 1 - (object$deviance/object$null.deviance) * (
    ifelse (adjust.size, (n - 1) / (n - rank), 1) )

  return(R2)
}
