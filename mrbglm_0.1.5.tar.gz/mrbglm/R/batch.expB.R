#' Run Simulation Experiment \code{B}
#'
#' This function runs a simulation experiment on Multistage Binomial Model based Regression
#'
#' @param n numeric vector of sample sizes.
#' Note that the supplied \code{n} is ignored if a non null \code{w} is
#' provided: only one sample size is then considered, namely the number of
#' rows of \code{w}.
#'
#' @param verbose numeric integer, if positive, information is printed during the running of step.
#' Larger values may give more detailed information.
#'
#' @param models character vector, specifies desired fitting models.
#' One or many of \code{'M0'} (univariate model \code{y ~ w1}),
#' \code{'M1'} (bivariate model \code{y ~ w1 + w2}),
#' \code{'M2'} (bivariate model \code{y ~ w1 + w3}), and
#' \code{'M3'} (full model \code{y ~ w1 + w2 + w3}). The shorthand
#' \code{'M0:3'} is also accepted for all the four models (\code{'M0'} to \code{'M3'}).
#'
#' The default (when \code{models = NULL}) depends on the argument \code{L}
#' (specifically \code{L[1]}): if \code{L = 1}, then \code{models = 'M0'},
#' otherwise, \code{models = 'M0:3'}.
#'
#' @param w optional design matrix of true covariate values.
#' Note that the supplied \code{n} is ignored if a non null \code{w} is provided.
#'
#' @param x optional design matrix of measurement-prone covariate values.
#'
#' @details
#' Except for \code{tau.e}, only the first value of each multiple-valued
#' argument is used.
#'
#'
# @export mbm.expB
#'
#' @export batch.expB
# @aliases mbm.expB
#'
#' @import stats
#' @import parallel
#
#
# Do NOT use \code{w3.continuous = FALSE} for \code{L < 1}: only the product of the factor corresponding to w_3 and L can be identified.
# For L = 1, allowing \code{w3.continuous = FALSE} is simply another way to have L < 1.
#
# Run a simulation experiment using 'glm.mrb'
#

# Sample the variance of ME from the uniform distribution on (0, 2*sigma_e2)
batch.expB <- function (n = c(100, 200, 300, 500, 800, 1000),
                        beta_1 = -1,
                        CD = c('norm', 'lnorm', 'unif'),
                        mu_c = 1,   # Average of each continuous covariate
                        w3.continuous = TRUE,
                        mu_b = 0.5, # Average of the third (binary) covariate
                        sigma_22 = c(0.5, 1, 2),
                        rho = c(0, 0.3, 0.9),
                        MED = c('bridge', 'norm'),
                        sigma_e2 = c(0, 0.25, 0.5),
                        VED = 'unif', # c('unif', 'constant', 'chisq'),
                        beta_10 = 3,
                        beta_2 = beta_1, beta_20 = beta_10,
                        beta_3 = beta_1, beta_30 = beta_10,
                        link = "logit",
                        L = 1,
                        Lstart = NULL,
                        n.restart = 0,
                        criterion = c('ML', "NLS"),
                        method.optim = "BFGS",
                        slope.signs = NULL,
                        vary.sign = FALSE,
                        fixL = FALSE,
                        B = 2000,
                        tau.e = c(0, 0.5, 1, 2),
                        SBMmodels = NULL,
                        MBMmodels = NULL,
                        seed = 167,
                        verbose = 2,
                        nb.clusters = 0,
                        cl = if (nb.clusters > 0) parallel::makeCluster(nb.clusters),
                        chunk.size = NULL) {
  # Set seed for parallel computing if required
  if (!is.null(seed)) {
    saved.kind <- RNGkind()[1]
    saved.seed <- .Random.seed
    set.seed(seed)

    if (!is.null(cl)) {
      RNGkind("L'Ecuyer-CMRG")
      parallel::clusterSetRNGStream (cl, iseed = .Random.seed)
    }
  }

  # Grid of simulation parameters
  sigma_e2 <- unique(sigma_e2)
  Pgrid <- expand.grid (beta_1 = beta_1,
                        CD = CD,
                        sigma_22 = sigma_22,
                        rho = rho,
                        sigma_e2 = sigma_e2,
                        MED = MED)

  # A routine to run over settings
  nb.settings <- NROW(Pgrid)
  kfunc <- function(k) {

    if (verbose) {
      cat(paste0('\nRunning setting ', k, ' / ', nb.settings))
    }

    combs <- Pgrid[k,]

    # For each sample size in 'n'
    outk <- lapply(n,
                   FUN = function(nk) {

                     if (verbose) {
                       cat(paste0("\nExperiment B with sample size n = ", nk, "."))
                     }

                     ## Measurement-errors
                     sigma_e2 <- as.numeric(combs[5])

                     ## Simulate predictors
                     nkdesigns <- generate.covariate.matrix (n = nk,
                                                             w = NULL,
                                                             CD = as.character(combs[2][[1]]),
                                                             mu_c = mu_c,
                                                             w3.continuous = w3.continuous,
                                                             mu_b = mu_b,
                                                             sigma_22 = as.numeric(combs[3]),
                                                             rho = as.numeric(combs[4]),
                                                             x = NULL,
                                                             MED = as.character(combs[6][[1]]),
                                                             sigma_e2 = sigma_e2,
                                                             VED = VED[1],
                                                             seed = NULL)

                     outnk <- mbm.expB (w = nkdesigns$w,
                                        x = nkdesigns$x,
                                        sigma_e2 = nkdesigns$sigma_e2,
                                        L = L[1],
                                        beta_1 = as.numeric(combs[1]),
                                        beta_10 = beta_10[1],
                                        beta_2 = beta_2[1], beta_20 = beta_20[1],
                                        beta_3 = beta_3[1], beta_30 = beta_30[1],
                                        link = link[1],
                                        Lstart = Lstart[1],
                                        criterion = criterion[1],
                                        method.optim = method.optim[1],
                                        slope.signs = slope.signs[1],
                                        vary.sign = vary.sign[1],
                                        fixL = fixL[1],
                                        n.restart = n.restart[1],
                                        B = B[1],
                                        w3.continuous = w3.continuous,
                                        tau.e = tau.e,
                                        SBMmodels = SBMmodels,
                                        MBMmodels = MBMmodels,
                                        seed = NULL,
                                        verbose = verbose,
                                        cl = NULL,
                                        chunk.size = NULL)

                     return(outnk)
                   })

    names(outk) <- paste0('n=', n)

    outk$params <- combs

    return(outk)

  }

  out <- mrbglm:::matteLapply(X = 1:nb.settings,
                              FUN = kfunc,
                              cl = cl,
                              chunk.size = chunk.size)

  if (!is.null(cl)) {
    catch.conditions({
      parallel::stopCluster(cl)
    })
  }

  if (!is.null(seed)) {
    RNGkind(saved.kind)
    .Random.seed <- saved.seed
  }

  names(out) <- paste0("Setting", 1:nb.settings)

  return(out)

}

mbm.expB <- function(w, x, sigma_e2 = 0,
                     L = 1,
                     beta_1 = -1,
                     beta_10 = 3,
                     beta_2 = beta_1, beta_20 = beta_10,
                     beta_3 = beta_1, beta_30 = beta_10,
                     link = "logit",
                     Lstart = NULL,
                     criterion = c('ML', "NLS"),
                     method.optim = "BFGS",
                     slope.signs = NULL,
                     vary.sign = FALSE,
                     fixL = FALSE,
                     n.restart = 20,
                     B = 2000,
                     w3.continuous = TRUE,
                     tau.e = 1,
                     SBMmodels = 'M0',
                     MBMmodels = 'M0:3',
                     seed = 167,
                     verbose = 2,
                     nb.clusters = 8,
                     cl = if (nb.clusters > 0) parallel::makeCluster(nb.clusters),
                     chunk.size = NULL) {
  # Saved the call
  mcall <- match.call()

  # Pick first values of arguments
  L <- L[1]
  beta_1 <- beta_1[1]
  beta_10 <- beta_10[1]
  beta_2 <- beta_2[1]
  beta_20 <- beta_20[1]
  beta_3 <- beta_3[1]
  beta_30 <- beta_30[1]
  link <- link[1]
  criterion <- criterion[1]
  B <- B[1]

  # Argument check
  n <- NROW(w)
  stopifnot(n >= 10)
  stopifnot(all(tau.e >= 0))
  stopifnot(link %in% c('logit', 'probit'))
  if (is.null(SBMmodels)) {
    SBMmodels <- ifelse(all(sigma_e2 == 0), 'M0:3', 'M0')
  }
  else {
    stopifnot(is.character(SBMmodels))
    stopifnot(all(SBMmodels %in% c('M0', 'M1', 'M2', 'M3', 'M0:3')))
  }
  if ('M0:3' %in% SBMmodels) {
    SBMmodels <- c('M0', 'M1', 'M2', 'M3')
  }

  if (is.null(MBMmodels)) {
    MBMmodels <- ifelse(L < 1, 'M0', 'M0:3')
  }
  else {
    stopifnot(is.character(MBMmodels))
    stopifnot(all(MBMmodels %in% c('M0', 'M1', 'M2', 'M3', 'M0:3')))
  }
  if ('M0:3' %in% MBMmodels) {
    MBMmodels <- c('M0', 'M1', 'M2', 'M3')
  }

  # Set seed for parallel computing if required
  if (!is.null(seed)) {
    saved.kind <- RNGkind()[1]
    saved.seed <- .Random.seed
    set.seed(seed)

    if (!is.null(cl)) {
      RNGkind("L'Ecuyer-CMRG")
      parallel::clusterSetRNGStream (cl, iseed = .Random.seed)
    }
  }

  # Run B replicates of the simulation setting
  out <- mrbglm:::matteLapply (X = 1:B,
                               FUN = run.simB.k,
                               design.mat = list(w = w, x = x, sigma_e2 = sigma_e2),
                               beta = c(beta_10, beta_1, beta_20, beta_2, beta_30, beta_3),
                               delta = qlogis(L),
                               Lstart = Lstart,
                               link = link,
                               criterion = criterion,
                               method.optim = method.optim,
                               slope.signs = slope.signs,
                               vary.sign = vary.sign,
                               fixL = fixL,
                               n.restart = n.restart,
                               SBMmodels = SBMmodels,
                               MBMmodels = MBMmodels,
                               w3.continuous = w3.continuous,
                               tau.e = tau.e,
                               verbose = max(0, verbose - 1),
                               cl = cl,
                               chunk.size = chunk.size)

  if (!is.null(cl)) {
    catch.conditions({
      parallel::stopCluster(cl)
    })
  }

  if (!is.null(seed)) {
    RNGkind(saved.kind)
    .Random.seed <- saved.seed
  }

  names(out) <- paste0("k", 1:B)
  out <- list(main = out)

  # Save call, covariate data
  out$design.mat <- list(w = w, x = x, sigma_e2 = sigma_e2)
  out$call <- mcall

  # Set class
  class(out) <- "mbm.exp"

  # Compute performance measures
  # out$performance <- get.performance (out)

  return(out)

}

# Sub-routine to run Experiment B
run.simB.k <- function (k,
                        design.mat,
                        beta, delta, Lstart,
                        link, criterion,
                        method.optim, slope.signs, vary.sign,
                        fixL, n.restart, w3.continuous,
                        SBMmodels,
                        MBMmodels,
                        tau.e,
                        verbose) {
  if (verbose) {
    cat(paste0("\n\n  # replicate k = ", k, " \n"))
  }

  # Initialize output object
  out <- list(MBMdata = list())

  if (verbose) {
    cat("      * Generating MBM data ... ")
  }

  # Sample data
  MBMdata <- sim.mrb (x = design.mat$w,
                      intercepts = c(TRUE, TRUE, w3.continuous),
                      beta = beta,
                      delta = delta,
                      link = link)$data

  # Replace covariates by measurement error prone-observations
  MBMdata$w1 <- design.mat$x[,1]
  MBMdata$w2 <- design.mat$x[,2]
  MBMdata$w3 <- design.mat$x[,3]


  if (length(design.mat$sigma_e2) > 1) {
    MBMdata$sigma1_e <- sqrt(design.mat$sigma_e2[,1])
    MBMdata$sigma2_e <- sqrt(design.mat$sigma_e2[,2])
    if (w3.continuous)
      MBMdata$sigma3_e <- sqrt(design.mat$sigma_e2[,3])
    else
      MBMdata$sigma3_e <- 0
  }
  else {
    MBMdata$sigma1_e <- MBMdata$sigma2_e <- sqrt(design.mat$sigma_e2[1])
    MBMdata$sigma3_e <- if (w3.continuous) MBMdata$sigma1_e else 0
  }

  if (verbose) {
    cat("\n      * Fitting SBMs ... ")
  }

  out$MBMdata$SBMfits <- SBMfittingB (MBMdata,
                                      link = link,
                                      models = SBMmodels,
                                      verbose = max(0, verbose - 1))

  if (verbose) {
    cat("\n      * Fitting MBMs ... ")
  }

  out$MBMdata$MBMfits <- MBMfittingB (MBMdata,
                                      w3.continuous = w3.continuous,
                                      link = link,
                                      Lstart = Lstart, criterion = criterion,
                                      method.optim = method.optim,
                                      slope.signs = slope.signs,
                                      vary.sign = vary.sign,
                                      fixL = fixL,
                                      n.restart = n.restart,
                                      models = MBMmodels,
                                      tau.e = tau.e,
                                      verbose = max(0, verbose - 1))

  out$MBMdata$y <- MBMdata$y
  out$MBMdata$sigma_e <- sqrt(design.mat$sigma_e2)

  if (verbose) {
    cat("\n ")
  }

  return(out)

}

# Routine to fit SBM model M0 to M3
SBMfittingB <- function (mdata, link, models = 'M0', verbose) {
  SBMfits <- list()

  if ('M0' %in% models) {
    if (verbose) {
      cat("\n        - M0 specification: y ~ x1 ... ")
    }
    rtime <- system.time({
      SBMfits$M0 <- catch.conditions({
        glm(formula = y ~ w1,
            family = binomial(link = link),
            data = mdata)
      })$value
    })

    SBMfits$M0 <- as.list(SBMfits$M0)
    SBMfits$M0$time <- rtime

  }

  if ('M1' %in% models) {
    if (verbose) {
      cat("\n        - M1 specification: y ~ x1 + x2 ... ")
    }
    rtime <- system.time({
      SBMfits$M1 <- catch.conditions({
        glm(formula = y ~ w1 + w2,
            family = binomial(link = link),
            data = mdata)
      })$value
    })

    SBMfits$M1 <- as.list(SBMfits$M1)
    SBMfits$M1$time <- rtime

  }

  if ('M2' %in% models) {
    if (verbose) {
      cat("\n        - M2 specification: y ~ x1 + x3 ... ")
    }
    rtime <- system.time({
      SBMfits$M2 <- catch.conditions({
        glm(formula = y ~ w1 + w3,
            family = binomial(link = link),
            data = mdata)
      })$value
    })

    SBMfits$M2 <- as.list(SBMfits$M2)
    SBMfits$M2$time <- rtime

  }

  if ('M3' %in% models) {
    if (verbose) {
      cat("\n        - M3 specification: y ~ x1 + x2 + x3 ... ")
    }
    rtime <- system.time({
      SBMfits$M3 <- catch.conditions({
        glm(formula = y ~ w1 + w2 + w3,
            family = binomial(link = link),
            data = mdata)
      })$value
    })

    SBMfits$M3 <- as.list(SBMfits$M3)
    SBMfits$M3$time <- rtime

  }

  return(SBMfits)
}

# Routine to fit MBM models M0 to M3
MBMfittingB <- function (mdata,
                         w3.continuous = TRUE,
                         link, Lstart, criterion,
                         method.optim, slope.signs, vary.sign,
                         fixL = FALSE,
                         n.restart = 3,
                         models = c('M0', 'M1', 'M2', 'M3'),
                         tau.e = 1,
                         verbose) {

  MBMfits <- list()

  if ('M0' %in% models) {
    MBMfits$M0 <- MBMfittingB.M0 (mdata = mdata,
                                  link = link, Lstart = Lstart, criterion = criterion,
                                  method.optim = method.optim, slope.signs = slope.signs,
                                  vary.sign = vary.sign, fixL = fixL,
                                  n.restart = n.restart,
                                  tau.e = tau.e,
                                  verbose = verbose)
  }

  if ('M1' %in% models) {
    MBMfits$M1 <- MBMfittingB.M1 (mdata = mdata,
                                  link = link, Lstart = Lstart, criterion = criterion,
                                  method.optim = method.optim, slope.signs = slope.signs,
                                  vary.sign = vary.sign, fixL = fixL,
                                  n.restart = n.restart,
                                  tau.e = tau.e,
                                  verbose = verbose)
  }

  if ('M2' %in% models) {
    MBMfits$M2 <- MBMfittingB.M2 (mdata = mdata,
                                  w3.continuous = w3.continuous,
                                  link = link, Lstart = Lstart, criterion = criterion,
                                  method.optim = method.optim, slope.signs = slope.signs,
                                  vary.sign = vary.sign, fixL = fixL,
                                  n.restart = n.restart,
                                  tau.e = tau.e,
                                  verbose = verbose)
  }

  if ('M3' %in% models) {
    MBMfits$M3 <- MBMfittingB.M3 (mdata = mdata,
                                  w3.continuous = w3.continuous,
                                  link = link, Lstart = Lstart, criterion = criterion,
                                  method.optim = method.optim, slope.signs = slope.signs,
                                  vary.sign = vary.sign, fixL = fixL,
                                  n.restart = n.restart,
                                  tau.e = tau.e,
                                  verbose = verbose)
  }

  return(MBMfits)

}

MBMfittingB.M0 <- function(mdata,
                           link, Lstart, criterion,
                           method.optim, slope.signs,
                           vary.sign = FALSE, fixL = FALSE,
                           n.restart = 3,
                           tau.e = 1,
                           verbose) {
  if (verbose) {
    cat("\n        - M0 specification: y ~ x1 ... ")
  }

  M0fun <- function (Lstarti, fixL = FALSE) {
    rtime <- system.time({
      M0 <- catch.conditions({
        mrbglm::glm.mrb (formula = y ~ w1,
                         link = link,
                         maxp.formula = ~1,
                         start = NULL,
                         Lstart = Lstarti,
                         control = control.mrb(fixL = fixL,
                                               criterion = criterion,
                                               method = method.optim,
                                               slope.signs = slope.signs),
                         data = mdata)
      })$value
    })
    M0 <- as.list(M0)
    M0$time <- rtime

    return(M0)

  }

  # Perform restarts if required
  if (n.restart > 0) {
    if (n.restart == 1)
      M0.seq <- lapply(0.515, FUN = M0fun, fixL = fixL)
    else
      M0.seq <- lapply(seq(0.04, 0.99, length.out = n.restart),
                       FUN = M0fun, fixL = fixL)
  }
  else {
    M0.seq <- list()
  }

  # Use the supplied 'Lstart'
  if (!(identical(Lstart, 1) & fixL)) {
    M0.seq[[length(M0.seq) + 1]] <- M0fun(Lstart, fixL = fixL)
  }

  # Not specifying the starting L value (self-initialize)
  if (!is.null(Lstart)) {
    M0.seq[[length(M0.seq) + 1]] <- M0fun(NULL, fixL = fixL)
  }

  # Deviance of the GLM fit (L=1)
  fit.glm <- M0fun(1, fixL = TRUE)
  M0.seq[[length(M0.seq) + 1]] <- fit.glm

  # Residual deviances of the fits
  rdev <- sapply(M0.seq, FUN = function(x) {
    if(!is.list(x))
      return(NA)
    res <- x$deviance

    if (is.null(res))
      return(NA)

    return(res)
  })

  # Pick the best fit
  M0 <- M0.seq[[which.min(rdev)]]

  start_coef <- M0$coefficients
  start_L <- M0$L.values

  ### Fitting models accounting for true measurement errors if any
  M0 <- list(`tau=0` = M0)
  if (any(mdata$sigma1_e > 0) & any(tau.e > 0)) {
    tau.e <- tau.e[tau.e > 0]

      M0[2:(length(tau.e) + 1)] <- lapply(tau.e,
                                          FUN = function(tau) {
                                            me.MBMfittingB.M0(tau * mdata$sigma1_e,
                                                              mdata = mdata, link = link,
                                                              start = start_coef, Lstart = start_L,
                                                              criterion = criterion,
                                                              method.optim = method.optim, slope.signs = slope.signs,
                                                              vary.sign = vary.sign, fixL = fixL,
                                                              n.restart = ceiling(n.restart/4),
                                                              verbose = max(0, verbose - 1))
                                          })

    names(M0) <- paste0('tau=', c(0, tau.e))
  }

  return(M0)
}

# Routine to fit MBM models M0 to M3 with measurement errors
me.MBMfittingB.M0 <- function (sigma1_e = 0,
                               mdata,
                               link, start = NULL,
                               Lstart = NULL, criterion,
                               method.optim, slope.signs,
                               vary.sign = FALSE, fixL = FALSE,
                               n.restart = 3,
                               verbose) {
  mdata$sigma1_e <- sigma1_e

  if (verbose) {
    if (length(sigma1_e) ==1)
      cat(paste0("\n        - M0 specification: y ~ x1 with sigma1_e = ", round(sigma1_e, digits = 4), " ... "))
    else
      cat(paste0("\n        - M0 specification: y ~ x1 with E{sigma1_e} = ", round(mean(sigma1_e), digits = 4), " ... "))
  }

  M0fun <- function (Lstarti, fixL = FALSE, slope.signs = NULL) {
    rtime <- system.time({
      M0 <- catch.conditions({
        mrbglm::glm.mrb (formula = y ~ w1,
                         link = link,
                         maxp.formula = ~1,
                         x.with.me = TRUE,
                         me.offsets = ~ sigma1_e,
                         start = start,
                         Lstart = Lstarti,
                         control = control.mrb(fixL = fixL,
                                               criterion = criterion,
                                               method = method.optim,
                                               slope.signs = slope.signs),
                         data = mdata)
      })$value
    })
    M0 <- as.list(M0)
    M0$time <- rtime

    return(M0)

  }

  # Perform restarts if required
  if (n.restart > 0) {
    if (n.restart == 1)
      M0.seq <- list(M0fun(0.515, fixL = fixL, slope.signs = slope.signs))
    else
      M0.seq <- lapply(seq(0.04, 0.99, length.out = n.restart),
                       FUN = M0fun, fixL = fixL, slope.signs = slope.signs)

    if (!is.null(Lstart)) {
      M0.seq[[length(M0.seq) + 1]] <- M0fun(NULL, fixL = fixL, slope.signs = slope.signs) # Not specifying the starting L value
    }

  }
  else
    M0.seq <- list()

  # Use the supplied 'Lstart'
  if (!(identical(Lstart, 1) & fixL)) {
    M0.seq[[length(M0.seq) + 1]] <- M0fun(Lstart, fixL = fixL, slope.signs = slope.signs)
  }

  # Not specifying the starting L value (self-initialize)
  if (!is.null(Lstart)) {
    M0.seq[[length(M0.seq) + 1]] <- M0fun(NULL, fixL = fixL, slope.signs = slope.signs)
  }

  # Deviance of the GLM fit (L=1) with ME
  M0.seq[[length(M0.seq) + 1]] <- M0fun(1, fixL = TRUE, slope.signs = slope.signs)

  # Residual deviances of the fits
  rdev <- sapply(M0.seq, FUN = function(x) {
    if(!is.list(x))
      return(NA)
    res <- x$deviance

    if (is.null(res))
      return(NA)

    return(res)
  })

  # Pick the best fit
  M0 <- M0.seq[[which.min(rdev)]]

  if (is.null(slope.signs) & vary.sign) {
    M0neg <- M0fun (eval(M0$call$Lstart,
                         envir = environment(M0$call$formula)),
                    fixL = eval(M0$control$fixL,
                                envir = environment(M0$call$formula)),
                    slope.signs = 'negative')
    M0pos <- M0fun (eval(M0$call$Lstart,
                         envir = environment(M0$call$formula)),
                    fixL = eval(M0$control$fixL,
                                envir = environment(M0$call$formula)),
                    slope.signs = 'positive')

    M0.seq <- list(M0, M0neg, M0pos)
    rdev <- sapply(M0.seq, FUN = function(x) {
      if(!is.list(x))
        return(NA)
      res <- x$deviance

      if (is.null(res))
        return(NA)

      return(res)
    })
    M0 <- M0.seq[[which.min(rdev)]]
  }

  return(M0)

}

MBMfittingB.M1 <- function(mdata,
                           link, Lstart, criterion,
                           method.optim, slope.signs,
                           vary.sign = FALSE, fixL = FALSE,
                           n.restart = 3,
                           tau.e = 1,
                           verbose) {
  if (verbose) {
    cat("\n        - M1 specification: y ~ x1 + x2 ... ")
  }

  M1fun <- function (Lstarti, fixL = FALSE) {
    rtime <- system.time({
      M1 <- catch.conditions({
        mrbglm::glm.mrb (formula = y ~ w1 + w2,
                         link = link,
                         maxp.formula = ~1,
                         start = NULL,
                         Lstart = Lstarti,
                         control = control.mrb(fixL = fixL,
                                               criterion = criterion,
                                               method = method.optim,
                                               slope.signs = slope.signs),
                         data = mdata)
      })$value
    })
    M1 <- as.list(M1)
    M1$time <- rtime

    return(M1)

  }

  # Perform restarts if required
  if (n.restart > 0) {
    if (n.restart == 1)
      M1.seq <- lapply(0.515, FUN = M1fun, fixL = fixL)
    else
      M1.seq <- lapply(seq(0.04, 0.99, length.out = n.restart),
                       FUN = M1fun, fixL = fixL)
  }
  else {
    M1.seq <- list()
  }

  # Deviance of for L=1
  fit.glm <- M1fun(1, fixL = TRUE)
  M1.seq[[length(M1.seq) + 1]] <- fit.glm

  # Use the supplied 'Lstart'
  if (!(identical(Lstart, 1) & fixL)) {
    M1.seq[[length(M1.seq) + 1]] <- M1fun(Lstart, fixL = fixL)
  }

  # Not specifying the starting L value (self-initialize)
  if (!is.null(Lstart)) {
    M1.seq[[length(M1.seq) + 1]] <- M1fun(NULL, fixL = fixL)
  }

  # Residual deviances of the fits
  rdev <- sapply(M1.seq, FUN = function(x) {
    if(!is.list(x))
      return(NA)
    res <- x$deviance

    if (is.null(res))
      return(NA)

    return(res)
  })

  # Pick the best fit
  M1 <- M1.seq[[which.min(rdev)]]

  start_coef <- M1$coefficients
  start_L <- M1$L.values

  ### Fitting models accounting for true measurement errors if any
  M1 <- list(`tau=0` = M1)
  if (any(c(mdata$sigma1_e, mdata$sigma2_e) > 0) & any(tau.e > 0)) {
    tau.e <- tau.e[tau.e > 0]

    M1[2:(length(tau.e) + 1)] <- lapply(tau.e,
                                        FUN = function(tau) {
                                          me.MBMfittingB.M1(sigma1_e = tau * mdata$sigma1_e,
                                                            sigma2_e = tau * mdata$sigma2_e,
                                                            mdata = mdata, link = link,
                                                            start = start_coef, Lstart = start_L,
                                                            criterion = criterion,
                                                            method.optim = method.optim, slope.signs = slope.signs,
                                                            vary.sign = vary.sign, fixL = fixL,
                                                            n.restart = ceiling(n.restart/4),
                                                            verbose = max(0, verbose - 1))
                                        })

    names(M1) <- paste0('tau=', c(0, tau.e))
  }

  return(M1)
}

me.MBMfittingB.M1 <- function (sigma1_e = 0,
                               sigma2_e = 0,
                               mdata,
                               link, start = NULL,
                               Lstart = NULL, criterion,
                               method.optim, slope.signs,
                               vary.sign = FALSE, fixL = FALSE,
                               n.restart = 3,
                               verbose) {
  mdata$sigma1_e <- sigma1_e
  mdata$sigma2_e <- sigma2_e
  mdata$sigma3_e <- NULL

  if (verbose) {
    cat(paste0("\n        - M1 specification: y ~ x1 + x2 with E{sigma_e} = ",
               round(c(mean(sigma1_e), mean(sigma2_e)), digits = 4), " ... "))

  }

  M1fun <- function (Lstarti, fixL = FALSE, slope.signs) {
    rtime <- system.time({
      M1 <- catch.conditions({
        mrbglm::glm.mrb (formula = y ~ w1 + w2,
                         link = link,
                         maxp.formula = ~1,
                         x.with.me = c(TRUE, TRUE),
                         me.offsets = ~ sigma1_e + sigma2_e,
                         start = start,
                         Lstart = Lstarti,
                         control = control.mrb(fixL = fixL,
                                               criterion = criterion,
                                               method = method.optim,
                                               slope.signs = slope.signs),
                         data = mdata)
      })$value
    })
    M1 <- as.list(M1)
    M1$time <- rtime

    return(M1)

  }

  # Perform restarts if required
  if (n.restart > 0) {
    if (n.restart == 1)
      M1.seq <- list(M1fun(0.515, fixL = fixL, slope.signs = slope.signs))
    else
      M1.seq <- lapply(seq(0.04, 0.99, length.out = n.restart),
                       FUN = M1fun, fixL = fixL, slope.signs = slope.signs)

    if (!is.null(Lstart)) {
      M1.seq[[length(M1.seq) + 1]] <- M1fun(NULL, fixL = fixL, slope.signs = slope.signs) # Not specifying the starting L value
    }

  }
  else
    M1.seq <- list()

  # Use the supplied 'Lstart'
  if (!(identical(Lstart, 1) & fixL)) {
    M1.seq[[length(M1.seq) + 1]] <- M1fun(Lstart, fixL = fixL, slope.signs = slope.signs)
  }

  # Not specifying the starting L value (self-initialize)
  if (!is.null(Lstart)) {
    M1.seq[[length(M1.seq) + 1]] <- M1fun(NULL, fixL = fixL, slope.signs = slope.signs)
  }

  # Deviance of the GLM fit (L=1) with ME
  M1.seq[[length(M1.seq) + 1]] <- M1fun(1, fixL = TRUE, slope.signs = slope.signs)

  # Residual deviances of the fits
  rdev <- sapply(M1.seq, FUN = function(x) {
    if(!is.list(x))
      return(NA)
    res <- x$deviance

    if (is.null(res))
      return(NA)

    return(res)
  })

  # Pick the best fit
  M1 <- M1.seq[[which.min(rdev)]]

  if (is.null(slope.signs) & vary.sign) {
    M1neg <- M1fun (eval(M1$call$Lstart,
                         envir = environment(M1$call$formula)),
                    fixL = eval(M1$control$fixL,
                                envir = environment(M1$call$formula)),
                    slope.signs = 'negative')
    M1pos <- M1fun (eval(M1$call$Lstart,
                         envir = environment(M1$call$formula)),
                    fixL = eval(M1$control$fixL,
                                envir = environment(M1$call$formula)),
                    slope.signs = 'positive')

    M1.seq <- list(M1, M1neg, M1pos)
    rdev <- sapply(M1.seq, FUN = function(x) {
      if(!is.list(x))
        return(NA)
      res <- x$deviance

      if (is.null(res))
        return(NA)

      return(res)
    })
    M1 <- M1.seq[[which.min(rdev)]]
  }

  return(M1)

}

MBMfittingB.M2 <- function(mdata, w3.continuous,
                           link, Lstart, criterion,
                           method.optim, slope.signs,
                           vary.sign = FALSE, fixL = FALSE,
                           n.restart = 3,
                           tau.e = 1,
                           verbose) {
  if (verbose) {
    cat("\n        - M2 specification: y ~ x1 + x3 ... ")
  }

  M2fun <- function (Lstarti, fixL = FALSE) {
    rtime <- system.time({
      M2 <- catch.conditions({
        mrbglm::glm.mrb (formula = y ~ w1 + w3,
                         link = link,
                         maxp.formula = ~1,
                         start = NULL,
                         Lstart = Lstarti,
                         control = control.mrb(fixL = fixL,
                                               criterion = criterion,
                                               method = method.optim,
                                               slope.signs = slope.signs),
                         data = mdata)
      })$value
    })
    M2 <- as.list(M2)
    M2$time <- rtime

    return(M2)

  }

  # Perform restarts if required
  if (n.restart > 0) {
    if (n.restart == 1)
      M2.seq <- lapply(0.515, FUN = M2fun, fixL = fixL)
    else
      M2.seq <- lapply(seq(0.04, 0.99, length.out = n.restart),
                       FUN = M2fun, fixL = fixL)
  }
  else {
    M2.seq <- list()
  }

  # Deviance of for L=1
  fit.glm <- M2fun(1, fixL = TRUE)
  M2.seq[[length(M2.seq) + 1]] <- fit.glm

  # Use the supplied 'Lstart'
  if (!(identical(Lstart, 1) & fixL)) {
    M2.seq[[length(M2.seq) + 1]] <- M2fun(Lstart, fixL = fixL)
  }

  # Not specifying the starting L value (self-initialize)
  if (!is.null(Lstart)) {
    M2.seq[[length(M2.seq) + 1]] <- M2fun(NULL, fixL = fixL)
  }

  # Residual deviances of the fits
  rdev <- sapply(M2.seq, FUN = function(x) {
    if(!is.list(x))
      return(NA)
    res <- x$deviance

    if (is.null(res))
      return(NA)

    return(res)
  })

  # Pick the best fit
  M2 <- M2.seq[[which.min(rdev)]]

  start_coef <- M2$coefficients
  start_L <- M2$L.values

  ### Fitting models accounting for true measurement errors if any
  M2 <- list(`tau=0` = M2)
  if (any(c(mdata$sigma1_e, mdata$sigma3_e) > 0) & any(tau.e > 0)) {
    tau.e <- tau.e[tau.e > 0]

    M2[2:(length(tau.e) + 1)] <- lapply(tau.e,
                                        FUN = function(tau) {
                                          me.MBMfittingB.M2(sigma1_e = tau * mdata$sigma1_e,
                                                            sigma3_e = if (w3.continuous) tau * mdata$sigma3_e,
                                                            mdata = mdata, w3.continuous = w3.continuous, link = link,
                                                            start = start_coef, Lstart = start_L,
                                                            criterion = criterion,
                                                            method.optim = method.optim, slope.signs = slope.signs,
                                                            vary.sign = vary.sign, fixL = fixL,
                                                            n.restart = ceiling(n.restart/4),
                                                            verbose = max(0, verbose - 1))
                                        })

    names(M2) <- paste0('tau=', c(0, tau.e))
  }

  return(M2)
}

me.MBMfittingB.M2 <- function (sigma1_e = 0,
                               sigma3_e = 0,
                               mdata,
                               w3.continuous,
                               link, start = NULL,
                               Lstart = NULL, criterion,
                               method.optim, slope.signs,
                               vary.sign = FALSE, fixL = FALSE,
                               n.restart = 3,
                               verbose) {
  mdata$sigma1_e <- sigma1_e
  mdata$sigma2_e <- NULL
  mdata$sigma3_e <- sigma3_e

  if (verbose) {
    cat(paste0("\n        - M2 specification: y ~ x1 + x3 with E{sigma_e} = ",
               round(c(mean(sigma1_e), if (w3.continuous) mean(sigma3_e)), digits = 4), " ... "))

  }

  if (w3.continuous) {
    M2fun <- function (Lstarti, fixL = FALSE, slope.signs) {
      rtime <- system.time({
        M2 <- catch.conditions({
          mrbglm::glm.mrb (formula = y ~ w1 + w3,
                           link = link,
                           maxp.formula = ~1,
                           x.with.me = c(TRUE, TRUE),
                           me.offsets = ~ sigma1_e + sigma3_e,
                           start = start,
                           Lstart = Lstarti,
                           control = control.mrb(fixL = fixL,
                                                 criterion = criterion,
                                                 method = method.optim,
                                                 slope.signs = slope.signs),
                           data = mdata)
        })$value
      })
      M2 <- as.list(M2)
      M2$time <- rtime

      return(M2)

    }
  }
  else {
    M2fun <- function (Lstarti, fixL = FALSE, slope.signs) {
      rtime <- system.time({
        M2 <- catch.conditions({
          mrbglm::glm.mrb (formula = y ~ w1 + w3,
                           link = link,
                           maxp.formula = ~1,
                           x.with.me = c(TRUE, FALSE),
                           me.offsets = ~ sigma1_e,
                           start = start,
                           Lstart = Lstarti,
                           control = control.mrb(fixL = fixL,
                                                 criterion = criterion,
                                                 method = method.optim,
                                                 slope.signs = slope.signs),
                           data = mdata)
        })$value
      })
      M2 <- as.list(M2)
      M2$time <- rtime

      return(M2)

    }
  }

  # Perform restarts if required
  if (n.restart > 0) {
    if (n.restart == 1)
      M2.seq <- list(M2fun(0.515, fixL = fixL, slope.signs = slope.signs))
    else
      M2.seq <- lapply(seq(0.04, 0.99, length.out = n.restart),
                       FUN = M2fun, fixL = fixL, slope.signs = slope.signs)

    if (!is.null(Lstart)) {
      M2.seq[[length(M2.seq) + 1]] <- M2fun(NULL, fixL = fixL, slope.signs = slope.signs) # Not specifying the starting L value
    }

  }
  else
    M2.seq <- list()

  # Use the supplied 'Lstart'
  if (!(identical(Lstart, 1) & fixL)) {
    M2.seq[[length(M2.seq) + 1]] <- M2fun(Lstart, fixL = fixL, slope.signs = slope.signs)
  }

  # Not specifying the starting L value (self-initialize)
  if (!is.null(Lstart)) {
    M2.seq[[length(M2.seq) + 1]] <- M2fun(NULL, fixL = fixL, slope.signs = slope.signs)
  }

  # Deviance of the GLM fit (L=1) with ME
  M2.seq[[length(M2.seq) + 1]] <- M2fun(1, fixL = TRUE, slope.signs = slope.signs)

  # Residual deviances of the fits
  rdev <- sapply(M2.seq, FUN = function(x) {
    if(!is.list(x))
      return(NA)
    res <- x$deviance

    if (is.null(res))
      return(NA)

    return(res)
  })

  # Pick the best fit
  M2 <- M2.seq[[which.min(rdev)]]

  if (is.null(slope.signs) & vary.sign) {
    M2neg <- M2fun (eval(M2$call$Lstart,
                         envir = environment(M2$call$formula)),
                    fixL = eval(M2$control$fixL,
                                envir = environment(M2$call$formula)),
                    slope.signs = 'negative')
    M2pos <- M2fun (eval(M2$call$Lstart,
                         envir = environment(M2$call$formula)),
                    fixL = eval(M2$control$fixL,
                                envir = environment(M2$call$formula)),
                    slope.signs = 'positive')

    M2.seq <- list(M2, M2neg, M2pos)
    rdev <- sapply(M2.seq, FUN = function(x) {
      if(!is.list(x))
        return(NA)
      res <- x$deviance

      if (is.null(res))
        return(NA)

      return(res)
    })
    M2 <- M2.seq[[which.min(rdev)]]
  }

  return(M2)

}

MBMfittingB.M3 <- function(mdata, w3.continuous,
                           link, Lstart, criterion,
                           method.optim, slope.signs,
                           vary.sign = FALSE, fixL = FALSE,
                           n.restart = 3,
                           tau.e = 1,
                           verbose) {
  if (verbose) {
    cat("\n        - M3 specification: y ~ x1 + x2 + x3 ... ")
  }

  M3fun <- function (Lstarti, fixL = FALSE) {
    rtime <- system.time({
      M3 <- catch.conditions({
        mrbglm::glm.mrb (formula = y ~ w1 + w2 + w3,
                         link = link,
                         maxp.formula = ~1,
                         start = NULL,
                         Lstart = Lstarti,
                         control = control.mrb(fixL = fixL,
                                               criterion = criterion,
                                               method = method.optim,
                                               slope.signs = slope.signs),
                         data = mdata)
      })$value
    })
    M3 <- as.list(M3)
    M3$time <- rtime

    return(M3)

  }

  # Perform restarts if required
  if (n.restart > 0) {
    if (n.restart == 1)
      M3.seq <- lapply(0.515, FUN = M3fun, fixL = fixL)
    else
      M3.seq <- lapply(seq(0.04, 0.99, length.out = n.restart),
                       FUN = M3fun, fixL = fixL)
  }
  else {
    M3.seq <- list()
  }

  # Deviance of for L=1
  fit.glm <- M3fun(1, fixL = TRUE)
  M3.seq[[length(M3.seq) + 1]] <- fit.glm

  # Use the supplied 'Lstart'
  if (!(identical(Lstart, 1) & fixL)) {
    M3.seq[[length(M3.seq) + 1]] <- M3fun(Lstart, fixL = fixL)
  }

  # Not specifying the starting L value (self-initialize)
  if (!is.null(Lstart)) {
    M3.seq[[length(M3.seq) + 1]] <- M3fun(NULL, fixL = fixL)
  }

  # Residual deviances of the fits
  rdev <- sapply(M3.seq, FUN = function(x) {
    if(!is.list(x))
      return(NA)
    res <- x$deviance

    if (is.null(res))
      return(NA)

    return(res)
  })

  # Pick the best fit
  M3 <- M3.seq[[which.min(rdev)]]

  start_coef <- M3$coefficients
  start_L <- M3$L.values

  ### Fitting models accounting for true measurement errors if any
  M3 <- list(`tau=0` = M3)
  if (any(c(mdata$sigma1_e, mdata$sigma2_e, mdata$sigma3_e) > 0) & any(tau.e > 0)) {
    tau.e <- tau.e[tau.e > 0]

    M3[2:(length(tau.e) + 1)] <- lapply(tau.e,
                                        FUN = function(tau) {
                                          me.MBMfittingB.M3(sigma1_e = tau * mdata$sigma1_e,
                                                            sigma2_e = tau * mdata$sigma2_e,
                                                            sigma3_e = if (w3.continuous) tau * mdata$sigma3_e,
                                                            mdata = mdata, w3.continuous = w3.continuous, link = link,
                                                            start = start_coef, Lstart = start_L,
                                                            criterion = criterion,
                                                            method.optim = method.optim, slope.signs = slope.signs,
                                                            vary.sign = vary.sign, fixL = fixL,
                                                            n.restart = ceiling(n.restart/4),
                                                            verbose = max(0, verbose - 1))
                                        })

    names(M3) <- paste0('tau=', c(0, tau.e))
  }

  return(M3)
}

me.MBMfittingB.M3 <- function (sigma1_e = 0,
                               sigma2_e = 0,
                               sigma3_e = 0,
                               mdata,
                               w3.continuous,
                               link, start = NULL,
                               Lstart = NULL, criterion,
                               method.optim, slope.signs,
                               vary.sign = FALSE, fixL = FALSE,
                               n.restart = 3,
                               verbose) {
  mdata$sigma1_e <- sigma1_e
  mdata$sigma2_e <- sigma2_e
  mdata$sigma3_e <- sigma3_e

  if (verbose) {
    cat(paste0("\n        - M3 specification: y ~ x1 + x2 + x3 with E{sigma_e} = ",
               round(c(mean(sigma1_e), mean(sigma2_e), if (w3.continuous) mean(sigma3_e)), digits = 4), " ... "))

  }

  if (w3.continuous) {
    M3fun <- function (Lstarti, fixL = FALSE, slope.signs) {
      rtime <- system.time({
        M3 <- catch.conditions({
          mrbglm::glm.mrb (formula = y ~ w1 + w2 + w3,
                           link = link,
                           maxp.formula = ~1,
                           x.with.me = c(TRUE, TRUE, TRUE),
                           me.offsets = ~ sigma1_e + sigma2_e + sigma3_e,
                           start = start,
                           Lstart = Lstarti,
                           control = control.mrb(fixL = fixL,
                                                 criterion = criterion,
                                                 method = method.optim,
                                                 slope.signs = slope.signs),
                           data = mdata)
        })$value
      })
      M3 <- as.list(M3)
      M3$time <- rtime

      return(M3)

    }
  }
  else {
    M3fun <- function (Lstarti, fixL = FALSE, slope.signs) {
      rtime <- system.time({
        M3 <- catch.conditions({
          mrbglm::glm.mrb (formula = y ~ w1 + w2 + w3,
                           link = link,
                           maxp.formula = ~1,
                           x.with.me = c(TRUE, TRUE, FALSE),
                           me.offsets = ~ sigma1_e + sigma2_e,
                           start = start,
                           Lstart = Lstarti,
                           control = control.mrb(fixL = fixL,
                                                 criterion = criterion,
                                                 method = method.optim,
                                                 slope.signs = slope.signs),
                           data = mdata)
        })$value
      })
      M3 <- as.list(M3)
      M3$time <- rtime

      return(M3)

    }
  }

  # Perform restarts if required
  if (n.restart > 0) {
    if (n.restart == 1)
      M3.seq <- list(M3fun(0.515, fixL = fixL, slope.signs = slope.signs))
    else
      M3.seq <- lapply(seq(0.04, 0.99, length.out = n.restart),
                       FUN = M3fun, fixL = fixL, slope.signs = slope.signs)

    if (!is.null(Lstart)) {
      M3.seq[[length(M3.seq) + 1]] <- M3fun(NULL, fixL = fixL, slope.signs = slope.signs) # Not specifying the starting L value
    }

  }
  else
    M3.seq <- list()

  # Use the supplied 'Lstart'
  if (!(identical(Lstart, 1) & fixL)) {
    M3.seq[[length(M3.seq) + 1]] <- M3fun(Lstart, fixL = fixL, slope.signs = slope.signs)
  }

  # Not specifying the starting L value (self-initialize)
  if (!is.null(Lstart)) {
    M3.seq[[length(M3.seq) + 1]] <- M3fun(NULL, fixL = fixL, slope.signs = slope.signs)
  }

  # Deviance of the GLM fit (L=1) with ME
  M3.seq[[length(M3.seq) + 1]] <- M3fun(1, fixL = TRUE, slope.signs = slope.signs)

  # Residual deviances of the fits
  rdev <- sapply(M3.seq, FUN = function(x) {
    if(!is.list(x))
      return(NA)
    res <- x$deviance

    if (is.null(res))
      return(NA)

    return(res)
  })

  # Pick the best fit
  M3 <- M3.seq[[which.min(rdev)]]

  if (is.null(slope.signs) & vary.sign) {
    M3neg <- M3fun (eval(M3$call$Lstart,
                         envir = environment(M3$call$formula)),
                    fixL = eval(M3$control$fixL,
                                envir = environment(M3$call$formula)),
                    slope.signs = 'negative')
    M3pos <- M3fun (eval(M3$call$Lstart,
                         envir = environment(M3$call$formula)),
                    fixL = eval(M3$control$fixL,
                                envir = environment(M3$call$formula)),
                    slope.signs = 'positive')

    M3.seq <- list(M3, M3neg, M3pos)
    rdev <- sapply(M3.seq, FUN = function(x) {
      if(!is.list(x))
        return(NA)
      res <- x$deviance

      if (is.null(res))
        return(NA)

      return(res)
    })
    M3 <- M3.seq[[which.min(rdev)]]
  }

  return(M3)

}
