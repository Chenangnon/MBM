
#' Simulations with p = 1
#'
#' Run simulations

#' @export batchsimulations

batchsimulations <- function (ns = c(100, 200, 300, 500, 750, 1000, 2000),
                             lambdas = c(0.25, 0.5, 0.75, 0.9, 1),
                             betas = list(c(3, -1)),
                             xdistrs = list('unif', 'norm', 'lnorm'),
                             link = "logit",
                             mrb.control = list(),
                             B = 2000, seed = NULL, savepath = NULL,
                             cl = parallel::getDefaultCluster(),
                             chunk.size = NULL) {

  if (!is.null(seed))
    set.seed(seed)

  steprunp1 <- function (nlambdajbetakxdistr) {
    n <- as.numeric(nlambdajbetakxdistr[1])
    lambda <- as.numeric(nlambdajbetakxdistr[2])
    j <- as.numeric(nlambdajbetakxdistr[3])
    k <- as.numeric(nlambdajbetakxdistr[4])

    beta <- betas[[j]]
    xdistr <- xdistrs[[k]]

    if (beta[2] != 0) {
    wmin <- (5 - beta[1]) / beta[2]
    wmax <- (-5 - beta[1]) / beta[2]
    }
    else {
      wmin <- - 5 + beta[1]
      wmax <-   5 + beta[1]
    }

    batchres <- Brunsp1 (n = n,
                         lambda = lambda,
                         beta = beta,
                         xdistr = xdistr,
                         wmin = wmin, wmax = wmax, link = link,
                         mrb.control = mrb.control,
                         B = B, seed = NULL,
                         savepath = savepath)

    batchres$sumry <- rbind(c(n = n, lambda = lambda,
                        beta0 = beta[1], beta1 = beta[2],
                        xdistr = xdistr,
                        batchres$sumry))
    batchres$sumry <- as.data.frame(batchres$sumry)

    batchres$Bouts <- as.data.frame(batchres$Bouts)
    batchres$Bouts <- cbind(n = n, lambda = lambda,
                            beta0 = beta[1], beta1 = beta[2],
                            xdistr = xdistr, batchres$Bouts)

    return(batchres)
  }

  pgrid <- expand.grid(n = ns,
                       lambda = lambdas,
                       jbeta = 1:length(betas),
                       kxdistr = 1:length(xdistrs))
  Bouts <- mrbglm:::matteApply(X = pgrid, MARGIN = 1,
                              FUN = steprunp1,
                              simplify = FALSE,
                              cl = cl,
                              chunk.size = chunk.size)
  if (!is.null(cl)) {
    stopCluster(cl = cl)
  }

  sumry <- lapply(Bouts, FUN = function(x) x$sumry)
  sumry <- do.call('rbind', sumry)
  Bouts <- lapply(Bouts, FUN = function(x) x$Bouts)
  Bouts <- do.call('rbind', Bouts)

  if (!is.null(savepath)) {
    savepath <- paste0(savepath, 'batchrun_')
    write.table(Bouts, file  = paste0(savepath, 'Bouts.txt'))
    write.table(sumry, file  = paste0(savepath, 'sumry.txt'))
  }

  return(list(sumry = sumry, Bouts = Bouts))

}

# Run B replicates of one simulation setting (n, lambda, beta, xdistr)
Brunsp1 <- function (n = 100, lambda = 0.5,
                       beta = c(3, -1), xdistr = 'unif',
                       wmin = -2, wmax = 8,
                       link = "logit",
                       mrb.control = list(),
                       B = 2000, seed = NULL,
                       savepath = NULL) {
  p <- length(beta) / 2
  if (!is.null(seed))
    set.seed(seed)

  mrb.control <- do.call( "control.mrb", mrb.control)
  K <- 1:B
  Btime <- system.time({
    Bouts <- t(sapply(K,
                   FUN = function(j) {
                     one_run (n = n, lambda = lambda, beta = beta, xdistr = xdistr,
                              wmin = wmin, wmax = wmax, link = link,
                              mrb.control = mrb.control, seed = NULL)
                   }))
  })

  nouts <- NCOL(Bouts)

  sumry <- c(colMeans(Bouts, na.rm = TRUE),
             mrbglm:::colStats(Bouts, stat = var, na.rm = TRUE),
             Elapsed = Btime[3])

  SBMpaste <- c('beta0', paste0('beta', 1:p), 'sebeta0', paste0('sebeta', 1:p))
  SBMpaste <- c(SBMpaste, 'MADmu', 'MSEmu', 'R2mu', 'null.dev', 'dev', 'aic')
  outterpaste <- c(outer(c('beta0', 'beta', 'delta'), 1:p, paste0), 'lambdahat')
  outterpaste0 <- c(outterpaste, paste0('se', outterpaste),
                    'covb', 'MADmu', 'MSEmu', 'R2mu', 'null.dev', 'dev', 'aic')
  namesdf <- c(paste0(SBMpaste, '.SBM'),
               paste0(outterpaste0, '.ML'),
               paste0(outterpaste0, '.r1'),
               paste0(outterpaste0, '.r01'),
               paste0(outterpaste0, '.b50'),
               'pxbar', 'etabar', 'trueetabar',
               paste0('mean.x', 1:p), 'mean.y')
  names(sumry) <- c(outer(namesdf,
                           c('.mean', '.var'), paste0),
                     'Elapsed(s)')
  colnames(Bouts) <- namesdf

  output <- list(sumry = sumry, Bouts = Bouts)

  if (!is.null(savepath)) {
    savepath <- paste0(savepath,
                       paste0(unlist(xdistr)), 'n', n, 'L', lambda,
                       'b', paste0(beta, collapse = ''))
    write.table(output$Bouts, file  = paste0(savepath, 'Bouts.txt'))
    write.table(output$sumry, file  = paste0(savepath, 'sumry.txt'))
  }

  return(output)
}

# Run one replicate of one simulation setting (n, lambda, beta, xdistr)
one_run <- function (n = 100, lambda = 0.5, beta = c(3, -1),
                     xdistr = 'unif',
                     wmin = -2, wmax = 8,
                     link = "logit",
                     mrb.control = list(),
                     seed = NULL) {
  ### Dimensions
  beta <- as.numeric(beta)
  p <- length(beta) / 2
  stopifnot(p %in% c(1, 2, 3, 4))
  mrb.control <- do.call( "control.mrb", mrb.control)

  # Link function
  link <- stats::binomial(link = link)$link
  linkinv <- switch(link,
                    logit = stats::plogis,
                    stats::pnorm)
  linkfun <- switch(link,
                    logit = stats::qlogis,
                    stats::qnorm)
  delta <- linkfun(lambda)
  delta <- as.numeric(delta)

  ### Simulate a dataset
  if (!is.null(seed))
    set.seed(seed)

  # Design matrix
  x <- getorthcovmat (n = n, xdistr = xdistr,
                      wmin = wmin, wmax = wmax)

  # Binary response
  mrbdata <- sim.mrb (beta = beta, delta = delta, x = x,
                      link = link, yname = "y")
  #  x <- mrbdata$data[, 2:(1 + p), drop = FALSE]
  y <- mrbdata$data[, 1]

  # Standard Logistic regression
  fitdata <- mrbdata$data[, 1:(1 + p), drop = FALSE]
  SBM <- glm(y ~ ., data = fitdata, family = binomial(link))
  MADsmb <- mean(abs(SBM$fitted.values - mrbdata$mu), na.rm = TRUE)
  MSEsmb <- mean((SBM$fitted.values - mrbdata$mu)^2, na.rm = TRUE)
  R2smb <- cor(SBM$fitted.values, mrbdata$mu)^2
  SBM <- c(c(summary(SBM)$coefficients[,1:2]),
           MADsmb, MSEsmb, R2smb,
           SBM$null.deviance, SBM$deviance, SBM$aic)

  # Center the data (predictors)
  fitdata$x1 <- fitdata$x1 - mean(fitdata$x1)
  if (p >= 2) {
    fitdata$x2 <- fitdata$x2 - mean(fitdata$x2)
  }
  if (p >= 3) {
    fitdata$x3 <- fitdata$x3 - mean(fitdata$x3)
  }
  if (p == 4) {
    fitdata$x4 <- fitdata$x4 - mean(fitdata$x4)
  }

  # Functions to fit and summarize a model
  if (p == 1) {
    onefit <- function(mrb.control, Lstart = NULL) {

      fit0 <- glm.mrb (y ~ x1, data = fitdata, link = link,
                       start = c(beta, delta), Lstart = Lstart,
                       control = mrb.control)
    }
  }
  else if (p == 2) {
    onefit <- function(mrb.control, Lstart = NULL) {
      fit0 <- glm.mrb (y ~ x1 + x2, data = fitdata, link = link,
                       start = c(beta, delta), Lstart = Lstart,
                       control = mrb.control)
    }
  }
  else if (p == 3) {
    onefit <- function(mrb.control, Lstart = NULL) {
      fit0 <- glm.mrb (y ~ x1 + x2 + x3, data = fitdata, link = link,
                       start = c(beta, delta), Lstart = Lstart,
                       control = mrb.control)
    }
  }
  else {
    onefit <- function(mrb.control, Lstart = NULL) {
      fit0 <- glm.mrb (y ~ x1 + x2 + x3 + x4, data = fitdata, link = link,
                       start = c(beta, delta), Lstart = Lstart,
                       control = mrb.control)
    }
  }

  xmeans <- colMeans(x)
  ints <- (1:(2*p))[1:(2*p) %% 2 == 1]
  slps <- (1:(2*p))[1:(2*p) %% 2 == 0]
  # Translate estimate of beta0tilde (intercept using x - xbar) back to beta0
  outfun <- function(fitj) {

    sumj <- summary(fitj)
    covj <- sapply(1:p, FUN = function(k) {
      sumj$cov.unscaled[ints[k], slps[k]]
    })

    ests <- sumj$coefficients[, 1]
    stdj <- sumj$coefficients[, 2]

    ests[ints] <- ests[ints] - ests[slps] * xmeans
    stdj[ints] <- sqrt(stdj[ints]^2 + (stdj[slps] * xmeans)^2 -
      2 * xmeans * covj)

    ests <- c(ests, sumj$L[1])
    stdj <- c(stdj, sumj$L[2])

    MADmu <- mean(abs(fitj$fitted.values - mrbdata$mu), na.rm = TRUE)
    MSEmu <- mean((fitj$fitted.values - mrbdata$mu)^2, na.rm = TRUE)
    R2mu <- cor(fitj$fitted.values, mrbdata$mu)^2

    return(c(ests, stdj, covj, MADmu, MSEmu, R2mu,
             fitj$null.deviance, fitj$deviance, fitj$aic))
  }

  # Baseline fit ML (with unrestricted beta0 and beta1)
  mrb.control$fixL <- FALSE
  mrb.control$penalty <- 'none'
  mrb.control$penalize.intercepts <- FALSE
  mrb.control$lower.intercepts <- 'xmin'
  mrb.control$upper.intercepts <- 'xmax'
  fitML <- onefit (mrb.control)
  outML <- outfun (fitML)

  # Unrestricted beta0, ridge penalty for beta1
  mrb.control$penalty <- 'ridge'
  mrb.control$nobs.power <- 0.05
  fitb <- onefit (mrb.control)
  outb <- outfun (fitb)

  # Fits with ridge around zero penalty for beta0 and beta1
  mrb.control$penalize.intercepts <- TRUE
  mrb.control$int.location <- 0
  fit0 <- onefit (mrb.control)
  out0 <- outfun (fit0)

  po0 <- find.pmean (x = x, y = y, bandwith = 0.5)
  eps <- mrb.control$epsilon
  mlL <- max(as.numeric(fitb$L.values), 0.2)
  po <- pmax(pmin(min(po0$po, (1 - eps) * mlL), mlL - eps), eps)
  pzeros <- po
  beta0tilde <- max(min(linkfun (min(po / mlL, 1 - eps)), 4), -4)

  # Fits with ridge around beta0tilde penalty for beta0 and beta1
  mrb.control$int.location <- beta0tilde
  fit1 <- onefit (mrb.control)
  out1 <- outfun (fit1)

  trueetabar <- beta[1] + beta[2] * xmeans[1]

  return(c(SBM,
           c(outML),
           c(outb),
           c(out0),
           c(out1),
           pzeros,
           beta0tilde,
           trueetabar,
           mean = xmeans,
           mean(y)
  ))
}

# Design matrix / data
getorthcovmat <- function (n = 100, xdistr = 'unif', wmin = -2, wmax = 8) {
  p <- length(xdistr)
  stopifnot(p %in% c(1,2,3,4))

  x <- getonecov (n = n, xdistr = xdistr[1], wmin = wmin, wmax = wmax)

  if (p > 1) {
    x <- cbind(x,
               x2 = getonecov (n = n, xdistr = xdistr[2], wmin = wmin, wmax = wmax))
  }

  if (p > 2) {
    x <- cbind(x,
               x3 = getonecov (n = n, xdistr = xdistr[3], wmin = wmin, wmax = wmax))
  }

  if (p > 3) {
    x <- cbind(x,
               x4 = getonecov (n = n, xdistr = xdistr[4], wmin = wmin, wmax = wmax))
  }

  colnames(x) <- paste0('x', 1:p)

  return(x)
}

getonecov <- function (n, xdistr, wmin = -2, wmax = 8) {
  switch(tolower(xdistr),
         unif = {
           x <- cbind(x1 = runif(n, min = wmin, max = wmax))
         },
         norm = {
           x <- cbind(x1 = rnorm(n, mean = 3, sd = 1.6))
           x <- wmin + (x + 2) * (wmax - wmin) / 10 # Rescale to the interval [wmax, wmin]
         },
         lnorm = {
           x <- cbind(x1 = rlnorm(n, meanlog = 1.1, sdlog = 0.5))
           x <- wmin + (x - 0) * (wmax - wmin) / 10 # Rescale to the interval [wmax, wmin]
         })

  return (x)
}

# Find \tilde{\beta}_0: the location of the prior distribution on intercepts
find.pmean <- function (x, y, bandwith = 0.1) {
  #* Find the indices of the points to use
  dxbar <- abs(x - mean(x))
  qlim <- quantile(dxbar, prob = max(bandwith, 2/length(y)))
  pick <- dxbar <= qlim

  #* Find the success probability around xbar
  po <- mean(y[pick])

  return(list(po = po, pick = pick))
}
