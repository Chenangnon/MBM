#' Bivariate \code{logit} Link Function
#'
#' Multiplicative and additive bivariate \code{logit} link functions.
#'
#' @param x1,x2 numeric vectors, exposure/predictor values.
#'
#' @param a  numeric scalar, the \code{logit} of the success probability of the
#' response when \code{x1 = x2 --> -oo}, i.e. the maximum achievable probability
#' value.
#'
#' @param b1,b2 numeric scalars, slopes of \code{x1} and \code{x2} (logit scale).
#'
# @param shift numeric scalar, simultaneous translation of the values of
# \code{a}, \code{x1} and \code{x2}.
#'
#' @usage
#' biv.plogit.sum (x1, x2 = x1, a = -stats::qlogis(.95), b1 = 1, b2 = b1)
#'
#' biv.plogit.prod (x1, x2 = x1, a = -stats::qlogis(.95), b1 = 1, b2 = b1)
#'
#' @return a vector of probabilities in the upper tail for the 'bivariate'
#' logistic distributions.
#'
#' @aliases biv.plogit.sum
#'
#' @export biv.plogit.sum
#' @export biv.plogit.prod
#' @import stats
#'
#' @details The function \code{biv.plogit.sum} is essentially a univariate logit
#' function on the linear combination of \code{x1} and \code{x2} with weights
#' \code{b1} and \code{b2}, respectively. In other words, the function adds logits
#' linked to exposure to \code{x1} and \code{x2}, and then map the result to
#' the risk (probability) scale. However, the intercept \code{a} is separately
#' used to obtain a multiplicative intercept.
#'
#' The function \code{biv.plogit.prod} computes the probability corresponding to
#' each exposure and takes the product.
#'
#' @examples
#' ## Example 1: Table of probabilities
#' x1 <- seq(-3, 3, length.out = 5)
#' x2 <- rep(x1, 5)
#' x1 <- rep(x1, each = 5)
#'
#' res <- data.frame(x1 = x1, x2 = x2,
#'                   plogis1 = .95 * plogis(x1, lower.tail = FALSE),
#'                   plogis2 = .95 * plogis(x2, lower.tail = FALSE),
#'                   biv.sum = biv.plogit.sum(x1, x2, a = -qlogis(.95)),
#'                   biv.prod = biv.plogit.prod(x1, x2, a = -qlogis(.95)))
#' round(res, 4)
#'
#' ## Example 2: 3D plot of probabilities
#' x <- seq(-3, 3, length.out = 30)
#' y <- x
#' zsum <- outer(x, y, biv.plogit.sum)
#' zprod <- outer(x, y, biv.plogit.prod)
# par (mfrow = c(2,1))
#' op <- par(bg = "white")
#' persp(x, y, zsum, theta = 20, phi = 20, expand = 0.5, col = "lightblue",
#'       ltheta = 120, shade = 0.75, ticktype = "detailed",
#'       xlab = "X1", ylab = "X2", zlab = "E(Y)", zlim = c(0, 1),
#'       main = "Logit sum (product of odds)")
#'
#' persp(x, y, zprod, theta = 20, phi = 20, expand = 0.5, col = "lightblue",
#'       ltheta = 120, shade = 0.75, ticktype = "detailed",
#'       xlab = "X1", ylab = "X2", zlab = "E(Y)", zlim = c(0, 1),
#'       main = "Expit product (product of probs)")
#'

biv.plogit.prod <- function (x1, x2 = x1, a = -stats::qlogis(.95), b1 = 1, b2 = b1) {
  exp(stats::plogis(a, log.p = TRUE, lower.tail = FALSE) +
        stats::plogis(b1 * (x1), log.p = TRUE, lower.tail = FALSE) +
        stats::plogis(b2 * (x2), log.p = TRUE, lower.tail = FALSE))
}

biv.plogit.sum <- function (x1, x2 = x1, a = -stats::qlogis(.95), b1 = 1, b2 = b1) {
  exp(stats::plogis(a, log.p = TRUE, lower.tail = FALSE) +
        stats::plogis(b1 * (x1) + b2 * (x2), log.p = TRUE, lower.tail = FALSE))
}

