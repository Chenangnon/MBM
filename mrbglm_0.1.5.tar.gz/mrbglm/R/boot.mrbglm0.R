# Bootstrap a Multiplicative Risk Binomial Regression Model Fit
boot0.mrbglm0 <- function (object, nb.resamples = 999,
                         boot.type = "ordinary", simple = FALSE,
                         parallel = c("no", "multicore", "snow"),
                         ncpus = getOption("boot.ncpus", 1L),
                         cl = NULL) {

  # Using Jackknife estimates when \code{nb.resamples = NULL}
  if (is.null(nb.resamples)) {
    return(jackknife.mrb(object))
  }

  # Define a function to compute the target statistics and use 'boot::boot'
  switch(boot.type,
         parametric = boot.parametric (object = object,
                                       nb.resamples = nb.resamples,
                                       simple = simple,
                                       parallel =parallel,
                                       ncpus = ncpus,
                                       cl = cl),
         boot.ordinary (object = object,
                        nb.resamples = nb.resamples,
                        simple = simple,
                        parallel =parallel,
                        ncpus = ncpus,
                        cl = cl)
  )

}

