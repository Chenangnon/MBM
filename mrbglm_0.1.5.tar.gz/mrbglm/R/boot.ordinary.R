# Ordinary bootstrapping
boot.ordinary <- function (object,
                           nb.resamples = 999,
                           simple = FALSE,
                           parallel = c("no", "multicore", "snow"),
                           ncpus = getOption("boot.ncpus", 1L),
                           cl = NULL) {

  #### Dimensions
  nb.y <- NCOL(object$fit.call$y)
  p <- NCOL(object$fit.call$x)
  #pi <- sum(object$intercepts)
  q <- NCOL(object$fit.call$z)

  #### Original data
  data <- cbind(object$fit.call$y,
                object$fit.call$x,
                object$fit.call$z,
                object$fit.call$weights,
                object$fit.call$sample.weights,
                object$fit.call$offset)

  #### Extract sample MLE
  theta <- c(object$coefficients, object$L.coefs)

  #### Evaluation environment
  local.env <- new.env()

  #### A function to compute the vector of mrbglm coefficients
  statistic.fun <- function (data, index) {
    fit <- eval(call(if (is.function(object$method)) "method" else object$method,
                     y = data[index, 1:nb.y],
                     x = data[index, (nb.y + 1):(nb.y + p), drop = FALSE],
                     z = data[index, (nb.y + p + 1):(nb.y + p + q), drop = FALSE],
                     intercepts = object$intercepts,
                     linkinv = object$fit.call$linkinv,
                     weights = data[index, nb.y + p + q + 1],
                     sample.weights = data[index, nb.y + p + q + 2],
                     start = theta,
                     etastart = NULL, mustart = NULL,
                     offset = data[index, nb.y + p + q + 3],
                     control = object$fit.call$control))
    return(c(fit$coefficients,
             fit$L.coefs))
  }

  #### Call 'boot' to do the job
  boot.object <- boot::boot (data = data,
                             statistic = statistic.fun,
                             R = nb.resamples,
                             sim = "ordinary",
                             stype = 'i',
                             simple = simple,
                             parallel = parallel,
                             ncpus = ncpus,
                             cl = cl)

  colnames(boot.object$t) <- names(theta)

  boot.object$fit <- object
  return(boot.object)
}
