# Parametric bootstrapping
boot.parametric <- function (object,
                             nb.resamples = 999,
                             simple = FALSE,
                             parallel = c("no", "multicore", "snow"),
                             ncpus = getOption("boot.ncpus", 1L),
                             cl = NULL) {

  #### Ensure the ordering of coefficients if object is 'mixed'
  if (identical(object$order.intercepts, "separate"))
    object <- mrb.switch.coef (object)

  #### Dimensions
  nb.y <- NCOL(object$fit.call$y)
  p <- NCOL(object$fit.call$x)
  pi <- sum(object$intercepts)
  q <- object$q

  #### Original data
  data <- cbind(object$fit.call$y,
                object$fit.call$x,
                object$fit.call$z,
                object$fit.call$weights,
                object$fit.call$sample.weights,
                object$fit.call$offset)

  #### A function to extract the matrix for a specific dataset
  get.x <- function(data) {
    data[, (nb.y + 1):(nb.y + p), drop = FALSE]
  }

  #### A function to extract the matrix x for a specific dataset
  get.y <- function(data) {
    data[, 1:nb.y, drop = (nb.y == 1)]
  }

  #### A function to extract the vector/matrix z for a specific dataset
  if (length(object$fit.call$z) == 1) {
    get.z <- function(data) {
      object$fit.call$z
    }
  }
  else if (q == 1) {
    get.z <- function(data) {
      data[, (nb.y + p + 1):(nb.y + p + q), drop = TRUE]
    }
  }
  else {
    get.z <- function(data) {
      data[, (nb.y + p + 1):(nb.y + p + q), drop = FALSE]
    }
  }

  #### A function to extract the vector of weights for a specific dataset
  if (length(object$fit.call$weights) == 1) {
    get.weights <- function(data) {
      object$fit.call$weights
    }
  }
  else {
    get.weights <- function(data) {
      data[,nb.y + p + q + 1, drop = TRUE]
    }
  }

  #### A function to extract the vector of 'sample.weights' for a specific dataset
  if (length(object$fit.call$sample.weights) == 1) {
    get.sample.weights <- function(data) {
      object$fit.call$sample.weights
    }
  }
  else {
    get.sample.weights <- function(data) {
      data[,nb.y + p + q + 2, drop = TRUE]
    }
  }

  #### A function to extract the vector of offset for a specific dataset
  if (length(object$fit.call$offset) == 1) {
    get.offset <- function(data) {
      object$fit.call$offset
    }
  }
  else {
    get.offset <- function(data) {
      data[,nb.y + p + q + 3, drop = TRUE]
    }
  }

  # Extract sample MLE
  theta <- c(object$coefficients, object$L.coefs)

  # Evaluation environment
  local.env <- new.env()

  #### A function to compute the vector of mrbglm coefficients
  statistic.fun.d <- function(data) {
    fit.data <- eval(call(if (is.function(object$method)) "method" else object$method,
                          x = get.x (data),
                          y = get.y (data),
                          z = get.z (data),
                          intercepts = object$intercepts,
                          linkinv = object$fit.call$linkinv,
                          weights = get.weights(data),
                          sample.weights = get.sample.weights(data),
                          start = theta,
                          etastart = NULL, mustart = NULL,
                          offset = get.offset (data),
                          control = object$fit.call$control),
                     envir = local.env)
    return(c(fit.data$coefficients,
             fit.data$L.coefs))
  }

  #### Generate a random sample from the mrbglm model
  ran.gen.fun <- function(data, mle) {
    Sim <- sim.mrb(x = get.x (data),
                   intercepts = object$fit.call$intercepts,
                   beta = mle[1:(p + pi)],
                   weights = get.weights(data),
                   z = get.z (data),
                   delta = mle[-c(1:(p + pi))],
                   maxp.offset = get.offset (data),
                   link = object$link)

    return(cbind(Sim$data,
                 Sim$weights,
                 Sim$offset))
  }

  #### Call 'boot' to do the job
  boot.object <- boot::boot (data = data,
                             statistic = statistic.fun.d,
                             R = nb.resamples,
                             sim = "parametric",
                             ran.gen = ran.gen.fun,
                             mle = theta,
                             parallel = parallel,
                             ncpus = ncpus,
                             cl = cl)

  colnames(boot.object$t) <- names(theta)

  boot.object$fit <- object
  return(boot.object)
}
