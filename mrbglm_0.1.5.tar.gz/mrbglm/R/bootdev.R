
#'
#' @export bootdev.default
#'
bootdev.default <- function(object, ...) {
  mcall <- match.call()
  mcall[[1]] <- quote(bootdev)

  bootdev.mrbglm (object, ..., mcall = mcall)
}

#' Bootstrap the Deviance Statistic of a Model Fit
#'
#' Bootstrapping the null and residual deviances of a model fit object of a
#' class with a \code{bootdev} method, under the null assumption that the
#' response is independent of all included predictors.
#'
#' @param object R object of a class with a \code{bootdev} method.
#'
#' @param ... additional argument to \code{bootdev}. The (default) method for a
#' \code{mrbglm} class object accepts the following arguments:
#'
#' \itemize{
#' \item{\code{R}}{: positive integer giving the number of bootstrap resamples
#' to draw, or \code{NULL} which corresponds to jackknife approximation
#' (see 'Details').}
#' \item{\code{type}}{: character, one of \code{'ordinary'} (usual non-parametric
#' bootstrap based on resampling the original data used to fit the model) or
#' \code{parametric} which resample the response variable from a binomial
#' distribution with a success probability equal to the sample success
#' proportion (holding covariates fixed to their values in the original data
#' used to fit the model).}
#' \item{\code{verbose}}{: integer, should information be printed during the
#' boostrapping procedure? Larger values may give more information.}
#' \item{\code{simple}}{: logical, should resamples (observation indices) be
#' separately drawn for each bootstrap replication? This "is slower but uses
#' less memory" (see \link[boot]{boot}). Defaults to \code{simple = FALSE} which
#' creates an index array once for all resamples. Only used when
#' \code{type = ordinary}.}
#' \item{\code{parallel,ncpus,cl}}{: arguments passed to \link[boot]{boot}, may be
#' specified to allow parallel computations (based on R package \code{parallel}
#' or \code{snow}) which can be faster on multicore plateformes (see
#' \link[boot]{boot}).}
#' }
#'
#' @details
#' The function \code{bootdev} is generic and methods can be written for
#' \code{object}s of a specific class, with particular additional arguments
#' (\code{...}).
#'
#' Only objects of class \code{mrbglm} currently
#' have a method (the default) in the package \code{mrbglm}.
#'
#' The function is intended to provide the basic data for testing the
#' significance of a \code{GLM}-like model fit without assuming the large
#' sample \eqn{\chi^2} approximation for the likelihood ratio statistic,
#' which is the difference between the null deviance and the residual deviance.
#'
#' The function calls \link[boot]{boot} to resample the data under the
#' null model and return both the null and residual deviances. The returned object
#' is of class \code{boot}. A bootstrap approximation can be constructed
#' for the null distribution of the LR statistic to obtain an empirical
#' \code{p-value} for the significance of the model fit.
#'
#' ### Bootstrap a Multiplicative Risk Binomial Regression Model Fit ###
#'
#' The default method performs (for an object of class \code{mbrglm}) ordinary
#' bootstrapping based on \code{R} resamples, each of the same size
#' \code{nobs} of the original dataset.
#'
#' @aliases bootdev.default
#' @export bootdev
#' @exportMethod bootdev
#'
#' @import boot
#' @import methods
#'
#' @return An object of class \code{boot} defined from package
#' \code{boot} (see \link[boot]{boot} for details) with a 3-variate
#' statistic (the \code{$t} component of the output has 3 columns: the
#' likelihood ratio statistic, the null deviance, and the residual deviance).
#'
#' @seealso \link{bootfit} for boostrapping parameter estimates of a fitted model.
#'
#' @examples
#' # Takes about 30 seconds to run
#'
#' # Generate some data
#' set.seed(167)
#' mrbdata = sim.mrb (beta = c(2, -1, 4, -1.5),
#'                    x = cbind(x1 = runif(500, min = -10, max = 5),
#'                              x2 = runif(500, min = -5, max = 10)),
#'                    delta = qlogis(.66))$data
#'
#' # Fit an MRB model
#' mrbfit = glm.mrb (y ~ x1 + x2, data = mrbdata)
#'
#' summary(mrbfit)
#'
#' # Bootstrap the deviance statistics (null and residual)
#' bootmrbdev <- bootdev (mrbfit, R = 999)
#'
#' # Observed likelihood ratio (LR) statistic
#' mrbfit$null.deviance - mrbfit$deviance
#'
#' # Summary of bootstrapped values of LR under the null
#' summary(bootmrbdev$t[,1])
#'
#' # Plot the bootstrap distribution of the likelihood ratio statistic
#' plot(ecdf(bootmrbdev$t[,1]), main = "Empirical CDF")
#'
#' # Add the large sample chi-square distribution
#' plot(ecdf(bootmrbdev$t[,1]), main = "Empirical CDF")
#' curve(pchisq(x, df = 4), 0, 20, add = TRUE, col = 'blue')
#'
#' # A chi-square with df=3 is closer or even df=2.8 ...
# 2.8 close to 2.93 which is the mean of the bootstrapped values of LR
#' curve(pchisq(x, df = 3), 0, 20, add = TRUE, col = 'brown')
#' curve(pchisq(x, df = 2.8), 0, 20, add = TRUE, col = 'red')
#'
#' # P-value
#' sum(bootmrbdev$t[,1] > (mrbfit$null.deviance - mrbfit$deviance)) / 999
#'
#' pchisq(mrbfit$null.deviance - mrbfit$deviance, df = 4,
#'        lower.tail = FALSE)
#'

setGeneric(name = 'bootdev',
           def = bootdev.default)

