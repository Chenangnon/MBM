
# Method for mrbglm class object bootdev.mrbglm
bootdev.mrbglm <- function (object,
                            R = 999,
                            type = "ordinary", simple = FALSE,
                            strata = rep(1, nobs (object)), L = NULL,
                            weights = NULL, verbose = 1L,
                            parallel = c("no", "multicore", "snow"),
                            ncpus = getOption("boot.ncpus", 1L),
                            cl = NULL,
                            mcall) {
  # Build a dataset
  data <- object$fit.call$y

  stopifnot(is.numeric(R))
  R <- max(2, R)
  if (identical(type, 'parametric')) {
    stop("parametric not yet implemented")
  }

  mrb.rand <- function(data, mle) {

    # To be defined to handle parametric bootstrap

  }

  if (verbose) {
    mrbfit_boot <- boot::boot(data = data,
                              statistic = mrb.LRfitter,
                              R = R,
                              mle = coef(object),
                              sim = type[1],
                              stype = "i",
                              ran.gen = mrb.rand,
                              simple = simple,
                              strata = strata, L = L, weights = weights,
                              fit.call = object$fit.call,
                              verbose = max(verbose - 1, 0),
                              parallel = parallel[1],
                              ncpus = ncpus,
                              cl = cl)
  }
  else {
    mrbfit_boot <- catch.conditions({
      boot::boot(data = data,
                 statistic = mrb.LRfitter,
                 R = R,
                 mle = coef(object),
                 sim = type[1],
                 stype = "i",
                 ran.gen = mrb.rand,
                 simple = simple,
                 strata = strata, L = L, weights = weights,
                 fit.call = object$fit.call,
                 verbose = max(verbose - 1, 0),
                 parallel = parallel[1],
                 ncpus = ncpus,
                 cl = cl)
    })$value
  }

  colnames(mrbfit_boot$t) <- names(mrbfit_boot$t0) <- c('LR', 'null.dev', 'deviance')

  mrbfit_boot$call <- mcall

  return(mrbfit_boot)

}

# A fitter routine
mrb.LRfitter <- function (data, indices, fit.call, verbose) {
  data <- data[indices]
  fit.call$y <- data

  if (verbose) {
    new.fit <- eval(fit.call)
  }
  else {
    new.fit <- catch.conditions({
      eval(fit.call)
    })$value
  }

  return(c(LR = new.fit$null.deviance - new.fit$deviance, null.deviance = new.fit$null.deviance, deviance = new.fit$deviance))

}
