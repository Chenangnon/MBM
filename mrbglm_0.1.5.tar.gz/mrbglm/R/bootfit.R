
#'
#' @export bootfit.default
#'
bootfit.default <- function(object, ...) {
  mcall <- match.call()
  mcall[[1]] <- quote(bootfit)

  bootfit.mrbglm (object, ..., mcall = mcall)
}

#' Bootstrap a Model Fit
#'
#' Bootstrapping a model fit object of a class with a \code{bootfit} method.
#'
#' @param object R object of a class with a \code{bootfit} method.
#'
#' @param ... additional argument to \code{bootfit}. The (default) method for a \code{mrbglm} class object accepts the
#' following arguments:
#'
#' \itemize{
#' \item{\code{R}}{: positive integer giving the number of bootstrap resamples
#' to draw, or \code{NULL} which corresponds to jackknife approximation
#' (see 'Details').}
#' \item{\code{type}}{: character, one of \code{'ordinary'} (usual non-parametric
#' bootstrap based on resampling the original data used to fit the model) or
#' \code{parametric} which resample the response variable from a binomial
#' distribution (holding covariates fixed to their values in the original data
#' used to fit the model).}
#' \item{\code{simple}}{: logical, should resamples (observation indices) be
#' separately drawn for each bootstrap replication? This "is slower but uses
#' less memory" (see \link[boot]{boot}). Defaults to \code{simple = FALSE} which
#' creates an index array once for all resamples. Only used when
#' \code{type = ordinary}.}
#' \item{\code{se.fit}}{: logical, should standard errors of estimates be returned
#' for each bootstrap sample? Standard errors are useful to get a Studentized
#' bootstrap confidence interval (see \link[boot]{boot.ci}).}
#' \item{\code{strata,L,weights}}{: Arguments paased to \link[boot]{boot}.}
#' \item{\code{parallel,ncpus,cl}}{: arguments passed to \link[boot]{boot}, may be
#' specified to allow parallel computations (based on R package \code{parallel}
#' or \code{snow}) which can be faster on multicore plateformes (see
#' \link[boot]{boot}).}
#' }
#'
#' @details
#' The function \code{bootfit} is generic and methods can be written for
#' \code{object}s of a specific class, with particular additional arguments
#' (\code{...}).
#'
#' Only objects of class \code{mrbglm} (as returned by \link{glm.mrb}) currently
#' have a method (the default) in the package \code{mrbglm}. Methods will be
#' added for objects of classes \code{glm}/\code{glm.fit} for comparing MRB
#' models (see \link{sim.mrb}) with the common binomial GLM in simulation
#' settings/performance studies.
#'
#' ### Bootstrap a Multiplicative Risk Binomial Regression Model Fit ###
#'
#' The default method performs (for an object of class \code{mbrglm}) ordinary
#' bootstrapping based on \code{R} resamples, each of the same size
#' \code{nobs} of the original dataset. When \code{R} is set to
#' \code{R = NULL}, jackknife estimates are computed: one observation
#' is deleted from the original dateset at a time and the model parameters are
#' estimated using the remaining \code{nobs - 1} observations.
#'
#' @aliases bootfit.mrbglm
#' @export bootfit
#' @exportMethod bootfit
#'
#' @import boot
#' @import methods
#'
#' @return An object of class \code{boot} defined from package
#' \code{boot}. See \link[boot]{boot} for details.
#'
#' @seealso \link{bootdev} for boostrapping deviance to test model significance.
#'
#' @examples
#' # Takes about 30 seconds to run
#'
#' # Generate some data
#' set.seed(167)
#' mrbdata = sim.mrb (beta = c(2, -1, 4, -1.5),
#'                    x = cbind(x1 = runif(500, min = -10, max = 5),
#'                              x2 = runif(500, min = -5, max = 10)),
#'                    delta = qlogis(.66))$data
#'
#' # Fit an MRB model
#' mrbfit = glm.mrb (y ~ x1 + x2, data = mrbdata)
#'
#' summary(mrbfit)
#'
#' # Bootstrap parameter estimates
#' bootmrbfit <- bootfit (mrbfit, R = 999)
#' bootmrbfit
#'
#' # Build bootstrap percentile confidence interval for the slope of 'x1'
#' boot::boot.ci (bootmrbfit, index = 2, conf = 0.95, type = "perc")
#'
#' # Build bootstrap percentile confidence intervals for 'L'
#' # (using the inverse link function to map logit(L) to L)
#' boot::boot.ci (bootmrbfit, index = 5,
#'                conf = 0.95, type = "perc",
#'                h = mrbfit$link$linkinv)

setGeneric(name = 'bootfit',
           def = bootfit.default)

setGeneric(name = "bootfit")

