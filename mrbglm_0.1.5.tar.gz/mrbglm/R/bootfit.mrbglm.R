
#' @exportS3Method bootfit mrbglm

bootfit.mrbglm <- function (object,
                         R = 999,
                         type = "ordinary", simple = FALSE,
                         strata = rep(1, nobs (object)), L = NULL, weights = NULL,
                         se.fit = FALSE, verbose = 1L,
                         parallel = c("no", "multicore", "snow"),
                         ncpus = getOption("boot.ncpus", 1L),
                         cl = NULL, mcall) {
  # Build a dataset
  pweights <- if (any(eval(object$fit.call$weights, envir = object) != 1)) 1 else 0
  psweights <- if (any(eval(object$fit.call$sample.weights, envir = object) != 1)) 1 else 0
  p <- eval(object$p, envir = object)
  if (p == 0)
    stop("no predictor in the supplied 'mrbglm' object")
  p.xof <- if (any(eval(object$fit.call$x.offsets, envir = object) != 0)) NCOL(eval(object$fit.call$x.offsets, envir = object)) else 0

  p.me <-  eval(object$r, envir = object)
  p.meof <- if (any(eval(object$fit.call$me.offsets, envir = object) != 0)) NCOL(eval(object$fit.call$me.offsets, envir = object)) else 0

  p.zminp <- eval(object$qo, envir = object)
  p.minpof <- if (any(eval(object$fit.call$minp.offset, envir = object) != 0)) NCOL(eval(object$fit.call$minp.offset, envir = object)) else 0

  p.zmaxp <- eval(object$q, envir = object)
  p.maxpof <- if (any(eval(object$fit.call$maxp.offset, envir = object) != 0)) NCOL(eval(object$fit.call$maxp.offset, envir = object)) else 0

  data <- as.data.frame(cbind(eval(object$fit.call$y, envir = object),
                              if (pweights) eval(object$fit.call$weights, envir = object),
                              if (psweights) eval(object$fit.call$sample.weights),
                              eval(object$fit.call$x, envir = object),
                              if (p.xof) eval(object$fit.call$x.offsets, envir = object),
                              if (p.me) eval(object$fit.call$zme, envir = object),
                              if (p.meof) eval(object$fit.call$me.offsets, envir = object),
                              if (p.zminp) eval(object$fit.call$zminp, envir = object),
                              if (p.minpof) eval(object$fit.call$minp.offset, envir = object),
                              if (p.zmaxp) eval(object$fit.call$zmaxp, envir = object),
                              if (p.maxpof) eval(object$fit.call$maxp.offset, envir = object)))
  contract_eta <- eval(object$contract_eta, envir = object)

  # Using Jackknife estimates when \code{R = NULL}
  if (is.null(R)) {
    return(jackknife.mrb(data,
                         call = mcall,
                         fit.call = object$fit.call, pweights = pweights,
                         psweights = psweights, p = p, p.xof = p.xof,
                         p.me = p.me, p.meof = p.meof, p.zminp = p.zminp,
                         p.minpof = p.minpof, p.zmaxp = p.zmaxp,
                         p.maxpof = p.maxpof, se.fit = se.fit[1],
                         contract_eta = contract_eta, verbose = verbose))
  }
  stopifnot(is.numeric(R))
  R <- max(2, R)
  if (identical(type, 'parametric')) {
    stop("parametric not yet implemented")
  }

  mrb.rand <- function(data, mle) {

    # To be defined to handle parametric bootstrap

  }

  if (verbose) {
    mrbfit_boot <- boot::boot(data = data,
                              statistic = mrb.fitter,
                              R = R,
                              mle = coef(object),
                              sim = type[1],
                              stype = "i",
                              ran.gen = mrb.rand,
                              simple = simple,
                              strata = strata, L = L, weights = weights,
                              fit.call = object$fit.call, pweights = pweights,
                              psweights = psweights, p = p, p.xof = p.xof,
                              p.me = p.me, p.meof = p.meof, p.zminp = p.zminp,
                              p.minpof = p.minpof, p.zmaxp = p.zmaxp,
                              p.maxpof = p.maxpof, se.fit = se.fit[1],
                              contract_eta = contract_eta,
                              verbose = max(verbose - 1, 0),
                              parallel = parallel[1],
                              ncpus = ncpus,
                              cl = cl)
  }
  else {
    mrbfit_boot <- catch.conditions({
      boot::boot(data = data,
                 statistic = mrb.fitter,
                 R = R,
                 mle = coef(object),
                 sim = type[1],
                 stype = "i",
                 ran.gen = mrb.rand,
                 simple = simple,
                 strata = strata, L = L, weights = weights,
                 fit.call = object$fit.call, pweights = pweights,
                 psweights = psweights, p = p, p.xof = p.xof,
                 p.me = p.me, p.meof = p.meof, p.zminp = p.zminp,
                 p.minpof = p.minpof, p.zmaxp = p.zmaxp,
                 p.maxpof = p.maxpof, se.fit = se.fit[1],
                 contract_eta = contract_eta,
                 verbose = max(verbose - 1, 0),
                 parallel = parallel[1],
                 ncpus = ncpus,
                 cl = cl)
    })$value
  }

  colnames(mrbfit_boot$t) <- names(mrbfit_boot$t0) <- names(coef(object))

  mrbfit_boot$call <- mcall

  return(mrbfit_boot)

}

jackknife.mrb <- function (data, call, fit.call, pweights, psweights, p, p.xof, p.me,
                           p.meof, p.zminp, p.minpof, p.zmaxp, p.maxpof, se.fit,
                           contract_eta, verbose = 0) {
  n <- NROW(data)
  if (verbose) {
    out <- t(sapply(1:n,
                    FUN = function(i) {
                      mrb.fitter (data, indices = -i,
                                  fit.call = fit.call, pweights = pweights,
                                  psweights = psweights, p = p, p.xof = p.xof,
                                  p.me = p.me, p.meof = p.meof, p.zminp = p.zminp,
                                  p.minpof = p.minpof, p.zmaxp = p.zmaxp,
                                  p.maxpof = p.maxpof, se.fit = se.fit,
                                  contract_eta = contract_eta, verbose = max(verbose-1, 0))
                    }))

    t0 <- mrb.fitter(data, 1:n,
                     fit.call = fit.call, pweights = pweights,
                     psweights = psweights, p = p, p.xof = p.xof,
                     p.me = p.me, p.meof = p.meof, p.zminp = p.zminp,
                     p.minpof = p.minpof, p.zmaxp = p.zmaxp,
                     p.maxpof = p.maxpof, se.fit = se.fit,
                     contract_eta = contract_eta, verbose = max(verbose-1, 0))
  }
  else {
    out <- catch.conditions({
      t(sapply(1:n,
               FUN = function(i) {
                 mrb.fitter (data, indices = -i,
                             fit.call = fit.call, pweights = pweights,
                             psweights = psweights, p = p, p.xof = p.xof,
                             p.me = p.me, p.meof = p.meof, p.zminp = p.zminp,
                             p.minpof = p.minpof, p.zmaxp = p.zmaxp,
                             p.maxpof = p.maxpof, se.fit = se.fit,
                             contract_eta = contract_eta, verbose = 0)
               }))
    })$value

    t0 <- catch.conditions({
      mrb.fitter(data, 1:n,
                 fit.call = fit.call, pweights = pweights,
                 psweights = psweights, p = p, p.xof = p.xof,
                 p.me = p.me, p.meof = p.meof, p.zminp = p.zminp,
                 p.minpof = p.minpof, p.zmaxp = p.zmaxp,
                 p.maxpof = p.maxpof, se.fit = se.fit,
                 contract_eta = contract_eta, verbose = 0)
    })$value
  }

  out <- list(t0 = t0,
              t = out,
              R = n,
              data = data,
              seed = .GlobalEnv$.Random.seed,
              statistic = mrb.fitter,
              sim = 'ordinary',
              stype = 'i',
              call = call,
              strata = rep(1,n), L = NULL, weights = NULL)

  colnames(out$t) <- names(t0)

  structure(out, class = 'boot', boot_type = 'boot')

}


# A fitter routine
mrb.fitter <- function (data, indices, fit.call, pweights, psweights, p, p.xof, p.me,
                        p.meof, p.zminp, p.minpof, p.zmaxp, p.maxpof, se.fit, contract_eta,
                        verbose = 0) {
  data <- data[indices,]
  fit.call$y <- data[,1]
  if (pweights)
    fit.call$weights <- data[,2]
  if (psweights)
    fit.call$sample.weights <- data[,pweights+2]

  fit.call$x <- data[,(1+pweights+psweights+1):(1+pweights+psweights+p), drop = FALSE]
  if (p.xof > 0 & any(fit.call$x.offsets != 0))
    fit.call$x.offsets <- data[,(1+pweights+psweights+p+1):(1+pweights+psweights+p+p.xof), drop = FALSE]

  if (p.me > 0 & any(fit.call$zme != 0))
    fit.call$zme <- data[,(1+pweights+psweights+p+p.xof+1):(1+pweights+psweights+p+p.xof+p.me), drop = FALSE]

  if (p.meof > 0 & any(fit.call$me.offsets != 0))
    fit.call$me.offsets <- data[,(1+pweights+psweights+p+p.xof+p.me+1):(1+pweights+psweights+p+p.xof+p.me+p.meof), drop = FALSE]

  if (p.zminp > 0)
    fit.call$zminp <- data[,(1+pweights+psweights+p+p.xof+p.me+p.meof+1):(1+pweights+psweights+p+p.xof+p.me+p.meof+p.zminp), drop = FALSE]
  if (p.minpof > 0 & any(fit.call$minp.offset != 0))
    fit.call$minp.offset <- data[,(1+pweights+psweights+p+p.xof+p.me+p.meof+p.zminp+1):(1+pweights+psweights+p+p.xof+p.me+p.meof+p.zminp+p.minpof), drop = FALSE]

  if (p.zmaxp > 0)
    fit.call$zmaxp <- data[,(1+pweights+psweights+p+p.xof+p.me+p.meof+p.zminp+p.minpof+1):(1+pweights+psweights+p+p.xof+p.me+p.meof+p.zminp+p.minpof+p.zmaxp), drop = FALSE]
  if (p.maxpof > 0 & any(fit.call$maxp.offset != 0))
    fit.call$maxp.offset <- data[,(1+pweights+psweights+p+p.xof+p.me+p.meof+p.zminp+p.minpof+p.zmaxp+1):(1+pweights+psweights+p+p.xof+p.me+p.meof+p.zminp+p.minpof+p.zmaxp+p.maxpof), drop = FALSE]

  if (verbose) {
    new.fit <- eval(fit.call)
  }
  else {
    new.fit <- catch.conditions({
      eval(fit.call)
    })$value
  }

  if (!identical(new.fit$control$order.intercepts, new.fit$order.intercepts)) {
    new.fit$contract_eta <- contract_eta
    new.fit <- mrb.switch.coef (new.fit)
  }

  class(new.fit) <- c("mrbglm", "mrb.fit")

  if (se.fit) {
    if (verbose) {
      sum.fit <- summary(new.fit)
    }
    else {
      sum.fit <- catch.conditions({
        summary(new.fit)
      })$value
    }

    out <- c(sum.fit$coefficients[,1:2])
  }
  else {
    out <- coef(new.fit)
  }

  return(out)

}
