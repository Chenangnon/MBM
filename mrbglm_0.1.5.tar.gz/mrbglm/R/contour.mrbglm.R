#'
#' Contour plots for MRB and MIB Model Fits
#'
#' Draws false color contour plots.
#'
#' @param x an object of class (or inheriting from class) "mrbglm".
#'
#' @param xlim,xlab,zlab a label for the contours.
#'
#' @param panel,default.prepanel See \link[lattice]{contourplot}.
#'
#' @param cuts number of contour levels desired, i.e. the number of levels the
#' range of z would be divided into..
#'
#' @param nlevels number of function evaluation points per covariate.
#'
#' @param labels,contour,pretty,region logicals, see \link[lattice]{contourplot}.
#'
#' @param colorkey A logical flag specifying whether a colorkey is to be drawn
#' alongside the plot, or a list describing the colorkey. See
#' \link[lattice]{contourplot} for a description of the components of a list
#' \code{colorkey}.
#'
#' @param ... Further arguments may be supplied. Passed to \link[lattice]{contourplot}.
#'
#' @details
#' The function is a \link{contour} method for \code{"mrbglm"} and
#' \code{"mibglm"} objects.
#' However, it uses \link[lattice]{contourplot} and not \link{contour}.
#'
#' @aliases contour.mibglm
#' @aliases contour.glm
#'
#' @export contour.mrbglm
#' @export contour.mibglm
#' @export contour.glm
#' @exportS3Method contour mrbglm
#
# @exportS3Method contour mibglm
# @exportS3Method contour glm
#'
#' @importFrom lattice lattice.getOption
#' @importFrom lattice contourplot
#'
#' @return An object of class \code{"trellis"} (returned invisibly).
#' See \link[lattice]{contourplot} for a descripttion.
#'
#' @examples
#' ## Simulate some data
#' library(mrbglm)
#' set.seed(167)
#' mrbdata = sim.mrb (beta = c(-2, -3),
#'                    x = cbind(x1 = runif(1000, min = -5, max = 10),
#'                              x2 = runif(1000, min = -5, max = 10)),
#'                    delta = qnorm(.66))$data[,c("y", "x1", "x2")]
#'
#' head (mrbdata)
#' ## Fit a MRB model with a maximum success probability limit
#' MRBfit1 = glm.mrb (y ~ x1 + x2,
#'                    xlim = c(-2.5, 5),
#'                    data = mrbdata,
#'                    link = 'probit')
#'
#' contour(MRBfit1)
#'
contour.mrbglm <- function (x,
                            xlim = NULL, ylim = NULL, zlim = ylim,
                            xlab = NULL, ylab = NULL,
                            zlab = "Success probability",
                            panel = lattice.getOption("panel.contourplot"),
                            default.prepanel = lattice.getOption("prepanel.default.contourplot"),
                            cuts = 10,
                            nlevels = 200,
                            labels = TRUE,
                            contour = TRUE,
                            pretty = TRUE,
                            region = TRUE,
                            colorkey = list(title = zlab),
                            ...) {

  object <- x; rm(x)

  if (inherits(object, "glm"))
    p <- length(attr(object$terms,"dataClasses")) - 1
  else
    p <- object$p

  if (p != 2)
    stop("'contour.mrbglm' only handles bivariate model fits")

  # Predictor ranges
  if (!length(xlim)) {
    X1val <- with(object$data, eval(object$call$formula[3][[1]][[2]]))
    X2val <- with(object$data, eval(object$call$formula[3][[1]][[3]]))
    x1lim <- range(X1val)
    x2lim <- range(X2val)
  }
  else {
    if (is.list(xlim)) {
      x1lim <- xlim[[1]]
      x2lim <- xlim[[2]]
    }
    else {
      x1lim <- x2lim <- xlim
    }
  }
  stopifnot(is.numeric(x1lim), is.numeric(x2lim),
            length(x1lim) == 2, length(x2lim) == 2)

  # Predictor labels
  if (!length(xlab)) {
    x1lab <- deparse(object$call$formula[3][[1]][[2]])
    x2lab <- deparse(object$call$formula[3][[1]][[3]])
  }
  else {
    if (is.list(xlab)) {
      x1lab <- xlab[[1]]
      if (length(xlab) > 1)
        x2lab <- xlab[[2]]
      else
        x2lab <- x1lab
    }
    else {
      x1lab <- x2lab <- xlab
    }
  }

  # Plot data
  x <- seq(from = x1lim[1], to = x1lim[2], length.out = nlevels)
  y <- seq(from = x2lim[1], to = x2lim[2], length.out = nlevels)

  zclass <- attr(object$zmaxpterms,"dataClasses")
  if (length(zclass)) {

  }

  data <- expand.grid(x=x, y=y)
  colnames(data) <- c(deparse(object$call$formula[3][[1]][[2]]),
                      deparse(object$call$formula[3][[1]][[3]]))
  data$Probability <- predict(object, newdata = data, type = "response")

  plotformula <- paste0("Probability ~ ", deparse(object$call$formula[3][[1]]))
  plotformula <- as.formula(plotformula)

  # Plot
  out <- lattice::contourplot(plotformula, data = data,
                              xlim = x1lim, xlab = x1lab,
                              ylim = x2lim, ylab = x2lab,
                              colorkey = colorkey,
                              cuts = cuts,
                              labels = labels,
                              region = region,
                              contour = contour,
                              pretty = pretty,
                              ...)

  print(out)

  return(invisible(out))
}

contour.glm <- contour.mibglm <- contour.mrbglm
