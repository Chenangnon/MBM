
control.mib <- function (fixLo = FALSE, fixL = FALSE, fixme = FALSE,
                         criterion = "ML", slope.signs = NULL,
                         lower.intercepts = NULL, upper.intercepts = NULL,
                         nbeta.steps = 0, nother.steps = 0,
                         beta.step = .5, other.step = 1, step.degree = 1,
                         method = "BFGS", sequential = TRUE,
                         final.method = "none",
                         epsilon = 1e-08, maxit = 1000,
                         trace = FALSE, cl = NULL,
                         chunk.size = NULL) {

  if (!is.null(slope.signs)) {
    stopifnot(is.character(slope.signs))
    if (!all(slope.signs %in% c("positive", "negative")))
      stop("value of 'slope.signs' must one of 'NULL', 'positive' and negative'")
    slope.signs <- slope.signs[1]
  }

  stopifnot(is.character(criterion))
  if (!all(criterion %in% c("ML", "NLS")))
    stop("value of 'criterion' must one of 'ML' and NLS'")

  stopifnot(is.character(method))
  if (!all(method %in% c("Nelder-Mead", "BFGS", "CG", "L-BFGS-B", "nlm",
                         "nlminb", "lbfgsb3c", "Rcgmin", "Rtnmin", "Rvmmin", "snewton",
                         "snewtonm", "spg", "ucminf", "newuoa", "bobyqa", "nmkb",
                         "hjkb", "hjn", "subplex", "ALL")))
    stop("value of 'method' not recognized (see '?control.mrb' for a list of available methods)")
  if ("ALL" %in% method)
    method <- "ALL"

  sequential <- as.logical(sequential)
  stopifnot(is.logical(sequential))
  sequential <- sequential[1]

  stopifnot(is.character(final.method))
  final.method <- final.method[1]
  if (!all(final.method %in% c("BFGS", "CG", "Nelder-Mead", "L-BFGS-B", "nlm",
                               "nlminb", "lbfgsb3c", "Rcgmin", "Rtnmin", "Rvmmin",
                               "snewton", "snewtonm", "spg", "ucminf", "newuoa",
                               "bobyqa", "nmkb", "hjkb", "hjn", "subplex", "none")))
    stop("value of 'final.method' not recognized (see '?control.mrb' for a list of available methods)")

  rmv <- method %in% final.method
  if (any(rmv)) {
    method <- method[rmv]
  }

  if (!all(c(is.numeric(epsilon), epsilon > 0)))
    stop("value of 'epsilon' must be > 0")
  epsilon <- epsilon[1]

  if (!all(c(is.numeric(maxit), maxit > 0)))
    stop("maximum number of iterations must be > 0")
  maxit <- ceiling(maxit)[1]

  if (!all(c(is.numeric(nbeta.steps), nbeta.steps >= 0, is.numeric(nother.steps), nother.steps >= 0)))
    stop("arguments 'nbeta.steps' and 'nother.steps' must be non negative integers")
  nbeta.steps <- min(ceiling(nbeta.steps)[1], 10)
  nother.steps <- min(ceiling(nother.steps)[1], 10)

  if (!all(c(is.numeric(beta.step), sum(abs(beta.step)) > 0, is.numeric(other.step), sum(abs(other.step)) > 0)))
    stop("arguments 'beta.step' and 'other.step' must be numeric and non-null vectors")

  if (!all(c(is.numeric(step.degree), step.degree > 0)))
    stop("argument 'step.degree' must be a positive integer")
  step.degree <- max(1, min(ceiling(step.degree)[1], 2))

  list(fixLo = fixLo, fixL = fixL, fixme = fixme,
       criterion = criterion, slope.signs = slope.signs,
       lower.intercepts = lower.intercepts, upper.intercepts = upper.intercepts,
       nbeta.steps = nbeta.steps, nother.steps = nother.steps,
       beta.step = beta.step, other.step = other.step, step.degree = step.degree,
       method = method, sequential = sequential, final.method = final.method,
       epsilon = epsilon, maxit = maxit, trace = as.logical(trace)[1],
       cl = cl, chunk.size = chunk.size)
}
