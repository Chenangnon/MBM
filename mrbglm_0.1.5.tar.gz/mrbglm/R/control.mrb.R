#' Auxiliary for Controlling Binomial Model Fitting
#'
#' Auxiliary functions for a binomial model fitting (see e.g. \link{sim.mrb}
#' and \link{sim.mib}).
#' Typically only used internally by \code{\link{fit.mrb}} and \code{\link{fit.mib}},
#' but may be used to construct the control argument for \link{glm.mrb} and
#' \link{glm.mib}.
#'
#' @export control.mrb
#' @export control.mib
#'
#' @aliases control.mib
#'
#' @usage
#'
#' control.mrb (fixLo = FALSE, fixL = FALSE, fixme = FALSE,
#'              criterion = "ML", alternate = FALSE,
#'              penalty = c('ridge', 'lasso', 'logF', 'none'), nobs.power = 1,
#'              penalize.intercepts = TRUE, penalize.delta = FALSE,
#'              L.penalty = c('none', 'linear', 'inv', 'exp'),
#'              int.location = 0, slope.signs = NULL,
#'              lower.intercepts = 'xmin', upper.intercepts = 'xmax',
#'              order.intercepts = "mixed", nbeta.steps = 0, nother.steps = 0,
#'              beta.step = .5, other.step = 1, step.degree = 1,
#'              method = "BFGS", sequential = TRUE,
#'              final.method = "none",
#'              epsilon = 1e-08, maxit = 1000,
#'              trace = FALSE, cl = NULL,
#'              chunk.size = NULL)
#'
#' control.mib (fixLo = FALSE, fixL = FALSE, fixme = FALSE,
#'              criterion = "ML", alternate = FALSE, slope.signs = NULL,
#'              lower.intercepts = 'xmin', upper.intercepts = 'xmax',
#'              nbeta.steps = 0, nother.steps = 0,
#'              beta.step = .5, other.step = 1, step.degree = 1,
#'              method = "BFGS", sequential = TRUE,
#'              final.method = "none",
#'              epsilon = 1e-08, maxit = 1000,
#'              trace = FALSE, cl = NULL,
#'              chunk.size = NULL)
#'
#' @param fixLo,fixL,fixme logical, should the parameters related to the limit
#' probability values (minimum and maximum) and standard deviations of Bergson
#' errors be kept fixed to their initial values? The default values for these
#' arguments (\code{FALSE}) means that each of these parameters is estimated
#' when present in the model. Only \code{fixme = FALSE} is currently available.
#'
#' @param int.location numeric vector, location parameter of the prior distribution
#' on model intercepts. If \code{'NULL'} (the default), it is estimated from the
#' data. See section Details.
#'
#' @param slope.signs character, indicates if the regression slopes in the model
#' should be forced to have a specific sign. One of \code{'NULL'} (the default,
#' no sign forcing), \code{'positive'} or \code{'negative'}.
#'
#' @param criterion character, criterion (i.e. objective function) to be
#' optimized to find the estimates of model parameters. Defaults to 'ML' for
#' Maximum Likelihood estimation. Currently, only the alternative 'NLS' for
#' Nonlinear Least Squares is available.
#'
#' @param alternate logical, should the estimation process be alternated between
#' the estimation of asymptote(s) and the estimation of regression parameters?
#' Defaults to \code{FALSE}. If \code{alternate = TRUE}, a first estimation is
#' proceeded as when \code{alternate = FALSE}, and is then followed by a moment
#' estimation of the asymptote(s), a re-estimation of regression parameters while
#' keeping the asymptote(s) fixed to its last update, and so on. The process is
#' stopped when the asymptote(s) estimate(s) converges or the number of alternating
#' rounds reaches about 10th of \code{maxit} (exactly \code{max(2, ceiling(maxit/10))}).
#'
#' @param penalty character indicating the type of regression coefficient penalty
#' to add to the negative log-likelihood. Defaults to \code{'ridge'} which adds a ridge
#' penalty (sum of squared differences between each penalized parameter and its
#' penalty location which is set to zero for a slope and the covariate median for
#' an intercept) to the log-likelihood.
#' Alternatives include log-likelihood \code{'lasso'} (sum of absolute differences),
#' \code{'logF'} (uses the \code{logF} distribution), \code{'none'} (no penalty
#' added) to the log-likelihood.
#'
#' @param nobs.power numeric, real in \code{(0, 1]}, power of the number of observations \code{n}
#' in the weight of the penalty: \eqn{1/n^{nobs.power}}.
#'
#' @param penalize.intercepts logical, should regression intercepts coefficients be penalized (if any)?
#'
#' @param penalize.delta logical, should the coefficients of the asymptote related coefficients be penalized (if any)?
#'
#' @param L.penalty character indicating the type of asymptote probability penalty to add to the
#' negative log-likelihood.
#'
#' @param order.intercepts a character, one of \code{'mixed'} (default) and
#' \code{'separate'}. The choice \code{'mixed'} means that the vector of
#' coefficients is arranged as \code{beta = [a_1, b_1, a_2, b_2, ..., a_p, b_p]}
#' where \code{a_j} and \code{b_j} are the intercept and the slope for the
#' \code{j}th predictor, and when a predictor is lacking an intercept, the
#' corresponding element is dropped from this expression of \code{beta}.
#' The choice \code{'separate'} means that the vector of coefficients is
#' arranged as \code{beta = [a_1, a_2, ..., a_p, b_1, b_2, ..., b_p]} with
#' elements corresponding to predictors lacking intercepts dropped.
#'
#' @param lower.intercepts,upper.intercepts \code{NULL}, or a numeric vector of
#' length the number of intercepts in the model, or a character indicating
#' lower/upper bounds for the intercepts in the regression model.
#' A \code{NULL} value is interpreted as no bound for any intercept;
#' a numeric vector gives the bounds (must be of the same length as the vector
#' of model intercepts); and
#' a character gives the quantile of observed regression covariates to use as
#' lower or upper bound.
#' For \code{lower.intercepts}, one of the characters \code{'xmin'},
#' \code{'xq0'}, \code{'xq1'}, \code{'xq2.5'}, \code{'xq5'}, and \code{'xq10'};
#' and for \code{upper.intercepts}, one of the characters \code{'xmax'},
#' \code{'xq100'}, \code{'xq99'}, \code{'xq97.5'}, \code{'xq95'}, \code{'xq90'}.
#' The character \code{'xmin'} or \code{'xq0'} (respectively \code{'xmax'} or
#' \code{'xq100'}) indicates that the lower (respectively upper) bounds should
#' be the column minimum (respectively maximum) of the covariate matrix, and the
#' character \code{'xq1'} (respectively \code{'xq99'}) indicates that the lower
#' (respectively upper) bounds should be the column 1% quantile (respectively
#' 99% quantile) of the covariate matrix.
#'
#' @param nbeta.steps,nother.steps integers in the range \code{[0, 10]}, indicating half
#' the number of variations to build for each of the \code{'beta'} and \code{'delta'}
#' components of the initial vector of model parameters (\code{nbeta.steps = 0}
#' and \code{nother.steps = 0} indicate no variation, meaning that only the
#' supplied or the self-initialized starting vector of model parameters will be
#' used). Any value \code{nbeta.steps} or \code{nother.steps} larger than \code{10}
#' is reset to \code{10}. See section '\code{Details}'.
#
# USE ONE "nsteps" for BETA and ONE for "delta"
# Often, we would want nbeta.steps = 0 or 1 and nother.steps = 1 to 3
#'
#' @param beta.step,other.step numeric vectors, used in the definition of a set of
#' additional starting vectors of model parameters. \code{beta.step} (\code{other.step})
#' is not used if \code{nbeta.steps = 0} (\code{nother.steps = 0}).
#' See section '\code{Details}'.
#'
#' @param step.degree positive integer in the range \code{[1, 2]}. Specifies the
#' degree of the combinations of various elements of additional initial vector
#' of model parameters to built. Any value \code{step.degree} larger than
#' \code{2} is reset to \code{step.degree = 2}. Not used if both
#' \code{nbeta.steps = 0} and \code{nother.steps = 0}.
#' See section \code{Details}'.
#'
#' @param method a character (or a vector of characters) indicating the
#' optimizer(s) to consider for the primary search of parameter estimates.
#' Currently, this can be one or many of \code{"Nelder-Mead"} (the default),
#' \code{"CG"}, \code{"BFGS"}, \code{"L-BFGS-B"}, \code{"nlm"}, \code{"nlminb"},
#' \code{"lbfgsb3c"}, \code{"Rcgmin"}, \code{"Rtnmin"}, \code{"Rvmmin"},
#' \code{"snewton"}, \code{"snewtonm"}, \code{"spg"}, \code{"ucminf"},
#' \code{"newuoa"}, \code{"bobyqa"}, \code{"nmkb"}, \code{"hjkb"}, \code{"hjn"},
#' and \code{"subplex"} (see \link[optimx]{opm} for algorithm details).
#' There is an additional pseudo-method \code{"ALL"} (capitalized), which can
#' be used to specify all available and suitable methods, except the
#' \code{final.method}.
#'
#' @param sequential logical, should the methods in \code{method} be attempted
#' sequentially? If \code{TRUE}, the next method is executed starting with the
#' best parameters found so far. Note that, in that case, the final result
#' might depend on the order of methods in \code{method}.
#'
#' @param final.method a character indicating the optimizer to consider for the
#' final search of parameter estimates. After trying all the methods specified
#' in \code{method}, this is used to attempt to refine the parameter estimates.
#' Defaults to \code{"BFGS"}. No refinement is attempted if \code{final.method = "none"}:
#' the result from the \code{method} with the lowest objective function value
#' (e.g. negative log-likelihood, sum of squares of errors) is picked as the best.
#' Note that \code{final.method} cannot be \code{"ALL"}. If \code{final.method}
#' is part of \code{method}, the \code{final.method} is removed from \code{method}.
#'
#' @param epsilon positive convergence tolerance, typically used as relative
#' tolerance (\code{reltol} for \link{optim}).
#'
#' @param maxit The maximum number of iterations. Defaults to \code{500}.
#'
#' @param trace logical indicating if output should be produced for each iteration.
#'
#' @param cl a cluster object, created by the package \code{parallel} or \code{snow}.
#' If not \code{NULL}, and many optimizations are required, they are performed
#' in parallel (if \code{sequential = FALSE}) using the function
#' \link[parallel]{parLapply} of the package \code{parallel}.
#'
#' @param chunk.size positive integer, number of invocations per parallel tasks
#' scheduling (see \link[parallel]{parLapply}).
#'
#' @details This functions are similar to the \link{glm.control} function for fitting
#' \link{glm}'s. The \code{control} argument of \link{glm.mrb} (or \link{glm.mib}) is by default passed
#' to the \code{control} argument of \link{fit.mrb} (or \link{fit.mib}), which uses its elements as
#' arguments to \code{control.mrb} (or \code{control.mib}): the latter provides defaults and
#' sanity checking to some extent (argument \code{cl} and \code{chunk.size} are
#' not checked).
#'
#' The arguments \code{nbeta.steps}, \code{nother.steps}, \code{beta.step},
#' \code{other.step}, and \code{step.degree} are used as follows. Consider a
#' supplied or self-initialized starting parameter vector
#' \code{start} \eqn{= [\beta, \delta]} (\eqn{\beta} elements are regression
#' coefficients and \eqn{\delta} elements are parameters defining the theoretical
#' maximum success probability of the response variable). Additional starting
#' parameters vectors are of the forms
#'
#' \code{newstart} \eqn{= [\beta + beta.step * k_b, \delta + other.step * k_d]}
#'
#' where \eqn{k_b} and \eqn{k_d} are positive integers (from 0 to \code{nsteps}).
#' If \code{step.degree = 1}, then only one of \eqn{k_b} and \eqn{k_d} is positive
#' for an additional vector of starting parameters. If \code{step.degree = 2},
#' then all combinations of \eqn{k_b} and \eqn{k_d} are considered, the case
#' where \eqn{k_b = 0} and \eqn{k_d = 0} corresponding to \code{newstart = start}.
#'
#' Note that the dimensions of \code{beta.step} and \code{other.step} are not
#' checked (and cannot be sanitized) by \code{control.mrb} since these dimensions
#' depend on the specific data set at hand (dimensions of \code{beta} and \code{delta},
#' i.e. numbers of model parameters/covariates). The default behavior sets scalar
#' values (\code{beta.step = 0.5} and \code{other.step = 1}) to ensure no dimension
#' compatibility issue during model fitting.
#'
#' @return A list with components named as the arguments.
#'

# Lasso usually only penalize slopes, not intercept
# So it make sens here to not penalize lambda and alpha
# But should we also penalize intercepts going with each predictor?
# YES? Why?
control.mrb <- function (fixLo = FALSE, fixL = FALSE, fixme = FALSE,
                         criterion = "ML", alternate = FALSE,
                         penalty = c('ridge', 'lasso', 'logF', 'none'), nobs.power = 1,
                         penalize.intercepts = TRUE, penalize.delta = FALSE,
                         L.penalty = c('none', 'linear', 'inv', 'exp'),
                         int.location = 0, slope.signs = NULL,
                         lower.intercepts = 'xmin', upper.intercepts = 'xmax',
                         order.intercepts = "mixed", nbeta.steps = 0, nother.steps = 0,
                         beta.step = .5, other.step = 1, step.degree = 1,
                         method = "BFGS", sequential = TRUE,
                         final.method = "none",
                         epsilon = 1e-08, maxit = 1000,
                         trace = FALSE, cl = NULL,
                         chunk.size = NULL) {

  if (!is.null(slope.signs)) {
    stopifnot(is.character(slope.signs))
    if (!all(slope.signs %in% c("positive", "negative")))
      stop("value of 'slope.signs' must one of 'NULL', 'positive' and negative'")
    slope.signs <- slope.signs[1]
  }

  stopifnot(is.character(criterion))
  if (!all(criterion %in% c("ML", "NLS")))
    stop("value of 'criterion' must one of 'ML' and NLS'")

  alternate <- as.logical(alternate)
  stopifnot(is.logical(alternate))
  alternate <- alternate[1]

  if (!is.null(penalty)) {
    stopifnot(is.character(penalty))
    penalty <- tolower(penalty)
    if (!all(penalty %in% c('logf', 'lasso', 'ridge', 'none')))
      stop("value of 'penalty' must one of 'logF', 'lasso', ridge' and 'none'")
    penalty <- penalty[1]
  }
  else {
    penalty = 'none'
  }

  if (!is.null(L.penalty)) {
    stopifnot(is.character(L.penalty))
    L.penalty <- tolower(L.penalty)
    if (!all(L.penalty %in% c('linear', 'exp', 'inv', 'none')))
      stop("value of 'L.penalty' must one of 'linear', 'exp', inv' and 'none'")
    L.penalty <- L.penalty[1]
  }
  else {
    L.penalty = 'none'
  }


  stopifnot(is.numeric(nobs.power))
  #stopifnot(nobs.power > 0, nobs.power <= 1)
  penalize.intercepts <- as.logical(penalize.intercepts)
  penalize.delta <- as.logical(penalize.delta)
  stopifnot(is.character(method))
  if (!all(method %in% c("Nelder-Mead", "BFGS", "CG", "L-BFGS-B", "nlm",
                      "nlminb", "lbfgsb3c", "Rcgmin", "Rtnmin", "Rvmmin", "snewton",
                      "snewtonm", "spg", "ucminf", "newuoa", "bobyqa", "nmkb",
                      "hjkb", "hjn", "subplex", "ALL")))
    stop("value of 'method' not recognized (see '?control.mrb' for a list of available methods)")
  if ("ALL" %in% method)
    method <- "ALL"

  sequential <- as.logical(sequential)
  stopifnot(is.logical(sequential))
  sequential <- sequential[1]

  stopifnot(is.character(final.method))
  final.method <- final.method[1]
  if (!all(final.method %in% c("BFGS", "CG", "Nelder-Mead", "L-BFGS-B", "nlm",
                         "nlminb", "lbfgsb3c", "Rcgmin", "Rtnmin", "Rvmmin",
                         "snewton", "snewtonm", "spg", "ucminf", "newuoa",
                         "bobyqa", "nmkb", "hjkb", "hjn", "subplex", "none")))
    stop("value of 'final.method' not recognized (see '?control.mrb' for a list of available methods)")

  rmv <- method %in% final.method
  if (any(rmv)) {
    method <- method[rmv]
  }

  if (!any(c(is.null(lower.intercepts),
             identical(lower.intercepts, 'xmin'),
             identical(lower.intercepts, 'xq0'),
             identical(lower.intercepts, 'xq1'),
             identical(lower.intercepts, 'xq2.5'),
             identical(lower.intercepts, 'xq5'),
             identical(lower.intercepts, 'xq10'),
             identical(lower.intercepts, 'xq15'),
             identical(lower.intercepts, 'xq20'),
             identical(lower.intercepts, 'xq25'),
             is.numeric(lower.intercepts)))) {
    stop("'lower.intercepts' must be NULL, 'xq25', 'xq20', 'xq15', 'xq10', 'xq5', 'xq2.5', 'xq1', 'xq0', or 'xmin', or a numeric vector")
  }

  if (!any(c(is.null(upper.intercepts),
             identical(upper.intercepts, 'xmax'),
             identical(upper.intercepts, 'xq100'),
             identical(upper.intercepts, 'xq99'),
             identical(upper.intercepts, 'xq97.5'),
             identical(upper.intercepts, 'xq95'),
             identical(upper.intercepts, 'xq90'),
             identical(upper.intercepts, 'xq85'),
             identical(upper.intercepts, 'xq80'),
             identical(upper.intercepts, 'xq75'),
             is.numeric(upper.intercepts)))) {
    stop("'upper.intercepts' must be NULL, 'xq75', 'xq80', 'xq85', 'xq90', 'xq95', 'xq97.5', 'xq99', 'xq100', or 'xmax', or a numeric vector")
  } # NOW GO TO the FITTING FUNCTIONS TO USE THE NEWLY ADDED OPTIONS

  if (!all(c(is.numeric(epsilon), epsilon > 0)))
    stop("value of 'epsilon' must be > 0")
  epsilon <- epsilon[1]

  if (!all(c(is.numeric(maxit), maxit > 0)))
    stop("maximum number of iterations must be > 0")
  maxit <- ceiling(maxit)[1]

  if (!all(c(is.numeric(nbeta.steps), nbeta.steps >= 0, is.numeric(nother.steps), nother.steps >= 0)))
    stop("arguments 'nbeta.steps' and 'nother.steps' must be non negative integers")
  nbeta.steps <- min(ceiling(nbeta.steps)[1], 10)
  nother.steps <- min(ceiling(nother.steps)[1], 10)

  if (!all(c(is.numeric(beta.step), sum(abs(beta.step)) > 0, is.numeric(other.step), sum(abs(other.step)) > 0)))
    stop("arguments 'beta.step' and 'other.step' must be numeric and non-null vectors")

  if (!all(c(is.numeric(step.degree), step.degree > 0)))
    stop("argument 'step.degree' must be a positive integer")
  step.degree <- max(1, min(ceiling(step.degree)[1], 2))

  list(fixLo = fixLo, fixL = fixL, fixme = fixme,
       criterion = criterion, alternate = alternate,
       penalty = penalty, nobs.power = nobs.power,
       penalize.intercepts = penalize.intercepts,
       penalize.delta = penalize.delta,
       L.penalty = L.penalty,
       int.location = int.location,
       slope.signs = slope.signs,
       lower.intercepts = lower.intercepts,
       upper.intercepts = upper.intercepts,
       order.intercepts = order.intercepts[1],
       nbeta.steps = nbeta.steps, nother.steps = nother.steps,
       beta.step = beta.step, other.step = other.step, step.degree = step.degree,
       method = method, sequential = sequential, final.method = final.method,
       epsilon = epsilon, maxit = maxit, trace = as.logical(trace)[1],
       cl = cl, chunk.size = chunk.size)
}
