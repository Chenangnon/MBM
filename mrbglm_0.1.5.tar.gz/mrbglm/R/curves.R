#' Draw Model Plots
#'
#' Draws a curve corresponding to a function over the interval \code{[from, to]}.
#'
#' @param object R object of a class with a \code{curve} method.
#'
#' @param ... additional argument to \code{curve}. The (default) method for a \code{mrbglm} class object is
#' \code{curve.mrb} (see \link{curves.mrb} for arguments).
#'
#' @details
#' The function \code{curves} is generic and methods can be written for
#' \code{object}s of a specific class, with particular additional arguments
#' (\code{...}).
#'
#' The default method is \link[graphics]{curve}.
#' Only objects of class \code{mrbglm} (as returned by \link{glm.mrb}) currently
#' have a method (the default) in the package \code{mrbglm}.
#'
#' @export curves
#' @exportMethod curves
#'
#' @import graphics
#'
#' @return A list with components \code{x} and \code{y} of the points
#' that were drawn is returned invisibly.
#'
#

curves <- function(object, ...) {
  if (inherits(object, "mibglm") | inherits(object, "mib.fit"))
    curves.mibglm (object, ...)
  else
    curves.mrbglm (object, ...)
}

setGeneric(name = "curves")
