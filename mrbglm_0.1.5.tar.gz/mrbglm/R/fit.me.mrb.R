
# If mestart is given and zme = NULL, then me.offsets is not used at all

# mrb fit when Bergeson error variance is available
fit.me.mrb <- function (y, weights = 1, sample.weights = 1,
                        x, contract_eta, intercepts = TRUE, x.offsets = 0,
                        x.with.me = NULL, zme = NULL, pred.with.me = NULL,
                        me.intercepts = FALSE,
                        me.offsets = 0,
                        zminp = NULL, minp.offset = 0,
                        zmaxp = 1, maxp.offset = 0,
                        link = logit(), start = NULL,
                        mustart = NULL, etastart = NULL, # Arguments passed to glm.fit for initialization
                        mestart = NULL, gammastart = NULL,
                        Lostart = NULL, deltaostart = NULL,
                        Lstart = NULL, deltastart = NULL,
                        control = list(), ...) {
  ### Save the call
  fit.call <- match.call()

  ### Link function
  linkfun <- link$linkfun
  linkinv <- link$linkinv
  melinkinv <- link$melinkinv

  ### Dimensions and weights
  eval(memrb.dim())
  pi <- sum(intercepts)

  ### Initialization
  eval(initialize.me.mrb.fit())

  ### Negative log-likelihood function
  eval(make.me.mrb.nlikefun())

  ### Optimization
  #nparams <- p + pi + qo * (!control$fixLo) + q * (!control$fixL) + (r+ri) * (r > 0)
  theta0 <- start
  start <- c(theta0[1:(p + pi)],
             if (qo > 0 & !control$fixLo) theta0[(p + pi + 1):(p + pi + qo)],
             if (q > 0 & !control$fixL) theta0[(p + pi + qo + 1):(p + pi + qo + q)],
             if ((r+ri > 0 ) & !control$fixme) theta0[(p + pi + qo + q + 1):(p + pi + qo + q + r +ri)])
  nparams <- length(start)

  ### Bounds if required
  boundaries <- !is.null(control$slope.signs) | !is.null(control$lower.intercepts) | !is.null(control$upper.intercepts)
  if (boundaries) {

    # Slope bounds
    if (!is.null(control$slope.signs)) {
      if (identical(control$slope.signs, "positive")) {
        start[(pi + 1):(pi + p)] <- pmax(1e-10, start[(pi + 1):(pi + p)])
        lowerb <- rep(-Inf, nparams)
        lowerb[(pi + 1):(pi + p)] <- 0
        upperb <- Inf
      }
      else {
        start[(pi + 1):(pi + p)] <- pmin(-1e-10, start[(pi + 1):(pi + p)])
        lowerb <- -Inf
        upperb <- rep(Inf, nparams)
        upperb[(pi + 1):(pi + p)] <- 0
      }
    }
    else {
      lowerb = -Inf
      upperb = Inf
    }

    # Lower intercept bounds
    if (!is.null(control$lower.intercepts)) {
      if (length(lowerb) == 1) {
        lowerb <- rep(-Inf, nparams)
      }

      if (is.character(control$lower.intercepts)) {
        if (identical(control$lower.intercepts, 'xmin') | identical(control$lower.intercepts, 'xq0'))
          lowerb[1:pi] <- apply(rbind(X)[intercepts, , drop = FALSE], MARGIN = 1, FUN = min)
        else if (control$lower.intercepts %in% c('xq25', 'xq20', 'xq15', 'xq10', 'xq5', 'xq2.5', 'xq1')) {
          lowerbnum <- as.numeric(strsplit (control$lower.intercepts, split = "xq", fixed = TRUE)[[1]][2])
          lowerbnum <- lowerbnum / 100
          lowerb[1:pi] <- apply(rbind(X)[intercepts, , drop = FALSE], MARGIN = 1, FUN = function(x) quantile(x, probs = lowerbnum))
        }
      }
      else if (is.numeric(control$lower.intercepts)) {
        if (length(control$lower.intercepts) != pi) {
          stop(paste0("the length of a numeric 'control$lower.intercepts' must ",
                      "be the number of intercepts in the model (", pi, ")"))
        }
        lowerb[1:pi] <- control$lower.intercepts
      }
      else {
        stop("'control$lower.intercepts' must be NULL, 'xq25', 'xq20', 'xq15', 'xq10', 'xq5', 'xq2.5', 'xq1', 'xq0', or 'xmin', or a numeric vector")
      }
    }

    # Upper intercept bounds
    if (!is.null(control$upper.intercepts)) {
      if (length(upperb) == 1) {
        upperb <- rep(Inf, nparams)
      }

      if (is.character(control$upper.intercepts)) {
        if (identical(control$upper.intercepts, 'xmax') | identical(control$upper.intercepts, 'xq100'))
          upperb[1:pi] <- apply(rbind(X)[intercepts, , drop = FALSE], MARGIN = 1, FUN = max)
        else if (control$upper.intercepts %in% c('xq75', 'xq80', 'xq85', 'xq90', 'xq95', 'xq97.5', 'xq99')) {
          upperbnum <- as.numeric(strsplit (control$upper.intercepts, split = "xq", fixed = TRUE)[[1]][2])
          upperbnum <- upperbnum / 100
          upperb[1:pi] <- apply(rbind(X)[intercepts, , drop = FALSE], MARGIN = 1, FUN = function(x) quantile(x, probs = upperbnum))
        }
      }
      else if (is.numeric(control$upper.intercepts)) {
        if (length(control$upper.intercepts) != pi) {
          stop(paste0("the length of a numeric 'control$upper.intercepts' must ",
                      "be the number of intercepts in the model (", pi, ")"))
        }
        upperb[1:pi] <- control$upper.intercepts
      }
      else {
        stop("'control$upper.intercepts' must be NULL, 'xq75', 'xq80', 'xq85', 'xq90', 'xq95', 'xq97.5', 'xq99', 'xq100', or 'xmax', or a numeric vector")
      }
    }

    # Adjust 'start'
    if (any(lowerb >= upperb)) {
      cat("\n")
      print(rbind(LB = lowerb, UB = upperb))
      cat("\n")
      stop('inconsistent parameter bounds found:')
    }
    start <- pmax(start, lowerb)
    start <- pmin(start, upperb)

  }
  else {
    lowerb = -Inf
    upperb = Inf
  }

  vmethods <- c("Nelder-Mead", "BFGS", "CG", "L-BFGS-B", "SANN", "Brent")
  vmethod <- control$method %in% vmethods
  optres0 <- NULL

  if (length(control$method) > 1 | any(!vmethod)) {

    optres0 <- optim.mrb (start = start,
                          nb.betas = pi + p,
                          nlikefun = nlikefun,
                          control = control,
                          lower = lowerb,
                          upper = upperb)

    optres <- optres0$finalresult
    control$method <- unique(c(control$final.method, control$method))
    vmethod <- control$method %in% vmethods

    if (any(vmethod)) {
      control$method <- control$method[vmethod][1]
    }
    else
      control$method <- "Nelder-Mead"
  }
  else {

    optres <- catch.conditions({
      stats::optim(par = start, fn = nlikefun,
                   method = control$method,
                   control = list(maxit = control$maxit,
                                  reltol = control$epsilon),
                   lower = lowerb,
                   upper = upperb,
                   hessian = TRUE)
    })$value
  }

#  browser()

  pbeta <- pi + p
  if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
    optres <- catch.conditions({
      stats::optim(par = start, fn = nlikefun,
                   method = 'Nelder-Mead',
                   control = list(maxit = 3 * control$maxit,
                                  reltol = control$epsilon))
    })$value
    if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
      if (!control$fixL) {
        start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(deltastart + 1, q)
        optres <- catch.conditions({
          stats::optim(par = start, fn = nlikefun,
                       method = control$method,
                       control = list(maxit = control$maxit,
                                      reltol = control$epsilon),
                       hessian = TRUE)
        })$value

        if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
          start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(deltastart + 2, q)
          optres <- catch.conditions({
            stats::optim(par = start, fn = nlikefun,
                         method = control$method,
                         control = list(maxit = control$maxit,
                                        reltol = control$epsilon),
                         hessian = TRUE)
          })$value
        }

        if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
          start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(-1, q)
          optres <- catch.conditions({
            stats::optim(par = start, fn = nlikefun,
                         method = control$method,
                         control = list(maxit = control$maxit,
                                        reltol = control$epsilon),
                         hessian = TRUE)
          })$value
        }

        if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
          start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(-2, q)
          optres <- catch.conditions({
            stats::optim(par = start, fn = nlikefun,
                         method = control$method,
                         control = list(maxit = control$maxit,
                                        reltol = control$epsilon),
                         hessian = TRUE)
          })$value
        }
      }

      if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
        stop(paste0("fitting failled: ",
                    optres,
                    ". Try another optimizer (see '?control.mrb')"))
      }
    }
    else {
      optres <- catch.conditions({
        stats::optim(par = optres$par, fn = nlikefun,
                     method = control$method,
                     control = list(maxit = control$maxit,
                                    reltol = control$epsilon),
                     hessian = TRUE)
      })$value
    }
  }
  else if (any(colSums(optres$hessian[1:pbeta, 1:pbeta] == 0) == pbeta) & !control$fixL) {
    start1 <- start
    start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart + 1
    optres1 <- catch.conditions({
      stats::optim(par = start1, fn = nlikefun,
                   method = control$method,
                   control = list(maxit = control$maxit,
                                  reltol = control$epsilon),
                   lower = lowerb,
                   upper = upperb,
                   hessian = TRUE)
    })$value
    if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
      invalid1 <- TRUE
    }
    else {
      invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
      if (invalid1) {
        start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart + 2
        optres1 <- catch.conditions({
          stats::optim(par = start1, fn = nlikefun,
                       method = control$method,
                       control = list(maxit = control$maxit,
                                      reltol = control$epsilon),
                       lower = lowerb,
                       upper = upperb,
                       hessian = TRUE)
        })$value
        if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
          invalid1 <- TRUE
        }
        else {
          invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
        }
      }
    }
    if (invalid1) {
      start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart - 1
      optres1 <- catch.conditions({
        stats::optim(par = start1, fn = nlikefun,
                     method = control$method,
                     control = list(maxit = control$maxit,
                                    reltol = control$epsilon),
                     lower = lowerb,
                     upper = upperb,
                     hessian = TRUE)
      })$value
      if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
        invalid1 <- TRUE
      }
      else {
        invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
        if (invalid1) {
          start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart - 2
          optres1 <- catch.conditions({
            stats::optim(par = start1, fn = nlikefun,
                         method = control$method,
                         control = list(maxit = control$maxit,
                                        reltol = control$epsilon),
                         lower = lowerb,
                         upper = upperb,
                         hessian = TRUE)
          })$value
          if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
            invalid1 <- TRUE
          }
          else {
            invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
          }
        }
      }
    }
    if (!invalid1) {
      optres <- optres1
    }
  }

  if (!is.null(optres0)) {
    optres0$finalresult <- optres
    optres$details <- optres0
  }

  iter <- optres$counts
  converged <- optres$convergence == 0
  if (length(optres$convergence) == 0) {
    optres$convergence <- NA
    converged <- FALSE
    attr(converged, 'code') <- NA
  }
  else
    attr(converged, 'code') <- conv.optim(optres$convergence)
  attr(converged, 'message') <- optres$message

  # Extracting basic results
  theta <- optres$par
  mulist <- theta2mu (theta)
  beta.int <- mulist$beta.int
  beta.x <- mulist$beta
  beta <- c(beta.int, beta.x)
  eta <- mulist$eta
  if (!control$fixLo)
    deltao <- mulist$deltao
  if (!control$fixL)
    delta <- mulist$delta
  Lovalues <- mulist$Lovalues
  logLvalues <- mulist$logLvalues
  sdmat <- mulist$sdmat
  mu <- mulist$mu
  validmu <- mulist$validmu
  if (!control$fixme) {
    ptout <- pbeta + qo * (!control$fixLo) + q * (!control$fixL)
    gamma.int <- if (ri > 0) theta[(ptout + 1):(ptout + ri)]
    gamma <- if (r > 0) theta[(ptout + ri + 1):(ptout + ri + r)]
  }

  ### Degrees of freedom
  df.residual <- ssize - nparams
  df.null <- ssize - 1
  if (!all(validmu) & length(weights) > 1)
    weights <- weights[validmu]
  if (identical(control$criterion, "NLS")) {
    dispersion <- sum((y[validmu] - mu[validmu])^2) / df.residual
  }
  else {
    dispersion <- 1
  }

  # Residual deviance and information criteria
  residual.deviance <- 2 * halfdev_i (mulist)
  deviance <- sum(residual.deviance[validmu])
  logLike <- - .5 * deviance
  aic <- deviance + 2 * nparams
  bic <- deviance + log(ssize) * nparams

  ### Covariance matrix estimate
  hessian <- optres$hessian
  Rmat <- catch.conditions(solve(optres$hessian))$value
  if (any(class(Rmat) %in% c("simpleError", "error", "condition", "try-error"))) {
    if (all(optres$hessian == 0))
      warning("algorithm did not converge: over-parameterized model -- no covariance matrix estimate available")
    else if (any(colSums(abs(optres$hessian[1:pbeta, 1:pbeta])) == 0))
      warning("algorithm did not converge: no covariance matrix estimate available")
    else {
      Rmato <- catch.conditions(solve(optres$hessian[1:pbeta, 1:pbeta]))$value
      if (any(class(Rmato) %in% c("simpleError", "error", "condition", "try-error"))) {
        warning("algorithm did not converge: no covariance matrix estimate available")
      }
      else {
        Rmat <- matrix(0, nrow = nparams, ncol = nparams)
        Rmat[1:pbeta, 1:pbeta] <- Rmato
        warning("over-parameterized model? -- 0 or NA in covariance matrix estimate")
        Rmat <- Rmat * dispersion
        dimnames(Rmat) <- list(names(start), names(start))
      }
    }
  }
  else {
    Rmat <- Rmat * dispersion
    dimnames(Rmat) <- list(names(start), names(start))
  }

  ### Computing the null deviance (account for the criterion)
  nlike.null.mrb <- function(beta0) {
    mu <- exp(linkinv(beta0, log.p = TRUE))
    res <- ddistrlog (y = y, mu = rep(mu, length(y)), validmu = rep(TRUE, length(y)), weights = weights)

    if (!all(validsweights) & length(sample.weights) > 1) {
      sample.weights <- sample.weights[validsweights]
      res <- res[validsweights]
    }

    -sum(res * sample.weights, na.rm = TRUE)
  }

  null.method <- control$method
  if (!(null.method %in% c("Nelder-Mead", "BFGS", "CG", "L-BFGS-B", "SANN", "Brent")))
    null.method <- "Nelder-Mead"

  null.deviance <- catch.conditions({
    stats::optim(par = linkfun (mean(y/weights, na.rm = TRUE)),
                 fn = nlike.null.mrb,
                 method = null.method,
                 control = list(maxit = control$maxit,
                                reltol = control$epsilon))
  })
  if (any(class(null.deviance$value) %in% c("simpleError", "error", "condition", "try-error"))) {
    warning(paste0("fitting to compute the null deviance failled: ",
                   null.deviance$value))
    null.deviance <- NA
    beta0 <- NA
  }
  else {
    beta0 <- null.deviance$value$par
    null.deviance <- 2 * null.deviance$value$value
  }

  # Names Lovalues, Lvalues
  if (!is.null(zminp)) {
    if(is.null(zonames <- names(zminp))) {
      if ((zolen <- length(zminp)) == 1) {
        names(Lovalues) <- "Lo"
      }
      else {
        if (is.matrix(zminp))
          names(Lovalues) <- paste0("Lo", 1:NCOL(zminp))
        else
          names(Lovalues) <- paste0("Lo", 1:zolen)
      }
    }
    else {
      names(Lovalues) <- zonames
    }
  }
  else if (length(Lovalues) == 1) {
    names(Lovalues) <- "Lo"
  }
  L.values <- exp(logLvalues)
  if (!is.null(zmaxp)) {
    if(is.null(znames <- names(zmaxp))) {
      if ((zlen <- length(zmaxp)) == 1) {
        names(L.values) <- "L"
      }
      else {
        if (is.matrix(zmaxp))
          names(L.values) <- paste0("L", 1:NCOL(zmaxp))
        else
          names(L.values) <- paste0("L", 1:zlen)
      }
    }
    else {
      names(L.values) <- znames
    }
  }
  else if (length(L.values) == 1) {
    names(L.values) <- "L"
  }

  # Save some design matrices
  fit.call$x.offsets <- x.offsets
  fit.call$me.offsets <- me.offsets
  fit.call$minp.offset <- minp.offset
  fit.call$maxp.offset <- maxp.offset
  fit.call$zmaxp <- zmaxp
  fit.call$zminp <- zminp

  sdmat <- t(sdmat)
  rownames(sdmat) <- rownames(x)
  sdmat <- sdmat[,pred.with.me, drop = FALSE]

  structure(list(coefficients = beta,
                 Lo.coefs = deltao,
                 L.coefs = delta,
                 me.coefs = if (!control$fixme) c(gamma.int, gamma),
                 mu = mu,
                 fitted.values = mu * weights,
                 Lo.values = Lovalues,
                 L.values = L.values,
                 me.mat = sdmat, x.with.me = x.with.me,
                 beta.with.me = beta.with.me, pred.with.me = pred.with.me,
                 logLike = logLike, aic = aic, bic = bic,
                 deviance = deviance, null.deviance = null.deviance,
                 residual.deviance = residual.deviance,
                 df.residual = df.residual, df.null = df.null,
                 nobs = nobs, p = p, qo = qo, q = q, r = r, rank = nparams, ssize = ssize,
                 weights = prior.weights, sample.weights = sample.weights,
                 intercepts = intercepts, order.intercepts = "separate",
                 me.intercepts = me.intercepts, Rmat = Rmat, dispersion = dispersion,
                 hessian = hessian, start = theta0,
                 link = link, linkinv = linkinv, melinkinv = melinkinv,
                 fit.call = fit.call, control = control,
                 converged = converged, iter = iter, optres = optres,
                 nlikefun = nlikefun),
            class = c('mrb.fit', 'memrb.fit'))
}
