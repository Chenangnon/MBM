#' Fit a Multiplicative Risk Binomial Regression Model
#'
#' Add an argument to specify the sign of each slope
#'
#' USE A GRID SEARCH on \eqn{delta} a PRE-SPECIFIED INTERVAL \eqn{I = [a, b]} TO
#' FIND \eqn{\hat{delta}} (supply each grid value as an initial value)
#'
#'
#' The function \code{fit.mrb} is the workhorse for \link{glm.mrb}.
#' Not a user level routine, but should be used instead of \link{glm.mrb}
#' in a simulation framework where \code{fit.mrb} can reduce computation time.
#'
#' @param y a vector of observations of length \code{n}.
#'
#' @param x a design matrix of dimension \eqn{n * p}, covariates determining
#'  each a probability to observe \code{y = 1}. The overall probability is the
#'  product of all such probabilities, and a multiplicative intercept determined
#'  by \code{zmaxp}.
#'
#' @param contract_eta numeric vector,
#'
#' @param weights an optional numeric vector of 'sizes' giving the number of
#' trials which resulted in the number of success in each entry of \code{y}.
#' Defaults to \code{1} which is interpreted as a vector of all ones.
#'
#' @param sample.weights an optional numeric vector giving the weights of each
#' observation (row) in the data to be used for fitting. See argument definition
#' and the section 'Details' of \link{glm.mrb} for details.
#'
#' @param intercepts logical vector, should an intercept be included for each predictor?
#' A unique value is interpreted as the same for all terms that can have an
#' individual intercept (see 'Details' in \link{glm.mrb}).
#'
#' @param zminp design matrix of dimension \eqn{n * qo} that determines the
#' minimum success probability for responses in \code{y}.
#'
#' @param zmaxp a design matrix of dimension \eqn{n * q} that determines the
#' multiplicative intercept, the maximum probability of success for \code{y}.
#'
#' @param zme a design matrix of dimension \eqn{n * r} that determines the
#' standard deviation of the normal mixing distribution (i.e. for Bergson
#' measurement errors).
#'
#' @param minp.offset,maxp.offset,me.offsets numeric vectors of offsets for the linear
#' predictor corresponding to \code{zminp}, \code{zmaxp}, and \code{zme}.
#' See \link{glm} for a description of what is an \code{maxp.offset}.
#'
#' @param link an object of class \code{link}, giving details of the link
#' function to be used for the fit.
#'
# @param linkfun,linkinv function, the mapping (inverse link function) from each linear
# predictor to the corresponding probability, and vise-versa (link function).
#'
#' @param start a numeric \code{p}-vector of starting values for the
#' coefficients of variables in \code{x}; or a \code{p+q}-vector of starting
#' values for the coefficients of variables in \code{x} and \code{zmaxp}. There can
#' also be starting values for individual intercepts for variables in \code{x}, if any.
#'
#' @param mustart,etastart arguments passed to \link{glm.fit} for initialization
#' when \code{start} is missing or \code{NULL}. See \link{glm.fit} for a
#' description. Ignored when \code{start} is not missing and not \code{NULL}.
#'
#' @param Lostart,deltaostart numeric vectors, \code{Lostart} contains starting values
#' for minimum probability values divided by the maximum. \code{deltaostart} contains the
#' coefficients of variables in \code{zminp}. Ignored if these are already
#' available in \code{start}.
#'
#' @param Lstart,deltastart numeric vectors, \code{Lostart} contains starting values
#' for minimum probability values. \code{deltastart} contains the
#' coefficients of variables in \code{zmaxp}. Ignored if these are already
#' available in \code{start}.
#'
#' @param mestart,gammastart numeric vectors, \code{mestart} contains starting
#' values of the standard deviation of the normal mixing (measurement error)
#' distribution. \code{gammastart} contains starting values of the coefficients
#' of variables in \code{zme}.
#'
#' @param me.intercepts logical vector, should an intercept be included for each
#' term in \code{me.formula}? A unique value is interpreted as the same for all
#' terms in \code{me.formula}.
#'
#' @param x.with.me logical vector, indicating numerical predictors with
#' measurement error terms. The number of \code{TRUE} values in \code{x.with.me}
#' must match the number of measurement error terms in \code{me.formula}.
#'
#' @param x.offsets an optional one sided \link{formula} object specifying
#' columns in \code{data} (or in the environment from which \code{glm.mrb} is
#' called) to be used as offsets for numerical predictors in \code{formula}. An
#' offset here has the same meaning as an \link{offset} for a \link{glm}.
#'
#' @param control a list of parameters for controlling the fitting process.
#' This is passed to \link{control.mrb}.
#'
#' @param ... further arguments passed to or from other methods.
#'
#' @export fit.mrb
#' @import stats
#'
#' @details The function defines an objective function (e.g. negative log-likelihood
#' function, and residual sum of squares) and call a minimizer (e.g. \link{optim})
#' to minimize the objective function. A attempt to find starting values for all
#' model parameters is also optionnaly performed before the minimization.
#'
#' @return An object of class \code{"mrbglm.fit"}, that is a list with components:
#'
#' \code{coefficients, L.coefs, fitted.values, L.values, logLike, aic,}
#' \code{deviance, null.deviance, residual.deviance, df.residual, df.null,}
#' \code{p, q, rank, weights, intercepts,order.intercepts, Rmat, hessian, start, linkinv,}
#' \code{control, converged, iter}.
#'
#' See section "Value" in \link{glm.mrb} for descriptions of the list components.
#'
#' @seealso \link{glm.mrb}.
#'
# @examples
# set.seed(167)
# mrbdata = sim.mrb (beta = c(2, -2),
#                    x = cbind(x1 = runif(1000, min = -10, max = 5),
#                              x2 = runif(1000, min = -5, max = 10)),
#                    delta = qlogis(.66))$data
#
# head (mrbdata)
# # Including only a multiplicative intercept (the limit success probability)
# MRBfit1 = fit.mrb (y = mrbdata$y, x = cbind(mrbdata$x1, mrbdata$x2))
# MRBfit1
#
# me.offsets
# USE A GRID SEARCH on \eqn{delta} a PRE-SPECIFIED INTERVAL I = [a, b]

fit.mrb <- function(y, weights = 1, sample.weights = 1,
                    x, contract_eta, intercepts = TRUE, x.offsets = 0,
                    x.with.me = NULL, zme = NULL,
                    me.intercepts = FALSE, me.offsets = 0,
                    zminp = NULL, minp.offset = 0,
                    zmaxp = 1, maxp.offset = 0,
                    link = logit(),
                    start = NULL,
                    mustart = NULL, etastart = NULL,
                    mestart = NULL, gammastart = NULL,
                    Lostart = NULL, deltaostart = NULL,
                    Lstart = NULL, deltastart = NULL,
                    control = list(), ...) {

  # zme and x.with.me
  if (!is.null(zme)) {
    r <- ncol(zme)
    if (r == 0)
      zme <- NULL
    else {
      if(r > ncol(x))
        stop("inconsistent arguments 'x' and 'zme': more measurement error covariates than regression covariates!")
      if(is.null(x.with.me))
        x.with.me <- rep(TRUE, r)
      else if (sum(x.with.me) != r)
        stop("inconsistent arguments 'zme' and 'x.with.me'")
    }
  }

  # me.offsets
  if (is.null(me.offsets))
    me.offsets <- 0
  else {
    stopifnot(is.numeric(me.offsets))
    if (all(me.offsets == 0))
      me.offsets <- 0
  }

  # Call "fit.mrb.be" if any Bergeson error variance is available
  if (any(c(!is.null(zme), !is.null(mestart), !all(me.offsets == 0)))) {

    # indicator of predictors with me (pred.with.me)
    if (all(me.offsets == 0)) {
      x.with.me.offsets <- rep(FALSE, NCOL(x))
    }
    else if (length(me.offsets) == 1) {
      x.with.me.offsets <- rep(TRUE, NCOL(x))
    }
    else {
      x.with.me.offsets <- colSums(as.matrix(abs(me.offsets))) > 0
    }
    pred.with.me <- x.with.me.offsets

    if (!is.null(x.with.me))
      pred.with.me <- pred.with.me | x.with.me

    if (is.matrix(mestart)) {
      x.with.mestart <- colSums(as.matrix(abs(mestart))) > 0

      pred.with.me <- pred.with.me | x.with.mestart
    }

    # gammastart needs 'zme' to be useful
    return(fit.me.mrb (y = y, weights = weights, sample.weights = sample.weights,
                       x = x, contract_eta = contract_eta,
                       intercepts = intercepts, x.offsets = x.offsets,
                       x.with.me = x.with.me, zme = zme, pred.with.me = pred.with.me,
                       me.intercepts = me.intercepts, me.offsets = me.offsets,
                       zminp = zminp, minp.offset = minp.offset,
                       zmaxp = zmaxp, maxp.offset = maxp.offset,
                       link = link, start = start,
                       mustart = mustart, etastart = etastart,
                       mestart = mestart, gammastart = gammastart,
                       Lostart = Lostart, deltaostart = deltaostart,
                       Lstart = Lstart, deltastart = deltastart,
                       control = control, ...))
  }

  ### Save the call
  fit.call <- match.call()

  ### Link functions
  linkfun <- link$linkfun
  linkinv <- link$linkinv

  ### Dimensions and weights
  eval(mrb.dim())
  pi <- sum(intercepts)

  ### Initialization
  eval(initialize.mrb.fit())

  ### Negative log-likelihood function
  eval(make.mrb.nlikefun())

  ### Optimization
  nparams <- p + pi + qo * (!control$fixLo) + q * (!control$fixL)
  theta0 <- start
  start <- start[1:nparams]

  ### Bounds if required
  boundaries <- !is.null(control$slope.signs) | !is.null(control$lower.intercepts) | !is.null(control$upper.intercepts)
  if (boundaries) {
    # Slope bounds
    if (!is.null(control$slope.signs)) {
      if (identical(control$slope.signs, "positive")) {
        start[(pi + 1):(pi + p)] <- pmax(1e-10, start[(pi + 1):(pi + p)])
        lowerb <- rep(-Inf, nparams)
        lowerb[(pi + 1):(pi + p)] <- 0
        upperb <- Inf
      }
      else {
        start[(pi + 1):(pi + p)] <- pmin(-1e-10, start[(pi + 1):(pi + p)])
        lowerb <- -Inf
        upperb <- rep(Inf, nparams)
        upperb[(pi + 1):(pi + p)] <- 0
      }
    }
    else {
      lowerb = -Inf
      upperb = Inf
    }

    # Lower intercept bounds
    if (!is.null(control$lower.intercepts)) {
      if (length(lowerb) == 1) {
        lowerb <- rep(-Inf, nparams)
      }

      if (is.character(control$lower.intercepts)) {
        if (identical(control$lower.intercepts, 'xmin') | identical(control$lower.intercepts, 'xq0'))
          lowerb[1:pi] <- apply(cbind(X)[, intercepts, drop = FALSE], MARGIN = 1, FUN = min)
        else if (control$lower.intercepts %in% c('xq25', 'xq20', 'xq15', 'xq10', 'xq5', 'xq2.5', 'xq1')) {
          lowerbnum <- as.numeric(strsplit (control$lower.intercepts, split = "xq", fixed = TRUE)[[1]][2])
          lowerbnum <- lowerbnum / 100
          lowerb[1:pi] <- apply(cbind(X)[, intercepts, drop = FALSE], MARGIN = 1, FUN = function(x) quantile(x, probs = lowerbnum))
        }
      }
      else if (is.numeric(control$lower.intercepts)) {
        if (length(control$lower.intercepts) != pi) {
          stop(paste0("the length of a numeric 'control$lower.intercepts' must ",
                      "be the number of intercepts in the model (", pi, ")"))
        }
        lowerb[1:pi] <- control$lower.intercepts
      }
      else {
        stop("'control$lower.intercepts' must be NULL, 'xq25', 'xq20', 'xq15', 'xq10', 'xq5', 'xq2.5', 'xq1', 'xq0', or 'xmin', or a numeric vector")
      }
    }

    # Upper intercept bounds
    if (!is.null(control$upper.intercepts)) {
      if (length(upperb) == 1) {
        upperb <- rep(Inf, nparams)
      }

      if (is.character(control$upper.intercepts)) {
        if (identical(control$upper.intercepts, 'xmax') | identical(control$upper.intercepts, 'xq100'))
          upperb[1:pi] <- apply(cbind(X)[, intercepts, drop = FALSE], MARGIN = 1, FUN = max)
        else if (control$upper.intercepts %in% c('xq75', 'xq80', 'xq85', 'xq90', 'xq95', 'xq97.5', 'xq99')) {
          upperbnum <- as.numeric(strsplit (control$upper.intercepts, split = "xq", fixed = TRUE)[[1]][2])
          upperbnum <- upperbnum / 100
          upperb[1:pi] <- apply(cbind(X)[, intercepts, drop = FALSE], MARGIN = 1, FUN = function(x) quantile(x, probs = upperbnum))
        }
      }
      else if (is.numeric(control$upper.intercepts)) {
        if (length(control$upper.intercepts) != pi) {
          stop(paste0("the length of a numeric 'control$upper.intercepts' must ",
                      "be the number of intercepts in the model (", pi, ")"))
        }
        upperb[1:pi] <- control$upper.intercepts
      }
      else {
        stop("'control$upper.intercepts' must be NULL, 'xq75', 'xq80', 'xq85', 'xq90', 'xq95', 'xq97.5', 'xq99', 'xq100', or 'xmax', or a numeric vector")
      }
    }

    # Adjust 'start'
    if (any(lowerb >= upperb)) {
      cat("\n")
      print(rbind(LB = lowerb, UB = upperb))
      cat("\n")
      stop('inconsistent parameter bounds found:')
    }
    start <- pmax(start, lowerb)
    start <- pmin(start, upperb)
  }
  else {
    lowerb = -Inf
    upperb = Inf
  }

  vmethods <- c("Nelder-Mead", "BFGS", "CG", "L-BFGS-B", "SANN", "Brent")
  vmethod <- control$method %in% vmethods
  optres0 <- NULL

  if (length(control$method) > 1 | any(!vmethod)) {

    optres0 <- optim.mrb (start = start,
                          nb.betas = pi + p,
                          nlikefun = nlikefun,
                          control = control,
                          lower = lowerb,
                          upper = upperb)

    optres <- optres0$finalresult
    control$method <- unique(c(control$final.method, control$method))
    vmethod <- control$method %in% vmethods

    if (any(vmethod)) {
      control$method <- control$method[vmethod][1]
    }
    else
      control$method <- "Nelder-Mead"
  }
  else {
    optres <- catch.conditions({
      stats::optim(par = start, fn = nlikefun,
                   method = control$method,
                   control = list(maxit = control$maxit,
                                  reltol = control$epsilon),
                   lower = lowerb,
                   upper = upperb,
                   hessian = TRUE)
    })$value
  }

  pbeta <- pi + p
  if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
    optres <- catch.conditions({
      stats::optim(par = start, fn = nlikefun,
                   method = 'Nelder-Mead',
                   control = list(maxit = 3 * control$maxit,
                                  reltol = control$epsilon),
                   lower = lowerb,
                   upper = upperb)
    })$value
    if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
      if (!control$fixL) {
      start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(deltastart + 1, q)
      optres <- catch.conditions({
        stats::optim(par = start, fn = nlikefun,
                     method = control$method,
                     control = list(maxit = control$maxit,
                                    reltol = control$epsilon),
                     lower = lowerb,
                     upper = upperb,
                     hessian = TRUE)
      })$value

      if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
        start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(deltastart + 2, q)
        optres <- catch.conditions({
          stats::optim(par = start, fn = nlikefun,
                       method = control$method,
                       control = list(maxit = control$maxit,
                                      reltol = control$epsilon),
                       lower = lowerb,
                       upper = upperb,
                       hessian = TRUE)
        })$value
      }

      if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
        start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(-1, q)
        optres <- catch.conditions({
          stats::optim(par = start, fn = nlikefun,
                       method = control$method,
                       control = list(maxit = control$maxit,
                                      reltol = control$epsilon),
                       lower = lowerb,
                       upper = upperb,
                       hessian = TRUE)
        })$value
      }

      if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
        start[(pbeta+qo+1):(pbeta+qo+q)] <- rep(-2, q)
        optres <- catch.conditions({
          stats::optim(par = start, fn = nlikefun,
                       method = control$method,
                       control = list(maxit = control$maxit,
                                      reltol = control$epsilon),
                       lower = lowerb,
                       upper = upperb,
                       hessian = TRUE)
        })$value
      }
      }

      if (any(class(optres) %in% c("simpleError", "error", "condition", "try-error"))) {
        stop(paste0("fitting failled: ",
                    optres,
                    ". Try another optimizer (see '?control.mrb')"))
      }
    }
    else {
      optres <- catch.conditions({
        stats::optim(par = optres$par, fn = nlikefun,
                     method = control$method,
                     control = list(maxit = control$maxit,
                                    reltol = control$epsilon),
                     lower = lowerb,
                     upper = upperb,
                     hessian = TRUE)
      })$value
    }
  }
  else if (any(colSums(optres$hessian[1:pbeta, 1:pbeta] == 0) == pbeta) & !control$fixL) {
    start1 <- start
    start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart + 1
    optres1 <- catch.conditions({
      stats::optim(par = start1, fn = nlikefun,
                   method = control$method,
                   control = list(maxit = control$maxit,
                                  reltol = control$epsilon),
                   lower = lowerb,
                   upper = upperb,
                   hessian = TRUE)
    })$value
    if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
      invalid1 <- TRUE
    }
    else {
      invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
      if (invalid1) {
        start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart + 2
        optres1 <- catch.conditions({
          stats::optim(par = start1, fn = nlikefun,
                       method = control$method,
                       control = list(maxit = control$maxit,
                                      reltol = control$epsilon),
                       lower = lowerb,
                       upper = upperb,
                       hessian = TRUE)
        })$value
        if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
          invalid1 <- TRUE
        }
        else {
          invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
        }
      }
    }
    if (invalid1) {
      start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart - 1
      optres1 <- catch.conditions({
        stats::optim(par = start1, fn = nlikefun,
                     method = control$method,
                     control = list(maxit = control$maxit,
                                    reltol = control$epsilon),
                     lower = lowerb,
                     upper = upperb,
                     hessian = TRUE)
      })$value
      if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
        invalid1 <- TRUE
      }
      else {
        invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
        if (invalid1) {
          start1[(pbeta+qo+1):(pbeta+qo+q)] <- deltastart - 2
          optres1 <- catch.conditions({
            stats::optim(par = start1, fn = nlikefun,
                         method = control$method,
                         control = list(maxit = control$maxit,
                                        reltol = control$epsilon),
                         lower = lowerb,
                         upper = upperb,
                         hessian = TRUE)
          })$value
          if (any(class(optres1) %in% c("simpleError", "error", "condition", "try-error"))) {
            invalid1 <- TRUE
          }
          else {
            invalid1 <- any(colSums(optres1$hessian[1:pbeta, 1:pbeta] == 0) == pbeta)
          }
        }
      }
    }
    if (!invalid1) {
      optres <- optres1
    }
  }

  if (!is.null(optres0)) {
    optres0$finalresult <- optres
    optres$details <- optres0
  }

  iter <- optres$counts
  converged <- optres$convergence == 0
  if (length(optres$convergence) == 0) {
    optres$convergence <- NA
    converged <- FALSE
    attr(converged, 'code') <- NA
  }
  else
    attr(converged, 'code') <- conv.optim(optres$convergence)
  attr(converged, 'message') <- optres$message
  boundary <- (optres$par == lowerb) | (optres$par == upperb)

  # Extracting basic results
  theta <- optres$par
  mulist <- theta2mu (theta)
  beta.int <- mulist$beta.int
  beta.x <- mulist$beta
  beta <- c(beta.int, beta.x)
  eta <- mulist$eta
  if (!control$fixLo)
    deltao <- mulist$deltao
  if (!control$fixL)
    delta <- mulist$delta
  Lovalues <- mulist$Lovalues
  logLvalues <- mulist$logLvalues
  mu <- mulist$mu
  validmu <- mulist$validmu

  ### Degrees of freedom
  df.residual <- ssize - nparams
  df.null <- ssize - 1
  if (!all(validmu) & length(weights) > 1)
    weights <- weights[validmu]
  if (identical(control$criterion, "NLS")) {
    dispersion <- sum((y[validmu] - mu[validmu])^2) / df.residual
  }
  else {
    dispersion <- 1
  }

  # Residual deviance and information criteria
  residual.deviance <- 2 * halfdev_i (mulist)
  deviance <- sum(residual.deviance[validmu])
  logLike <- - .5 * deviance
  aic <- deviance + 2 * nparams
  bic <- deviance + log(ssize) * nparams

  ### Covariance matrix estimate
  hessian <- optres$hessian
  Rmat <- catch.conditions(solve(optres$hessian))$value
  if (any(class(Rmat) %in% c("simpleError", "error", "condition", "try-error"))) {
    if (all(optres$hessian == 0))
      warning("algorithm did not converge: over-parameterized model -- no covariance matrix estimate available")
    else if (any(colSums(abs(optres$hessian[1:pbeta, 1:pbeta])) == 0))
      warning("algorithm did not converge: no covariance matrix estimate available")
    else {
      Rmato <- catch.conditions(solve(optres$hessian[1:pbeta, 1:pbeta]))$value
      if (any(class(Rmato) %in% c("simpleError", "error", "condition", "try-error"))) {
        warning("algorithm did not converge: no covariance matrix estimate available")
      }
      else {
        Rmat <- matrix(0, nrow = nparams, ncol = nparams)
        Rmat[1:pbeta, 1:pbeta] <- Rmato
        warning("over-parameterized model? -- 0 or NA in covariance matrix estimate")
        Rmat <- Rmat * dispersion
        dimnames(Rmat) <- list(names(start), names(start))
      }
    }
  }
  else {
    Rmat <- Rmat * dispersion
    dimnames(Rmat) <- list(names(start), names(start))
  }

  ### Computing the null deviance (account for the criterion)
  nlike.null.mrb <- function(beta0) {
    mu <- exp(linkinv(beta0, log.p = TRUE))
    res <- ddistrlog (y = y, mu = rep(mu, length(y)), validmu = rep(TRUE, length(y)), weights = weights)

    if (!all(validsweights) & length(sample.weights) > 1) {
      sample.weights <- sample.weights[validsweights]
      res <- res[validsweights]
    }

    -sum(res * sample.weights, na.rm = TRUE)
  }

  null.method <- control$method
  if (!(null.method %in% c("Nelder-Mead", "BFGS", "CG", "L-BFGS-B", "SANN", "Brent")))
    null.method <- "Nelder-Mead"

  null.deviance <- catch.conditions({
    stats::optim(par = linkfun (mean(y/weights, na.rm = TRUE)),
                 fn = nlike.null.mrb,
                 method = null.method,
                 control = list(maxit = control$maxit,
                                reltol = control$epsilon))
  })
  if (any(class(null.deviance$value) %in% c("simpleError", "error", "condition", "try-error"))) {
    warning(paste0("fitting to compute the null deviance failled: ",
                null.deviance$value))
    null.deviance <- NA
    beta0 <- NA
  }
  else {
    beta0 <- null.deviance$value$par
    null.deviance <- 2 * null.deviance$value$value
  }

  # Names Lovalues, Lvalues
  if (!is.null(zminp)) {
    if(is.null(zonames <- names(zminp))) {
      if ((zolen <- length(zminp)) == 1) {
        names(Lovalues) <- "Lo"
      }
      else {
        if (is.matrix(zminp))
          names(Lovalues) <- paste0("Lo", 1:NCOL(zminp))
        else
          names(Lovalues) <- paste0("Lo", 1:zolen)
      }
    }
    else {
      names(Lovalues) <- zonames
    }
  }
  else if (length(Lovalues) == 1) {
    names(Lovalues) <- "Lo"
  }

  L.values <- exp(logLvalues)
  if (!is.null(zmaxp)) {
    if(is.null(znames <- names(zmaxp))) {
      if ((zlen <- length(zmaxp)) == 1) {
        names(L.values) <- "L"
      }
      else {
        if (is.matrix(zmaxp))
          names(L.values) <- paste0("L", 1:NCOL(zmaxp))
        else
          names(L.values) <- paste0("L", 1:zlen)
      }
    }
    else {
      names(L.values) <- znames
    }
  }
  else if (length(L.values) == 1) {
    names(L.values) <- "L"
  }

  # Save some design matrices
  fit.call$x.offsets <- x.offsets
  fit.call$minp.offset <- minp.offset
  fit.call$maxp.offset <- maxp.offset
  fit.call$zmaxp <- zmaxp
  fit.call$zminp <- zminp

  # Generate "estimable functions"/scores useful to get scores and thus sandwich variance estimates
  # estfun <- numScore(theta = theta, likefun_i = likefun_i)

  structure(list(coefficients = beta,
                 Lo.coefs = deltao,
                 L.coefs = delta,
                 mu = mu, fitted.values = mu * weights,
                 Lo.values = Lovalues,
                 L.values = L.values,
                 logLike = logLike, aic = aic, bic = bic,
                 deviance = deviance, null.deviance = null.deviance,
                 residual.deviance = residual.deviance,
                 df.residual = df.residual, df.null = df.null,
                 nobs = nobs, p = p, qo = qo, q = q, r = 0, rank = nparams, ssize = ssize,
                 weights = prior.weights, sample.weights = sample.weights,
                 intercepts = intercepts, order.intercepts = "separate",
                 Rmat = Rmat, dispersion = dispersion, hessian = hessian,
                 start = theta0, end = theta, boundary = boundary,
                 link = link, linkinv = linkinv,
                 fit.call = fit.call, control = control,
                 converged = converged, iter = iter, optres = optres,
                 lowerb = lowerb, upperb = upperb,
                 nlikefun = nlikefun, likefun_i = likefun_i,
                 estfun = NULL),
            class = 'mrb.fit')
}

conv.optim <- function(code) {
  paste(code, ": ",
        switch(as.character(code),
               `1` = "the iteration limit 'maxit' had been reached",
               `10` = "degeneracy of the Nelder-Mead simplex",
               `51` = "warning from the 'L-BFGS-B' method",
               `52` = "error from the 'L-BFGS-B' method",
               "successful completion"))
}
