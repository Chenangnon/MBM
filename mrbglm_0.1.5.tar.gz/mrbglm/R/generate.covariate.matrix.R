#'
#' Matrix of covariates
#'
#' Generate a three-column matrix of covariates, the first two being continuous
#' with unit means (optionally correlated, and with measurement errors), and
#' the last being independent of the first two, optionally binary or continuous.
#'
#' @param n sample size, i.e. number of observations (rows in the design matrix).
#' \code{n} must be a numeric integer when \code{w} is missing or \code{NULL}.
#' If \code{w} is not missing, \code{n} must be the number of rows of \code{w}
#' (when \code{n} is supplied and not \code{NULL}).
#'
#' @param w optional design matrix of true covariates values.
#'
#' @param CD character indicating the continuous probability distribution to
#' generate continuous covariates from when \code{w} is missing (or \code{NULL}).
#' One of \code{'unif'}, \code{'norm'}, and 'lnorm' for uniform, normal,
#' and log-normal distributions, respectively.
#'
#' @param mu_c numeric scalar, expectation of each continuous covariate to generate.
#'
#' @param w3.continuous logical, should the third covariate be generated from
#' a continuous distribution? (The first two are alway from a continuous distribution).
#' If \code{FALSE}, the third covariate is generated from a binary distribution
#' with expectation \code{mu_b}
#'
#' @param mu_b numeric scalar in the open \code{(0, 1)}, expectation of binary
#' covariates. Only used when \code{w3.continuous = FALSE}.
#'
#' @param sigma_22 numeric, positive scalar, variance of the distribution of the
#' second covariate to be generated.
#'
#' @param rho numeric scalar in the open \code{(-1, 1)}, coefficient of correlation
#' between the first two covariates to be generated.
#'
#' @param x optional design matrix of measurement error prone covariates values.
#'
#' @param MED character indicating the continuous probability distribution to
#' generate measurement errors for continuous covariates from when \code{x} is
#' missing (or \code{NULL}). One of \code{'bridge'} and \code{'norm'} for bridge
#' and normal distributions, respectively.
#'
#' @param sigma_e2 numeric, positive scalar, average variance of the distribution of the
#' measurement errors to be generated.
#'
#' @param seed integer giving a seed for reproducibility, or \code{NULL}. When non-null,
#' \link{set.seed} is called to ensure reproducibility, but the state of the
#' random generator is saved before setting the seed, and restored to the saved value
#' after generating the design matrices.
#'
#' @details
#' When both arguments \code{w} and \code{x} are supplied and not null,
#' the function only checks their consistency with argument \code{n} and
#' return the supplied \code{w} and \code{x}.
#'
#' When \code{w3.continuous = TRUE}, the third covariate is measurement error
#' prone as the first two. If \code{w3.continuous = FALSE}, the third covariate
#' is binary and has no measurement error.
#'
#' @return A list with the following elements:
#'
#' \item{w}{ the 3-column matrix of true covariate values.}
#' \item{x}{ the 3-column matrix of error prone covariate values.}
#'
#' @export generate.covariate.matrix
#'
#' @examples
#' # Generate the covariate matrices
#' Dmats <- generate.covariate.matrix (n = 1000,
#'                                     CD = 'unif',
#'                                     mu_c = 1,
#'                                     w3.continuous = TRUE,
#'                                     sigma_22 = 1,
#'                                     rho = 0,
#'                                     MED = 'bridge',
#'                                     sigma_e2 = 0.25,
#'                                     seed = 123)
#' # Summaries
#' summary(Dmats$w)
#'
#' summary(Dmats$x)
#'
#'
# # rrlnorm rrunif
generate.covariate.matrix <- function (n = NULL,
                                       w = NULL, # matrix of true covariates
                                       CD = c('unif', 'norm', 'lnorm'),
                                       mu_c = 1,   # Average of each continuous covariate
                                       w3.continuous = TRUE, # should the third covariate be continuous too?
                                       mu_b = 0.5, # Average of the third (binary) covariate (not used when \code{w3.continuous = TRUE})
                                       sigma_22 = 1,
                                       rho = 0,
                                       x = NULL, # matrix of covariates with measurement errors
                                       MED = c('bridge', 'norm'),
                                       sigma_e2 = 0.25,
                                       VED = 'unif',
                                       seed = NULL) {
  # Set seed if required
  if (!is.null(seed)) {
    saved.seed <- .Random.seed
    set.seed(seed)
  }

  # Argument check
  stopifnot(CD[1] %in% c('unif', 'norm', 'lnorm'))
  if (identical(CD[1], "lnorm"))
    stopifnot(mu_c > 0)
  stopifnot(is.logical(w3.continuous))
  w3.continuous <- w3.continuous[1]
  if (!w3.continuous)
    stopifnot(mu_b > 0, mu_b < 1)
  stopifnot(sigma_22 > 0)
  stopifnot(rho > -1, rho < 1)
  stopifnot(MED[1] %in% c('bridge', 'norm'))
  stopifnot(VED[1] %in% c('unif', 'chisq', 'constant'))
  stopifnot(sigma_e2 >= 0)
  sigma_e2 <- sigma_e2[1]

  # Generate matrix of true continuous covariate (no measurement error)
  if (is.null(w)) {
    stopifnot(!missing(n))
    switch(CD[1],
           unif = {
             w <- rbivunif(n = n[1], mu = rep(mu_c, 2),
                           sigma = c(1, sqrt(sigma_22[1])), rho = rho[1])
           },
           norm = {
             w <- rbivnorm(n = n[1], mu = rep(mu_c, 2),
                           sigma = c(1, sqrt(sigma_22[1])), rho = rho[1])
           },
           lnorm = {
             w <- rbivlnorm(n = n[1], mu = rep(mu_c, 2),
                            sigma = c(1, sqrt(sigma_22[1])), rho = rho[1])
           })

    # Add the binary covariate x3 to x
    if (w3.continuous) {
      switch(CD[1],
             unif = {
               w3 <- rrunif(n = n[1], mu = mu_c, sigma = 1)
               },
             norm = {
               w3 <- rnorm(n = n[1], mean = mu_c, sd = 1)
             },
             lnorm = {
               w3 <- rrlnorm(n = n[1], mu = mu_c, sigma = 1)
             })
    }
    else
      w3 <- rbinom(n = n[1], size = 1, prob = mu_b[1])

    w <- cbind(w1 = w[,1], w2 = w[,2], w3 = w3)
  }
  else {
    if (!missing(n) & !is.null(n))
      stopifnot(NCOL(w) == 3, NROW(w) == n)
    else
      n <- NROW(w)
    w <- as.matrix(w)
  }

  # Generate matrix of continuous covariate with measurement errors
  if (is.null(x)) {
    x <- w
    if (sigma_e2 > 0) {

      sigma_e2 <- matrix(switch(VED[1],
                                unif = {
                                  runif(n = (2+w3.continuous)*n, min = 0, max = 2*sigma_e2)
                                },
                                chisq = {
                                  rchisq(n = (2+w3.continuous)*n, df = sigma_e2)
                                },
                                constant = {
                                  sigma_e2
                                }),
                         nrow = n,
                         ncol = 2+w3.continuous)

      Ex <- matrix(switch(MED[1],
                          bridge = {
                            rbridge(n = (2+w3.continuous)*n, location = 0,
                                    scale = pi / sqrt(pi^2 + 3 * c(sigma_e2[,1:(2+w3.continuous)])))
                          },
                          norm = {
                            rnorm(n = (2+w3.continuous)*n, mean = 0,
                                  sd = sqrt(c(sigma_e2[,1:(2+w3.continuous)])))
                          }),
                   nrow = n, ncol = 2+w3.continuous)

      x[,1:(2+w3.continuous)] <- w[,1:(2+w3.continuous)] + Ex

    }
  }
  else {
    stopifnot(NCOL(x) == 3, NROW(x) == n)
    x <- as.matrix(x)
  }

  if (!is.null(seed)) {
    .Random.seed <- saved.seed
  }

  return(list(w = w, x = x, sigma_e2 = sigma_e2))

}
