
# Project of a grouped formula interface for mrb models
# User will give a formula for each group.
# Risks are multiplicative between groups, effects are additive at link scale within each group.
# Intercepts are allowed withing each group (no argument 'intercepts' HERE)
# Interaction terms are allowed withing each group, but not between groups
# Higher order terms are also allowed
#

glm.gmrb <- function (formula,               # Response ~ first group, or response ~ 1
                      groups = list(),       # a list of formulas for (additional) groups
                      link = logit,          # link name or function returning a link object
                      group.with.me = NULL,  #
                      me.formula   = ~ -1,   #
                      minp.formula = ~ -1,
                      maxp.formula = ~  1,
                      data, weights, subset,
                      na.action = getOption("na.action"),
                      sample.weights = ~ 1,
                      start = NULL,  etastart, mustart,
                      mestart = NULL, gammastart = NULL,
                      Lostart = NULL, deltaostart = NULL,
                      Lstart = NULL, deltastart = NULL,
                      me.intercepts = FALSE,
                      group.with.offsets  = NULL, group.offsets = ~ -1, #
                      me.with.offsets = NULL, me.offsets  = ~ -1,       #
                      minp.offset = ~ -1,
                      maxp.offset = ~ -1,
                      method = 'fit.mrb',
                      control = list(),
                      model = FALSE,
                      x = FALSE, y = TRUE,
                      ...) {

  gmrb.frame()

}
