# infer.lambda used for simulation results labelled 'Feb17'
infer.lambda00 <-
  function (x, y, min.quantile = 0.1, max.quantile = 0.4, bin.size = 0.1,
            leftmost = TRUE, alpha = 0.2, alternative = c("two.sided", "less", "greater"),
            conf.level = 0.95, eps = 1e-05)  {
    mcall <- match.call()
    stopifnot(eps > 0)
    stopifnot(min.quantile >= eps, min.quantile < 0.25)
    stopifnot(min.quantile < max.quantile, max.quantile <= 0.5)
    stopifnot(bin.size > 0, bin.size < max.quantile)
    stopifnot(bin.size <= max.quantile - min.quantile)
    bins <- seq(from = min.quantile, to = max.quantile, by = bin.size)
    nbins <- max(length(bins), 2)
    bins[1] <- min.quantile
    bins[nbins] <- max.quantile
    qmin <- quantile(x, prob = bins)
    n <- sapply(qmin, FUN = function(xmin) {
      pick <- x <= xmin
      c(sum(pick), sum(y[pick], na.rm = TRUE))
    })
    N <- c(n[1, 1], diff(n[1, ]))
    n <- c(n[2, 1], diff(n[2, ]))
    res.df <- matrix(NA, nrow = nbins, ncol = 5)
    colnames(res.df) <- c("N", "n", "lambda", "odds.ratio", "p.value")
    rownames(res.df) <- names(N)
    x_argo <- x_arg <- n[1]
    n_argo <- n_arg <- N[1]
    res.df[1, ] <- c(N = n_argo, n = x_argo, lambda = x_argo/n_argo,
                     odds.ratio = NA, p.value = NA)
    for (k in 2:nbins) {
      x_arg <- x_arg + n[k]
      n_arg <- n_arg + N[k]
      Ftests <- fisher.test(matrix(c(x_argo, x_arg, n_argo -
                                       x_argo, n_arg - x_arg), nrow = 2, byrow = TRUE),
                            alternative = alternative[1])
      if (!leftmost) {
        x_argo <- x_arg
        n_argo <- n_arg
      }
      res.df[k, ] <- c(n_arg, x_arg, x_arg/n_arg, Ftests$estimate,
                       Ftests$p.value)
    }
    res.df <- as.data.frame(res.df)
    pick <- which(res.df$p.value[-1] <= alpha)
    if (length(pick)) {
      pick <- pick[1]
    }
    else {
      pick <- nbins
    }
    lambda <- res.df[pick, 3]
    elbow.x <- qmin[pick]
    Btest <- binom.test(x = c(sum(n[1:pick]), sum(N[1:pick]) -
                                sum(n[1:pick])), alternative = alternative[1], conf.level = conf.level[1])
    res.df <- cbind(x = qmin, res.df)
    return(list(lambda = lambda, elbow.x = elbow.x, conf.int = Btest$conf.int,
                raw = res.df, call = mcall))
  }
