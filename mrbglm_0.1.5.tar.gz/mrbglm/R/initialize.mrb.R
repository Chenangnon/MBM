
# smrb = simple MRB model
Initialize.L <- function(y, x = NULL,
                         method = "binomial",
                         bin.sum = FALSE, # Ignore the order of the data (use a (sum of two) binomials) ? This may be silly ...
                         n0 = 5,  # How many data points to start with (number of initial 'leftmost' points)
                         n1 = n0, # how many data points in each 'bin' (step moving forward)
                         alpha = 0.1, # Significance level
                         alternative = c("two.sided", "less", "greater"), # For the linear model, not used now.
                         slope.sign = 0) {
  # Save the call
  mcall <- match.call()

  # Data dimension and consistency
  stopifnot(all(floor(y) == y))
  stopifnot(all(y >= 0 & y <= 1))
  nobs <- length(y)
  stopifnot(floor(n0) == n0, floor(n1) == n1, n0 > 0, n1 > 0, nobs > n0, nobs > n1)
  stopifnot(nobs >= n0 + n1)

  # Order the data with x
  if (!is.null(x)) {
    x <- sort(x, index.return = TRUE)
    y <- y[x$ix]
    x <- x$x
  }

  # Compute m_0
  cumsumy <- cumsum(y)

  # Choose a method
  switch(method,
         linear = {
           if (is.null(x)) {
             stop("method 'linear' requires 'x' to be specified (numeric vector)")
           }
           muj <- cumsumy / (1:nobs)
           muj[muj == 1] <- 1 - 1/nobs
           slopes <- matrix(NA, nrow = nobs - n0 + 1, ncol = 4)
           colnames(slopes) <- c("Est", "StdErr", "tValue", "PValue")
           for (j in n0:nobs) { # stop once the slope has the desired sign and is significant!
             modelj <- lm(qlogis(muj[1:j]) ~ x[1:j])
             slopes[j - n0 + 1, ] <- summary(modelj)$coefficients[2,]
           }
           signif <- if (as.logical(slope.sign))
             (slopes[,1] * slope.sign > 0) & (slopes[,4] <= alpha)
           else slopes[,4] <= alpha

           j <- which(signif)[1] + n0 - 1
           if (is.na(j)) {
             j <- length(signif) - 1
           }
           if (j > 1) {
             j <- j - 1
           }
           L <-  mean(y[1:j])
           SD.L <- sqrt(L * (1 - L) / j)

           list(L = L, SD.L = SD.L, j = j, steps = slopes, call = mcall)
         },
         {
           # ML estimate under H0
           n <- (n0 + n1):nobs
           m <- cumsumy[n]
           alphaH0 <- m/n

           # # ML estimates under H1
           n_0 <- n0:(nobs - n1)
           m_0 <- cumsumy[n_0]
           alpha_0 <- m_0/n_0
           m_1 <- m - m_0
           alpha_1 <- m_1/n1

           # Log-likelihood under H0
           if (bin.sum) {
             #LikeH0 <- dbinom(m, size = n, prob = alphaH0, log = TRUE)
             LikeH0 <- dbinsum (m, size1 = n_0, prob1 = alphaH0,
                                size2 = n1, prob2 = alphaH0, log = TRUE)
           }
           else {
             LikeH0 <- m * dbinom(1, size = 1, prob = alphaH0, log = TRUE) +
               (n - m) * dbinom(0, size = 1, prob = alphaH0, log = TRUE)
           }
           LikeH0[is.na(LikeH0)] <- 0

           # Log-likelihood under H1
           if (bin.sum) {
             LikeH1 <- dbinsum (m, size1 = n_0, prob1 = alpha_0,
                                size2 = n1, prob2 = alpha_1, log = TRUE)
             # dbinom(m_0, size = n_0, prob = alpha_0, log = TRUE) +
             # dbinom(m_1, size = n1, prob = alpha_1, log = TRUE)
           }
           else {
             LikeH1 <- m_0 * dbinom(1, size = 1, prob = alpha_0, log = TRUE) +
               (n_0 - m_0) * dbinom(0, size = 1, prob = alpha_0, log = TRUE) +
               m_1 * dbinom(1, size = 1, prob = alpha_1, log = TRUE) +
               (n1 - m_1) * dbinom(0, size = 1, prob = alpha_1, log = TRUE)
           }
           LikeH1[is.na(LikeH1)] <- 0

           # Deviance
           DevValues <- 2 * (LikeH1 - LikeH0)

           # Probability value
           PValues <- pchisq(DevValues, df = 1, lower.tail = FALSE)

           # Difference between alpha_0 and alpha_1, should be negative
           DiffAlpha <- alphaH0 - alpha_0

           # Significance
           if (length(n_0) > 1) {

           signif <- if (as.logical(slope.sign))
             (DiffAlpha * slope.sign > 0) & (PValues <= alpha)
           else
             PValues <= alpha

           # Index
           j <- which(signif)[1]
           if (is.na(j)) {
             j <- length(signif) - 1
           }
           if (j > 1) {
             j <- j - 1
           }

           L <- alphaH0[j]
           SD.L <- sqrt(L * (1 - L) / j)
           }
           else {
             j <- 1
             L <- alpha_0[j] # if(alpha_1[j] == 0) alphaH0[j] else  alpha_0[j]
             SD.L <- sqrt(L * (1 - L) / j)
           }

           # Step wise results
           steps = as.data.frame(cbind(DevValue = DevValues, PValue = PValues,
                                       m = m, n = n, alphaH0 = alphaH0, LikeH0 = LikeH0,
                                       m_0 = m_0, n_0 = n_0, alpha_0 = alpha_0,
                                       m_1 = m_1, n_1 = n1, alpha_1 = alpha_1, LikeH1 = LikeH1))

           resultats <- list(L = L, SD.L = SD.L, j = j,
                             steps = steps, call = mcall)
           return(resultats)
         })
}


Exp.init.L0 <- function(alpha0 = c(.2, .3, .4, .5, .6, .7, .8, .9),
                        delta = c(.1, .2, .6, .8),
                        n_0 = c(5, 10, 20, 30, 50, 100),
                        n_1 = c(5, 10, 20, 30, 50, 100),
                        alpha = 0.1,
                        n0 = 5,
                        n1 = c(5, 10, 20, 30, 50),
                        B = 500,
                        seed = 123) {

  mcall <- match.call()

  scenarios <- cbind(alpha0 = rep(alpha0, each = length(delta)), delta = rep(delta, length(alpha0)))
  scenarios <- cbind(matrixcalc::direct.prod (scenarios,
                                              rep(1, length(n_0))), rep(n_0, NROW(scenarios)))
  scenarios <- cbind(matrixcalc::direct.prod (scenarios,
                                              rep(1, length(n_1))), rep(n_1, NROW(scenarios)))
  colnames(scenarios) <- c("alpha0", "delta", "n_0", "n_1")
  nb.scenarios <- NROW(scenarios)
  set.seed(seed)

  results <- apply (X = scenarios,
                    MARGIN = 1,
                    FUN = Exp.init.L0.j,
                    n0 = n0[1], n1 = n1, alpha = alpha, B = B,
                    simplify = FALSE)

  names (results) <- paste0("sce", 1:nb.scenarios)

  list(results = results, scenarios = scenarios, call = mcall)
}

Exp.init.L0.j <- function (x, n0, n1 = c(5, 10, 20, 30, 50), alpha = 0.1, B = 500) {
  alpha0 <- x[1]
  alpha1 <- alpha0 * x[2]
  n_0 <- x[3]
  n_1 <- x[4]
  nobs <- n_0 + n_1

  resj <- lapply(1:B, FUN = function(r) {
    y <- c(rbinom(n_0, size = 1, prob = alpha0),
           rbinom(n_1, size = 1, prob = alpha1))
    resi <- lapply(n1,
                   FUN = Exp.init.L0.j.k,
                   n0 = n0, y = y, alpha)
    names (resi) <- paste0("n1=", n1)
    resi
  })

  names (resj) <- paste0("rep=", 1:B)

  list(res = resj, alpha0 = alpha0, alpha1 = alpha1, n_0 = n_0, n_1 = n_1)
}

Exp.init.L0.j.k <- function(n1, n0, y, alpha) {
  nobs <- length(y)
  if (n1 > nobs - n0)
    return(list())

  res1 <- catch.conditions(initialize.L (y = y, bin.sum = FALSE,
                                         n0 = n0, n1 = n1, alpha = alpha[1]))$value

  res2 <- catch.conditions(initialize.L (y = y, bin.sum = TRUE,
                                         n0 = n0, n1 = n1, alpha = alpha[1]))$value

  list(res1 = res1, res2 = res2, y = y)
}

mySummary.expL0 <- function(object) { #
  B <- length(object[[1]]$res)
  resume <- lapply(object, # For each scenario
                   FUN = function(scej) {
                     RR <- lapply(scej$res, # For each repetition n_0
                            FUN = function(repi) {
                              R0 <- sapply(repi, # For each n1
                                     FUN = function(repij) {
                                       if (length(repij) == 0)
                                         return(rep(NA, 8))
                                       if (is.null(repij$res1$L)) {
                                         res1alpha.1 <- res1alpha.05 <- c(NA, NA)
                                       }
                                       else {
                                         res1alpha.05 <- c(repij$res1$L, repij$res1$steps[repij$res1$j,8])

                                         # Significance
                                         if (length(repij$res1$steps[,2]) > 1) {
                                           signif <- repij$res1$steps[,2] <= 0.05

                                           # Index
                                           j <- which(signif)[1]
                                           if (is.na(j)) {
                                             j <- length(signif) - 1
                                           }
                                           if (j > 1) {
                                             j <- j - 1
                                           }

                                           L <- repij$res1$steps[j,5]

                                           res1alpha.1 <- c(L, repij$res1$steps[j,8])
                                         }
                                         else {
                                           res1alpha.1 <- res1alpha.05
                                         }
                                       }

                                       if (is.null(repij$res2$L)) {
                                         res1alpha.05 <- c(res1alpha.05, NA, NA)
                                         res1alpha.1 <- c(res1alpha.1, NA, NA)
                                       }
                                       else {
                                         res1alpha.05 <- c(res1alpha.05,
                                                           repij$res2$L, repij$res2$steps[repij$res2$j,8])

                                         # Significance
                                         if (length(repij$res2$steps[,2]) > 1) {
                                           signif <- repij$res2$steps[,2] <= 0.05

                                           # Index
                                           j <- which(signif)[1]
                                           if (is.na(j)) {
                                             j <- length(signif) - 1
                                           }
                                           if (j > 1) {
                                             j <- j - 1
                                           }

                                           L <- repij$res2$steps[j,5]

                                           res1alpha.1 <- c(res1alpha.1, L, repij$res2$steps[j,8])
                                         }
                                         else {
                                           res1alpha.1 <- c(res1alpha.1, res1alpha.05[3:4])
                                         }
                                       }
                                       c(res1alpha.05, res1alpha.1)
                                     })
                              R0
                            })
                     names(RR) <- names(scej$res)

                     #print(RR)

                     ave <- sapply(RR, c)


                     SD <- apply(ave, MARGIN = 1, FUN = sd, na.rm = TRUE)
                     ave <- apply(ave, MARGIN = 1, FUN = mean, na.rm = TRUE)
                     list(MEAN = ave, SD = SD, raw = RR)
                   })
  names(resume) <- names(object)

  ave <- t(sapply(resume, FUN = function(x) { x$MEAN }))
  SD <- t(sapply(resume, FUN = function(x) { x$SD }))

  nb.n1 <- length(object$sce1$res[[1]])
  main <- lapply(1:nb.n1, FUN = function(j) {
    bar <- ave[, ((j - 1)*8 + 1):(j * 8)]
    dev <- SD[, ((j - 1)*8 + 1):(j * 8)]
    colnames(bar) <- colnames(dev) <- c("L.b.1", "n_0.b.1", "L.s.1", "n_0.s.1",
                                        "L.b.05", "n_0.b.05", "L.s.05", "n_0.s.05")

    keep <- rowSums(is.na(cbind(bar, dev))) < 16 # select all non-total NaN rows

    list(MEAN = bar[keep,,drop = FALSE], SD = dev[keep,,drop = FALSE])
  })

  names(main) <- names(object$sce1$res[[1]])

  list(main = main, raw = resume)
}

get.exp.init.L0.scenarios <- function(alpha0 = c(.2, .3, .4, .5, .6, .7, .8, .9),
                                  delta = c(.1, .2, .6, .8),
                                  n_0 = c(5, 10, 20, 30, 50, 100),
                                  n_1 = c(5, 10, 20, 30, 50, 100)) {
  scenarios <- cbind(alpha0 = rep(alpha0, each = length(delta)), delta = rep(delta, length(alpha0)))
  scenarios <- cbind(matrixcalc::direct.prod (scenarios,
                                              rep(1, length(n_0))), rep(n_0, NROW(scenarios)))
  scenarios <- cbind(matrixcalc::direct.prod (scenarios,
                                              rep(1, length(n_1))), rep(n_1, NROW(scenarios)))
  colnames(scenarios) <- c("alpha0", "delta", "n_0", "n_1")
  rownames(scenarios) <- paste0("sce", 1:NROW(scenarios))

  return(scenarios)
}
