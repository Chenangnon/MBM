#load.as.envir <- function (path) {
#  Time <- system.time({
#    envir <- new.env()
#    load(path, envir = envir)
#  })
#  attr(envir, 'loading.time') <- Time
#
#  return(envir)
#
#}
