#'
#' Distribution Functions for Measurement Error Families
#'
#' This function is used with \link{link} functions in \link{glm.mrb}.
#' Given the name of a family, it returns a probability density function (pdf),
#' a cumulative distribution function (cdf), and a quantile (inverse cdf)
#' function (quf).
#'
#' @param me.family character; currently one of \code{"norm"}, \code{"logis"},
#' and \code{bridge}, corresponding to the Gaussian, Logistic and Bridge
#' distribution families, respectively.
#'
#' @export make.me.family
#'
#' @return An object of class \code{me-family}, a list with components:
#' \item{pdf}{probability density function of the family.}
#' \item{cdf}{cumulative distribution function of the family.}
#' \item{quf}{quantile (inverse cdf) function of the family.}
#' \item{name}{a name to be used for the family.}
#'
#' The arguments of these three functions are
#' \item{eta}{numeric; vector of quantiles,}
#' \item{p}{numeric; vector of probabilities,}
#' \item{sd}{numeric; vector of standard deviations,}
#' \item{log,log.p}{logical; should the \code{log} of density/probability values
#' be returned? Defaults to \code{FALSE},}
#' \item{lower.tail}{logical, should the probability in the lower tail be
#' returned? Defaults to \code{TRUE}.}
#'
#' @seealso \link[mrbglm]{link}, \link[mrbglm]{probit}, \link[mrbglm]{logit},
#' \link[mrbglm]{glm.mrb}.
#'
make.me.family <- function(me.family) {
  switch(me.family,
         norm = {
           pdf <- function(eta, sd = 1, log = FALSE) {
             dnorm (eta, sd = sd, log = log)
           }
           cdf <- function(eta, sd = 1, lower.tail = TRUE, log.p = FALSE) {
             thresh <- -qnorm(.Machine$double.eps)
             eta <- pmin(pmax(eta, -thresh), thresh)
             pnorm (eta, sd = sd, lower.tail = lower.tail, log.p = log.p)
           }
           quf <- function(p, sd = 1, lower.tail = TRUE, log.p = FALSE) {
             qnorm (p, sd = sd, lower.tail = lower.tail, log.p = log.p)
           }
         },
         logis = {
           pdf <- function(eta, sd = 1, log = FALSE) {
             dlogis (eta, scale = sd * sqrt(3) / pi, log = log)
           }
           cdf <- function(eta, sd = 1, lower.tail = TRUE, log.p = FALSE) {
             plogis (eta, scale = sd * sqrt(3) / pi, lower.tail = lower.tail, log.p = log.p)
           }
           quf <- function(p, sd = 1, lower.tail = TRUE, log.p = FALSE) {
             qlogis (p, scale = sd * sqrt(3) / pi, lower.tail = lower.tail, log.p = log.p)
           }
         },
         bridge = {
           pdf <- function(eta, sd = 1, log = FALSE) {
             dbridge (eta, scale = pi / sqrt(3*sd^2 + pi^2), log = log) # scale = phi
           }
           cdf <- function(eta, sd = 1, lower.tail = TRUE, log.p = FALSE) {
             pbridge (eta, scale = pi / sqrt(3*sd^2 + pi^2), lower.tail = lower.tail, log.p = log.p)
           }
           quf <- function(p, sd = 1, lower.tail = TRUE, log.p = FALSE) {
             qbridge (p, scale = pi / sqrt(3*sd^2 + pi^2), lower.tail = lower.tail, log.p = log.p)
           }
         },
         {
           stop("not yet implemented for families other than 'norm', 'bridge' and 'logis'")
         })

  environment(pdf) <- environment(cdf) <- environment(quf) <- asNamespace("stats")
  structure(list(pdf = pdf, cdf = cdf, quf = quf,
                 name = me.family),
            class = "me-family")
}
