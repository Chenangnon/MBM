
# A routine to generate negative log-likelihood function for mrb fit
make.me.mrb.nlikefun <- function() {

  expression({
    X <- x
    if(is.matrix(X))
      X <- t(X)
    X.offsets <- x.offsets
    if(is.matrix(X.offsets))
      X.offsets <- t(X.offsets)

    # beta.with.me
    beta.with.me <- beta.with.me.index (contract_eta, pred.with.me = pred.with.me)

    # Penalty computation
    {
      beta.penalty.factor <- switch(control$penalty,
                                    none = 0,
                                    1/((nobs - p)^(control$nobs.power)))
      int.penalty.factor <- switch(control$penalty,
                                   none = 0,
                                   1/((nobs - pi)^(control$nobs.power)))

      penalty.fun <- switch(control$penalty,
                            ridge = function(beta, m = 1) {
                              m * sum(beta^2)
                            },
                            lasso = function(beta, m = 1) {
                              m * sum(abs(beta))
                            },
                            logf = function(beta, m = 1) {
                              - m * sum(.5 * beta - log(1 + exp(beta)))
                            },
                            none = function(beta, m = 1) {
                              0
                            })
      beta.int <- NULL # Used as a place holder for penalty computation when there is no intercept
      if (any(intercepts)) {
        int.tilde <- control$int.location
        if (is.null(int.tilde)) {
          int.tilde <- apply(X[intercepts, , drop = FALSE],
                             MARGIN = 1, FUN = median, na.rm = TRUE)
        }
        else {
          stopifnot(length(int.tilde) %in% c(1, sum(intercepts)))
        }

        Diff.beta.int <- function(beta.int) {
          if (is.null(beta.int))
            return(NULL)
          else
            beta.int - int.tilde
        }

      }
      else {
        Diff.beta.int <- function(beta.int) {
          return(NULL)
        }
      }

      if (control$penalize.delta & !all(c(control$fixLo, control$fixL))) {
        deltao.penalty <- if (!control$fixLo) start[(pi + p + 1):(pi + p + qo)] else 0
        if (any(is.infinite(deltao.penalty)))
          deltao.penalty[is.infinite(deltao.penalty)] <- sign(deltao.penalty[is.infinite(deltao.penalty)]) * rep(linkfun (1-(1e-16)), sum(is.infinite(deltao.penalty)))
        delta.penalty <- if (!control$fixL) start[(pi + p + qo + 1):(pi + p + qo + q)] else 0
        if (any(is.infinite(delta.penalty)))
          delta.penalty[is.infinite(delta.penalty)] <- sign(delta.penalty[is.infinite(delta.penalty)]) * rep(linkfun (1-(1e-16)), sum(is.infinite(delta.penalty)))

        penalty.deltao <- function (deltao, m = 10, npower = control$nobs.power) {
          if (any(is.infinite(c(deltao, deltao.penalty))))
            0
          else
            penalty.fun (deltao - deltao.penalty, m = m / (nobs - qo)^npower)
        }

        penalty.delta <- function (delta, m = 10, npower = control$nobs.power) {
          if (any(is.infinite(c(delta, delta.penalty))))
            0
          else
            penalty.fun (delta - delta.penalty, m = m / (nobs - q)^npower)
        }
      }
      else {
        penalty.deltao <- function (delta0) {
          0
        }

        penalty.delta <- function (delta) {
          0
        }
      }

      Lpenalty.fun <- switch(control$L.penalty,
                             none = function(logLvalue, Lovalue = 0) {
                               1
                             },
                             linear = function(logLvalue, Lovalue = 0) {
                               Lrange <- mean(exp(logLvalue), na.rm = TRUE) - mean(Lovalue, na.rm = TRUE)

                               Lrange
                             },
                             inv = function(logLvalue, Lovalue = 0) {
                               Lrange <- mean(exp(logLvalue), na.rm = TRUE) - mean(Lovalue, na.rm = TRUE)

                               1/(1-Lrange)
                             },
                             exp = function(logLvalue, Lovalue = 0) {
                               Lrange <- mean(exp(logLvalue), na.rm = TRUE) - mean(Lovalue, na.rm = TRUE)
                               (Lrange - exp(-1))/(1 - exp(-1))
                             })
    }

    # Log density of responses
    ddistrlog <- switch(control$criterion,
                     NLS = function(y, mu, validmu, weights) {
                       stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                    sd = 1, log = TRUE)
                     },
                     ML = function(y, mu, validmu, weights) {
                       stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                     })


    # Half deviance per individual observation
    halfdev_i <- function(mulist) {
      res <- numeric(nobs) + log(1e-323)
      if (length(weights) > 1 & !all(mulist$validmu))
        weights <- weights[mulist$validmu]

      res[mulist$validmu] <- ddistrlog (y = y, mu = mulist$mu, validmu = mulist$validmu, weights = weights)
      if (!all(validsweights) & length(sample.weights) > 1) {
        sample.weights <- sample.weights[validsweights]
        res <- res[validsweights]
      }

      - res * sample.weights
    }

    # Define objective
    if (control$fixme) {
      if (control$fixLo) {
        Lovalues <- Lo0
        if (all(Lovalues == 0)) {
          if (control$fixL) {
            logLvalues <- log(L0)
            Lpenalty <- Lpenalty.fun(logLvalues)
            theta2mu <- if (any(intercepts)) {
              function(theta) {
                beta.int <- theta[1:pi]
                beta <- theta[(pi+1):(pi+p)]
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                eta[intercepts,] <- eta[intercepts,] + beta.int
                sdmat <- sdmat0 <- t(sd0)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta, beta.int = beta.int,
                     Lpenalty = Lpenalty,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
            else {
              function(theta) {
                beta <- theta[1:p]
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                sdmat <- sdmat0 <- t(sd0)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta, beta.int = beta.int,
                     Lpenalty = Lpenalty,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
          }
          else {
            theta2mu <- if (any(intercepts)) {
              function(theta) {
                beta.int <- theta[1:pi]
                beta <- theta[(pi+1):(pi+p)]
                delta <- theta[(pi + p + 1):(pi + p + q)]
                logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                Lpenalty <- Lpenalty.fun(logLvalues)
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                eta[intercepts,] <- eta[intercepts,] + beta.int
                sdmat <- sdmat0 <- t(sd0)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta, beta.int = beta.int,
                     delta = delta, Lpenalty = Lpenalty,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
            else {
              function(theta) {
                beta <- theta[1:p]
                delta <- theta[(p+1):(p+q)]
                logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                Lpenalty <- Lpenalty.fun(logLvalues)
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                sdmat <- sdmat0 <- t(sd0)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta, beta.int = beta.int,
                     delta = delta, Lpenalty = Lpenalty,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
          }
        }
        else {
          if (control$fixL)  {
            logLvalues <- log(L0)
            Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
            theta2mu <- if (any(intercepts)) {
              function(theta) {
                beta.int <- theta[1:pi]
                beta <- theta[(pi+1):(pi+p)]
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                eta[intercepts,] <- eta[intercepts,] + beta.int
                sdmat <- sdmat0 <- t(sd0)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta, beta.int = beta.int,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
            else {
              function(theta) {
                beta <- theta[1:p]
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                sdmat <- sdmat0 <- t(sd0)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta, beta.int = beta.int,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
          }
          else {
            theta2mu <- if (any(intercepts)) {
              function(theta) {
                beta.int <- theta[1:pi]
                beta <- theta[(pi+1):(pi+p)]
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                eta[intercepts,] <- eta[intercepts,] + beta.int
                delta <- theta[(pi + p + 1):(pi + p + q)]
                logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
                sdmat <- sdmat0 <- t(sd0)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                     beta.int = beta.int, delta = delta, Lpenalty = Lpenalty,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
            else {
              function(theta) {
                beta <- theta[1:p]
                delta <- theta[(p+1):(p+q)]
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
                sdmat <- sdmat0 <- t(sd0)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                     beta.int = beta.int, delta = delta, Lpenalty = Lpenalty,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
          }
        }
      }
      else {
        if (control$fixL)  {
          logLvalues <- log(L0)
          if (any(intercepts)) {
            theta2mu <- function(theta) {
              beta.int <- theta[1:pi]
              beta <- theta[(pi+1):(pi+p)]
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              eta[intercepts,] <- eta[intercepts,] + beta.int
              deltao <- theta[(pi + p + 1):(pi + p + qo)]
              Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
              Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
              sdmat <- sdmat0 <- t(sd0)
              sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
              if (any(sdmat > 0))
                mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
              else
                mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
              mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                   beta.int = beta.int, deltao = deltao, Lpenalty = Lpenalty,
                   Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
            }
          }
          else {
            theta2mu <- function(theta) {
              beta <- theta[1:p]
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              deltao <- theta[(p + 1):(p + qo)]
              Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
              Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
              sdmat <- sdmat0 <- t(sd0)
              sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
              if (any(sdmat > 0))
                mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
              else
                mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
              mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                   beta.int = beta.int, deltao = deltao, Lpenalty = Lpenalty,
                   Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
            }
          }
        }
        else {
          if (any(intercepts)) {
            theta2mu <- function(theta) {
              beta.int <- theta[1:pi]
              beta <- theta[(pi+1):(pi+p)]
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              eta[intercepts,] <- eta[intercepts,] + beta.int
              deltao <- theta[(pi + p + 1):(pi + p + qo)]
              delta <- theta[(pi + p + qo + 1):(pi + p + qo + q)]
              Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
              logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
              Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
              sdmat <- sdmat0 <- t(sd0)
              sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
              if (any(sdmat > 0))
                mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
              else
                mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
              mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                   beta.int = beta.int, deltao = deltao, delta = delta, Lpenalty = Lpenalty,
                   Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
            }
          }
          else {
            theta2mu <- function(theta) {
              beta <- theta[1:p]
              deltao <- theta[(p + 1):(p + qo)]
              delta <- theta[(p + qo + 1):(p + qo + q)]
              Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
              logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
              Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              sdmat <- sdmat0 <- t(sd0)
              sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
              if (any(sdmat > 0))
                mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
              else
                mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
              mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                   beta.int = beta.int, deltao = deltao, delta = delta, Lpenalty = Lpenalty,
                   Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
            }
          }
        }
      }
    }
    else {

      # Penalties not implemented HERE!

      # A routine to extract sdmat
      get.sdmat <- function (theta, ptout) {
        gamma.int <- if (ri > 0) theta[(ptout + 1):(ptout + ri)]
        gamma <- theta[(ptout + ri + 1):(ptout + ri + r)]
        sdmat <- matrix(0, nrow = nobs, ncol = nbcovs) + me.offsets
        sdmat <- t(sdmat)

        if (length(zme) > 1) {
          meterm <- exp(gamma) * t(zme)
          if (ri > 0)
            meterm[me.intercepts,] <- meterm[me.intercepts,] + exp(gamma.int)
          sdmat[X.with.me,] <- sdmat[X.with.me, , drop = FALSE] + meterm
        }
        else {
          meterm <- exp(gamma) * zme
          if (ri > 0)
            meterm <- meterm + exp(gamma.int)
          sdmat[X.with.me,] <- sdmat[X.with.me, , drop = FALSE] + meterm
        }
        return(sdmat)
      }


      if (control$fixLo) {
        Lovalues <- Lo0
        if (all(Lovalues == 0)) {
          if (control$fixL)  {
            logLvalues <- log(L0)
            Lpenalty <- Lpenalty.fun(logLvalues)
            if (any(intercepts)) {
              theta2mu <- function(theta) {
                beta.int <- theta[1:pi]
                beta <- theta[(pi+1):(pi+p)]
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                eta[intercepts,] <- eta[intercepts,] + beta.int
                sdmat <- sdmat0 <- get.sdmat (theta, ptout = pi + p)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta, beta.int = beta.int,
                     Lpenalty = Lpenalty,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
            else {
              theta2mu <- function(theta) {
                beta <- theta[1:p]
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                sdmat <- sdmat0 <- get.sdmat (theta, ptout = p)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta, beta.int = beta.int,
                     Lpenalty = Lpenalty,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
          }
          else {
            if (any(intercepts)) {
              theta2mu <- function(theta) {
                beta.int <- theta[1:pi]
                beta <- theta[(pi+1):(pi+p)]
                delta <- theta[(pi + p + 1):(pi + p + q)]
                logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                Lpenalty <- Lpenalty.fun(logLvalues)
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                eta[intercepts,] <- eta[intercepts,] + beta.int
                sdmat <- sdmat0 <- get.sdmat (theta, ptout = pi + p + q)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                     beta.int = beta.int, delta = delta,
                     Lpenalty = Lpenalty,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
            else {
              theta2mu <- function(theta) {
                beta <- theta[1:p]
                delta <- theta[(p+1):(p+q)]
                logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                Lpenalty <- Lpenalty.fun(logLvalues)
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                sdmat <- sdmat0 <- get.sdmat (theta, ptout = p + q)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(logLvalues + colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                     beta.int = beta.int, delta = delta,
                     Lpenalty = Lpenalty,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
          }
        }
        else {
          if (control$fixL)  {
            logLvalues <- log(L0)
            Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)

            if (any(intercepts)) {
              theta2mu <- function(theta) {
                beta.int <- theta[1:pi]
                beta <- theta[(pi+1):(pi+p)]
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                eta[intercepts,] <- eta[intercepts,] + beta.int
                sdmat <- sdmat0 <- get.sdmat (theta, ptout = pi+p)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta, beta.int = beta.int,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
            else {
              theta2mu <- function(theta) {
                beta <- theta[1:p]
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                sdmat <- sdmat0 <- get.sdmat (theta, ptout = p)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta, beta.int = beta.int,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
          }
          else {
            if (any(intercepts)) {
              theta2mu <- function(theta) {
                beta.int <- theta[1:pi]
                beta <- theta[(pi+1):(pi+p)]
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                eta[intercepts,] <- eta[intercepts,] + beta.int
                delta <- theta[(pi + p + 1):(pi + p + q)]
                logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
                sdmat <- sdmat0 <- get.sdmat (theta, ptout = pi + p + q)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                     beta.int = beta.int, delta = delta, Lpenalty = Lpenalty,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
            else {
              theta2mu <- function(theta) {
                beta <- theta[1:p]
                delta <- theta[(p+1):(p+q)]
                eta <- beta * X
                eta <- contract.eta (eta, contract_eta)
                eta <- eta + X.offsets
                logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
                Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
                sdmat <- sdmat0 <- get.sdmat (theta, ptout = p+q)
                sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
                if (any(sdmat > 0))
                  mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
                else
                  mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
                mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
                validmu <- is.finite(mu) & (mu > 0 & mu < 1)

                list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                     beta.int = beta.int, delta = delta, Lpenalty = Lpenalty,
                     Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
              }
            }
          }
        }
      }
      else {
        if (control$fixL)  {
          logLvalues <- log(L0)
          if (any(intercepts)) {
            theta2mu <- function(theta) {
              beta.int <- theta[1:pi]
              beta <- theta[(pi+1):(pi+p)]
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              eta[intercepts,] <- eta[intercepts,] + beta.int
              deltao <- theta[(pi + p + 1):(pi + p + qo)]
              Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
              Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
              sdmat <- sdmat0 <- get.sdmat (theta, ptout = pi + p + qo)
              sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
              if (any(sdmat > 0))
                mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
              else
                mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
              mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                   beta.int = beta.int, deltao = deltao, Lpenalty = Lpenalty,
                   Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
            }
          }
          else {
            theta2mu <- function(theta) {
              beta <- theta[1:p]
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              deltao <- theta[(p + 1):(p + qo)]
              Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
              Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
              sdmat <- sdmat0 <- get.sdmat (theta, ptout = p + qo)
              sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
              if (any(sdmat > 0))
                mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
              else
                mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
              mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                   beta.int = beta.int, deltao = deltao, Lpenalty = Lpenalty,
                   Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
            }
          }
        }
        else {
          if (any(intercepts)) {
            theta2mu <- function(theta) {
              beta.int <- theta[1:pi]
              beta <- theta[(pi+1):(pi+p)]
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              eta[intercepts,] <- eta[intercepts,] + beta.int
              deltao <- theta[(pi + p + 1):(pi + p + qo)]
              delta <- theta[(pi + p + qo + 1):(pi + p + qo + q)]
              Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
              logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
              Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
              sdmat <- sdmat0 <- get.sdmat (theta, ptout = pi + p + qo + q)
              sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
              if (any(sdmat > 0))
                mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
              else
                mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
              mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                   beta.int = beta.int, deltao = deltao, delta = delta, Lpenalty = Lpenalty,
                   Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
            }
          }
          else {
            theta2mu <- function(theta) {
              beta <- theta[1:p]
              deltao <- theta[(p + 1):(p + qo)]
              delta <- theta[(p + qo + 1):(p + qo + q)]
              Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
              logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
              Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              sdmat <- sdmat0 <- get.sdmat (theta, ptout = p + qo + q)
              sdmat[pred.with.me,] <- abs(beta[beta.with.me]) * sdmat[pred.with.me,]
              if (any(sdmat > 0))
                mu <- exp(colSums(melinkinv(eta, sd = sdmat, log.p = TRUE)))
              else
                mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
              mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                   beta.int = beta.int, deltao = deltao, delta = delta, Lpenalty = Lpenalty,
                   Lovalues = Lovalues, logLvalues = logLvalues, sdmat = sdmat0)
            }
          }
        }
      }

    }

    # Define the objective function
    nlikefun <- function(theta) {
      mulist <- theta2mu (theta)
      res <- halfdev_i (mulist)

      out <- sum(res) +
        penalty.deltao (mulist$deltao) +
        penalty.delta (mulist$delta) +
        mulist$Lpenalty * (
          beta.penalty.factor * penalty.fun (mulist$beta) +
            if (control$penalize.intercepts) {
              int.penalty.factor * penalty.fun (Diff.beta.int(mulist$beta.int))
            }
          else {
            0
          }
        )

      return(out)
    }

    # Define the function likefun_i useful to get scores and thus sandwich variance estimates
    likefun_i <- function(theta) {
      mulist <- theta2mu (theta)
      res <- - halfdev_i (mulist)

      return(res)
    }

  })

}


beta.with.me.index <- function (contract_eta, pred.with.me) {
  # If a unique predictor in one column
  if (length(pred.with.me) == 1)
    return(pred.with.me)

  # A child function to return TRUE/FALSEs per predictor
  cfun <- function(j) {
    # Number of slopes for predictor 'j' appears in beta
    nbj <- sum(contract_eta == j)

    if (nbj > 1) {
      return(rep(FALSE, nbj)) # Factors have no measurement error term
    }
    else {
      pred.with.me[j]
    }

  }

  # For each predictor, return TRUEs/FALSEs
  beta.with.me <- lapply(1:length(pred.with.me),
                         FUN = cfun)
  beta.with.me <- unlist(beta.with.me, recursive = TRUE)
  beta.with.me <- which(beta.with.me)

  return(beta.with.me)

}
