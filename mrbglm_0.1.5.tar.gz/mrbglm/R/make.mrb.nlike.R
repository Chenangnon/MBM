
# A routine to generate negative log-likelihood function for mrb fit
# The log-likelihood for a unit with undefined expectation (succes probability) is log(1e-323)
make.mrb.nlikefun <- function() {
  expression({
    # transpose 'x' and 'x.offsets' for convenience
    X <- x
    if(is.matrix(X))
      X <- t(X)
    X.offsets <- x.offsets
    if(is.matrix(X.offsets))
      X.offsets <- t(X.offsets)

    # Penalty computation
    {
      beta.penalty.factor <- switch(control$penalty,
                               none = 0,
                               1/((nobs - p)^(control$nobs.power)))
      int.penalty.factor <- switch(control$penalty,
                                   none = 0,
                                   1/((nobs - pi)^(control$nobs.power)))

      penalty.fun <- switch(control$penalty,
                            ridge = function(beta, m = 1) {
                              m * sum(beta^2)
                            },
                            lasso = function(beta, m = 1) {
                              m * sum(abs(beta))
                            },
                            logf = function(beta, m = 1) {
                              - m * sum(.5 * beta - log(1 + exp(beta)))
                            },
                            none = function(beta, m = 1) {
                              0
                            })
      beta.int <- NULL # Used as a place holder for penalty computation when there is no intercept
      if (any(intercepts)) {
        int.tilde <- control$int.location
        if (is.null(int.tilde)) {
          int.tilde <- apply(X[intercepts, , drop = FALSE],
                             MARGIN = 1, FUN = median, na.rm = TRUE)
        }
        else {
          stopifnot(length(int.tilde) %in% c(1, sum(intercepts)))
        }

        Diff.beta.int <- function(beta.int) {
          if (is.null(beta.int))
            return(NULL)
          else
            beta.int - int.tilde
        }

      }
      else {
        Diff.beta.int <- function(beta.int) {
          return(NULL)
        }
      }

      if (control$penalize.delta & !all(c(control$fixLo, control$fixL))) {
        deltao.penalty <- if (!control$fixLo) start[(pi + p + 1):(pi + p + qo)] else 0
        if (any(is.infinite(deltao.penalty)))
          deltao.penalty[is.infinite(deltao.penalty)] <- sign(deltao.penalty[is.infinite(deltao.penalty)]) * rep(linkfun (1-(1e-16)), sum(is.infinite(deltao.penalty)))
        delta.penalty <- if (!control$fixL) start[(pi + p + qo + 1):(pi + p + qo + q)] else 0
        if (any(is.infinite(delta.penalty)))
          delta.penalty[is.infinite(delta.penalty)] <- sign(delta.penalty[is.infinite(delta.penalty)]) * rep(linkfun (1-(1e-16)), sum(is.infinite(delta.penalty)))

        penalty.deltao <- function (deltao, m = 10, npower = control$nobs.power) {
          if (any(is.infinite(c(deltao, deltao.penalty))))
            0
          else
            penalty.fun (deltao - deltao.penalty, m = m / (nobs - qo)^npower)
        }

        penalty.delta <- function (delta, m = 10, npower = control$nobs.power) {
          if (any(is.infinite(c(delta, delta.penalty))))
            0
          else
            penalty.fun (delta - delta.penalty, m = m / (nobs - q)^npower)
        }
      }
      else {
        penalty.deltao <- function (deltao) {
          0
        }

        penalty.delta <- function (delta) {
          0
        }
      }

      Lpenalty.fun <- switch(control$L.penalty,
                             none = function(logLvalue, Lovalue = 0) {
                               1
                             },
                             linear = function(logLvalue, Lovalue = 0) {
                               Lrange <- mean(exp(logLvalue), na.rm = TRUE) - mean(Lovalue, na.rm = TRUE)

                               Lrange
                             },
                             inv = function(logLvalue, Lovalue = 0) {
                               Lrange <- mean(exp(logLvalue), na.rm = TRUE) - mean(Lovalue, na.rm = TRUE)

                               1/(1-Lrange)
                             },
                             exp = function(logLvalue, Lovalue = 0) {
                               Lrange <- mean(exp(logLvalue), na.rm = TRUE) - mean(Lovalue, na.rm = TRUE)
                               (Lrange - exp(-1))/(1 - exp(-1))
                             })
    }

    # Log density of responses
    ddistrlog <- switch(control$criterion,
                        NLS = function(y, mu, validmu, weights) {
                          stats::dnorm(y[validmu], mean = mu[validmu] * weights,
                                       sd = 1, log = TRUE)
                        },
                        ML = function(y, mu, validmu, weights) {
                          stats::dbinom(y[validmu], size = weights, prob = mu[validmu], log = TRUE)
                        })

    # Half deviance per individual observation
    halfdev_i <- function(mulist) {
      res <- numeric(nobs) + log(1e-323)
      if (length(weights) > 1 & !all(mulist$validmu))
        weights <- weights[mulist$validmu]

      res[mulist$validmu] <- ddistrlog (y = y, mu = mulist$mu,
                                        validmu = mulist$validmu,
                                        weights = weights)
      if (!all(validsweights) & length(sample.weights) > 1) {
        sample.weights <- sample.weights[validsweights]
        res <- res[validsweights]
      }

      - res * sample.weights
    }

    # Define a map from the parameters vector to the expectations of the responses (success probabilities)
    if (control$fixLo) {
      Lovalues <- Lo0
      if (all(Lovalues == 0)) {
        if (control$fixL) {
          logLvalues <- log(L0)
          Lpenalty <- Lpenalty.fun(logLvalues)
          if (any(intercepts)) {
            theta2mu <- function(theta) {
              beta.int <- theta[1:pi]
              beta <- theta[(pi+1):(pi+p)]
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              eta[intercepts,] <- eta[intercepts,] + beta.int
              mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta, beta.int = beta.int,
                   Lpenalty = Lpenalty,
                   Lovalues = Lovalues, logLvalues = logLvalues)
            }
          }
          else {
            theta2mu <- function(theta) {
              beta <- theta[1:p]
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta, beta.int = beta.int,
                   Lpenalty = Lpenalty,
                   Lovalues = Lovalues, logLvalues = logLvalues)
            }
          }
        }
        else {
          if (any(intercepts)) {
            theta2mu <- function(theta) {
              beta.int <- theta[1:pi]
              beta <- theta[(pi+1):(pi+p)]
              delta <- theta[(pi + p + 1):(pi + p + q)]
              logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
              Lpenalty <- Lpenalty.fun(logLvalues)
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              eta[intercepts,] <- eta[intercepts,] + beta.int
              mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                   beta.int = beta.int, delta = delta,
                   Lpenalty = Lpenalty,
                   Lovalues = Lovalues, logLvalues = logLvalues)
            }
          }
          else {
            theta2mu <- function(theta) {
              beta <- theta[1:p]
              delta <- theta[(p+1):(p+q)]
              logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
              Lpenalty <- Lpenalty.fun(logLvalues)
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              mu <- exp(logLvalues + colSums(linkinv(eta, log.p = TRUE)))
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                   beta.int = beta.int, delta = delta,
                   Lpenalty = Lpenalty,
                   Lovalues = Lovalues, logLvalues = logLvalues)
            }
          }
        }
      }
      else {
        if (control$fixL)  {
          logLvalues <- log(L0)
          Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)

          if (any(intercepts)) {

            theta2mu <- function(theta) {
              beta.int <- theta[1:pi]
              beta <- theta[(pi+1):(pi+p)]
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              eta[intercepts,] <- eta[intercepts,] + beta.int
              mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
              mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta, beta.int = beta.int,
                   Lovalues = Lovalues, logLvalues = logLvalues)
            }
          }
          else {
            theta2mu <- function(theta) {
              beta <- theta[1:p]
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
              mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta, beta.int = beta.int,
                   Lovalues = Lovalues, logLvalues = logLvalues)
            }
          }
        }
        else {
          if (any(intercepts)) {
            theta2mu <- function(theta) {
              beta.int <- theta[1:pi]
              beta <- theta[(pi+1):(pi+p)]
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              eta[intercepts,] <- eta[intercepts,] + beta.int
              delta <- theta[(pi + p + 1):(pi + p + q)]
              logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
              Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
              mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
              mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                   beta.int = beta.int, delta = delta, Lpenalty = Lpenalty,
                   Lovalues = Lovalues, logLvalues = logLvalues)
            }
          }
          else {
            theta2mu <- function(theta) {
              beta <- theta[1:p]
              delta <- theta[(p+1):(p+q)]
              logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
              Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
              eta <- beta * X
              eta <- contract.eta (eta, contract_eta)
              eta <- eta + X.offsets
              mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
              mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
              validmu <- is.finite(mu) & (mu > 0 & mu < 1)

              list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                   beta.int = beta.int, delta = delta, Lpenalty = Lpenalty,
                   Lovalues = Lovalues, logLvalues = logLvalues)
            }
          }
        }
      }
    }
    else {
      if (control$fixL)  {
        logLvalues <- log(L0)
        if (any(intercepts)) {
          theta2mu <- function(theta) {
            beta.int <- theta[1:pi]
            beta <- theta[(pi+1):(pi+p)]
            eta <- beta * X
            eta <- contract.eta (eta, contract_eta)
            eta <- eta + X.offsets
            eta[intercepts,] <- eta[intercepts,] + beta.int
            deltao <- theta[(pi + p + 1):(pi + p + qo)]
            Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
            Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
            mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
            mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
            validmu <- is.finite(mu) & (mu > 0 & mu < 1)

            list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                 beta.int = beta.int, deltao = deltao, Lpenalty = Lpenalty,
                 Lovalues = Lovalues, logLvalues = logLvalues)
          }
        }
        else {
          theta2mu <- function(theta) {
            beta <- theta[1:p]
            eta <- beta * X
            eta <- contract.eta (eta, contract_eta)
            eta <- eta + X.offsets
            deltao <- theta[(p + 1):(p + qo)]
            Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
            Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
            mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
            mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
            validmu <- is.finite(mu) & (mu > 0 & mu < 1)

            list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                 beta.int = beta.int, deltao = deltao, Lpenalty = Lpenalty,
                 Lovalues = Lovalues, logLvalues = logLvalues)
          }
        }
      }
      else {
        if (any(intercepts)) {
          theta2mu <- function(theta) {
            beta.int <- theta[1:pi]
            beta <- theta[(pi+1):(pi+p)]
            eta <- beta * X
            eta <- contract.eta (eta, contract_eta)
            eta <- eta + X.offsets
            eta[intercepts,] <- eta[intercepts,] + beta.int
            deltao <- theta[(pi + p + 1):(pi + p + qo)]
            delta <- theta[(pi + p + qo + 1):(pi + p + qo + q)]
            Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
            logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
            Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
            mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
            mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
            validmu <- is.finite(mu) & (mu > 0 & mu < 1)

            list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                 beta.int = beta.int, deltao = deltao, delta = delta, Lpenalty = Lpenalty,
                 Lovalues = Lovalues, logLvalues = logLvalues)
          }
        }
        else {
          theta2mu <- function(theta) {
            beta <- theta[1:p]
            deltao <- theta[(p + 1):(p + qo)]
            delta <- theta[(p + qo + 1):(p + qo + q)]
            Lovalues <- linkinv(minp.offset + c(zminp %*% deltao), log.p = FALSE)
            logLvalues <- linkinv(maxp.offset + c(zmaxp %*% delta), log.p = TRUE)
            Lpenalty <- Lpenalty.fun(logLvalues, Lovalues)
            eta <- beta * X
            eta <- contract.eta (eta, contract_eta)
            eta <- eta + X.offsets
            mu <- exp(colSums(linkinv(eta, log.p = TRUE)))
            mu <- exp(logLvalues) * (Lovalues + (1 - Lovalues) *  mu)
            validmu <- is.finite(mu) & (mu > 0 & mu < 1)

            list(mu = mu, validmu = validmu, eta = eta, beta = beta,
                 beta.int = beta.int, deltao = deltao, delta = delta, Lpenalty = Lpenalty,
                 Lovalues = Lovalues, logLvalues = logLvalues)
          }

        }
      }
    }

    # Define the objective function
    nlikefun <- function(theta) {
      mulist <- theta2mu (theta)
      res <- halfdev_i (mulist)
      Lpenaltyval <- mulist$Lpenalty * (
        beta.penalty.factor * penalty.fun (mulist$beta) +
          if (control$penalize.intercepts) {
            int.penalty.factor * penalty.fun (Diff.beta.int(mulist$beta.int))
          }
        else {
          0
        }
      )

      out <- sum(res) +
        penalty.deltao (mulist$deltao) +
        penalty.delta (mulist$delta) + Lpenaltyval

#      cat("res = ", sum(res))
#      cat("Lpenalty = ", Lpenaltyval)
#      cat("out = ", out)

      return(out)
    }

    # Define the function likefun_i useful to get scores and thus sandwich variance estimates
    likefun_i <- function(theta) {
      mulist <- theta2mu (theta)
      res <- - halfdev_i (mulist)

      return(res)
    }

  })
}

# Function to contract eta so that a factor has one linear predictor
# Also, for grouped covariates, ensure one linear predictor per group
contract.eta <- function (eta, contract_eta) {

  # No contraction needed
  if (missing(contract_eta))
    return(eta)

  # number of groups
  covgroup <- unique(contract_eta)
  ngroups <- length(covgroup)

  # If each row in eta is a group, no contraction needed
  if (ngroups == length(contract_eta))
    return(eta)

  # A child function to return one row per group
  cfun <- function(j) {

    contract_etaj <- which(contract_eta == j)
    etaj <- eta[contract_etaj,]

    if (length(contract_etaj) == 1) {
      # If one row group

      return(etaj)

    }
    else {
      # If more row in the group

      return(colSums(etaj))

    }

  }

  # For each group, return one row
  out <- sapply(covgroup, FUN = cfun)

  if (ngroups == 1)
    return(out)
  else
    return(t(out))

}
