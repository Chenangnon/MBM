#'
#' Wrapper to use MASS::mle or bbmle:mle2 to optimize
#'
mle.optim <- function () {

}
