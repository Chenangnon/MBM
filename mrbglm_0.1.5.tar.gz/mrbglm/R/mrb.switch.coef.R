# Re-ordering the coefficients and the related elements of a 'mrbglm' object
# Internal, not exported
mrb.switch.coef <- function(object) {
  # Number of intercepts
  pi <- sum(object$intercepts)

  # If no intercept
  if (pi == 0) {
    return(object)
  }

  # Number of predictors and coefficients
  nbcovs <- length(object$intercepts)
  n.coefs <- pi + object$p

  # Number of slopes per predictor (only factors can have more than one)
  nb.slp.cov <- as.numeric(table(object$contract_eta))
  # maximum of nb.slp.cov
  nmax <- max(nb.slp.cov)

  switch(object$order.intercepts,
         mixed = {
           labels <- 1:n.coefs
           label.int <- label.x <- NULL
           j1 <- 1

           if (nmax == 1) { # If one slope per predictor

             for (j in 1:object$p) {
               if (object$intercepts[j]) {
                 label.int <- c(label.int, labels[j1])
                 label.x <- c(label.x, labels[j1 + 1])
                 j1 <- j1 + 2
               }
               else {
                 label.x <- c(label.x, labels[j1])
                 j1 <- j1 + 1
               }
             }

           }
           else {

             for (j in 1:nbcovs) {
               if (object$intercepts[j]) {
                 label.int <- c(label.int,
                                labels[j1])
                 label.x <- c(label.x,
                              labels[(j1 + 1):(j1 + nb.slp.cov[j])])
                 j1 <- j1 + nb.slp.cov[j] + 1
               }
               else {
                 label.x <- c(label.x,
                              labels[j1:(j1 + nb.slp.cov[j] - 1)])
                 j1 <- j1 + nb.slp.cov[j]
               }
             }

           }
           ord.labels <- c(label.int, label.x)
           object$order.intercepts <- 'separate'
         },
         separate = {
           label.int <- numeric(nbcovs) + NA
           label.int[object$intercepts] <- 1:pi
           label.x <- (pi+1):n.coefs

           if (nmax == 1) { # If one slope per predictor
             ord.labels <- c(rbind(label.int,
                                   label.x))
           }
           else {
             csum.nb.slp <- cumsum(nb.slp.cov)

             ord.label1 <- c(label.int[1],
                             label.x[1:csum.nb.slp[1]])

             if (all(nb.slp.cov[-1] == 1) & FALSE) {
               # If all the remaining predictors have only one slope each
               ord.labels <- c(rbind(label.int[-1],
                                     label.x[-(1:csum.nb.slp[1])]))
             }
             else {
               ord.labels <- lapply(2:nbcovs, FUN = function(j) {
                 label.intj <- label.int[j]
                 label.xj <- label.x[(csum.nb.slp[j-1] + 1):csum.nb.slp[j]]

                 if (nb.slp.cov[j] < nmax)
                   label.xj <- c(label.xj, rep(NA, nmax - nb.slp.cov[j]))

                 return(c(label.intj, label.xj))
               })

               ord.labels <- unlist(ord.labels, recursive = TRUE)
             }

             ord.labels <- c(ord.label1, ord.labels)
           }

           ord.labels <- ord.labels[!is.na(ord.labels)]

           object$order.intercepts <- 'mixed'
         }
  )
  nmx <- names(object$coefficients)[ord.labels]
  object$coefficients <- object$coefficients[ord.labels]
  names(object$coefficients) <- nmx
  if (is.matrix(object$hessian)) {
    object$hessian[1:n.coefs, 1:n.coefs] <- object$hessian[ord.labels,
                                                           ord.labels]
  }
  if (is.matrix(object$Rmat)) {
    object$Rmat[1:n.coefs, 1:n.coefs] <- object$Rmat[ord.labels,
                                                     ord.labels]
    nmmat <- colnames(object$Rmat)
    nmmat[1:n.coefs] <- nmx
    dimnames(object$Rmat) <- list(nmmat, nmmat)
    if (is.matrix(object$hessian)) {
      dimnames(object$hessian) <- list(nmmat, nmmat)
    }
  }
  return(object)
}
