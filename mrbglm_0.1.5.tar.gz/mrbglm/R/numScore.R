# Numerical score function
#
#' @importFrom numDeriv jacobian
#
numScore <- function (theta, likefun_i, method = 'Richardson',
                      side = NULL, method.args = list()) {
  scores <- numDeriv::jacobian (func = likefun_i,
                                x = theta,
                                method = method,
                                side = side, method.args = method.args)

  return(scores)
}

# Numerical hessian function
#
#' @importFrom numDeriv hessian
#
numHessian <- function (theta, nlikefun, method = 'Richardson',
                      side = NULL, method.args = list()) {
  hessian <- numDeriv::hessian (func = nlikefun,
                                x = theta,
                                method = method,
                                method.args = method.args)

  return(hessian)
}
