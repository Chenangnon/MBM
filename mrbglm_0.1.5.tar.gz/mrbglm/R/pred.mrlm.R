
# binomial response probabilities
pred.mrb <- function(beta, x, intercepts, weights = 1, # interest covarying events/exposures
                     delta = 36, z = 1, offset = 0, # logit asymptotic limit of the response success prob.
                     linkinv = stats::plogis) {
  #-------- Covariates and regression coefficients ---------#
  x <- as.matrix(x)
  nobs <- NROW(x)
  if (length(weights) > 1) {
    if (length(weights)  != nobs)
      stop("inconsistent sizes of arguments 'x' and 'weights'")
  }
  p <- NCOL(x)
  if(length(nmbeta <- names(beta))) {
    beta <- as.vector(beta)
    nmbeta -> names(beta)
  }
  else {
    beta <- as.vector(beta)
  }
  n.coefs <- length(beta)

  if (!missing(intercepts)) {
    return(pred.mrb.pi(x = x, intercepts = intercepts > 0, beta = beta,
                      weights = weights, z = z, delta = delta,
                      offset = offset, linkinv = linkinv,
                      nobs = nobs, p = p, n.coefs = n.coefs))
  }

  if (n.coefs == p) {
    full.intercepts <- FALSE
  }
  else if (n.coefs == (2 * p)) {
    full.intercepts <- TRUE
    x.intercepts <- rep(1, nobs)
    beta.int <- beta[seq(1, n.coefs - 1, 2)]
    beta <- beta[seq(2, n.coefs, 2)]
  }
  else if (n.coefs == (2 * (p - 1))) {
    full.intercepts <- TRUE
    x.intercepts <- x[,1]
    p <- p - 1
    x <- x[,-1, drop = FALSE]
    beta.int <- beta[seq(1, n.coefs - 1, 2)]
    beta <- beta[seq(2, n.coefs, 2)]
  }
  else
    stop("inconsistent sizes of arguments 'beta' and 'x'")

  #-------- Asymptotic limit of the response success prob. ---------#
  if (!missing(z)) {
    z <- as.matrix(z)
    q <- NCOL(z)
    if (length(delta) != q)
      stop("inconsistent sizes of arguments 'delta' and 'z'")
  }
  delta <- as.vector(delta)
  mu <- linkinv(offset + c(z %*% delta), log.p = TRUE)

  #-------- Response success prob. ---------------------------------#
  if (!full.intercepts) {
    eta <- beta * t(x)
    mu <-  exp(mu + colSums(linkinv(eta, log.p = TRUE)))
  }
  else {
    eta <- outer(beta.int, x.intercepts)
    eta <- eta + beta * t(x)
    mu <-  exp(mu + colSums(linkinv(eta, log.p = TRUE)))
  }
  return(mu * weights)
}

pred.mrb.pi <- function(beta, x, intercepts, weights = 1, # interest covarying events/exposures
                     delta = 36, z = 1, offset = 0, # logit asymptotic limit of the response success prob.
                     nobs = NROW(x), p = NCOL(x), n.coefs,
                     linkinv = stats::plogis) {
  #-------- Covariates and regression coefficients ---------#
  if (length(intercepts) != p) {
    if (length(intercepts) == 1) {
      intercepts <- rep(intercepts[1], p)
    }
    else
      stop("inconsistent arguments 'x', 'intercepts'")
  }
  pi <- sum(intercepts)
  full.intercepts <- pi > 0
  zero.x.var <- apply(x, MARGIN = 2, var)
  zero.x.var[is.na(zero.x.var)] <- 0
  zero.x.var <- zero.x.var == 0
  if (!full.intercepts) {
    if (n.coefs == p) {
      x.intercepts <- 1
    }
    else if (n.coefs == p - 1) {
      #zero.x.var <- apply(x, MARGIN = 2, var) == 0
      if (sum(zero.x.var) == 1) {
        if (NROW(x) > 1)
          warning(paste0("removing a constant columns from 'x': ",
                         paste((1:p)[zero.x.var], collapse = ', '), "."))
        x.intercepts <- x[,zero.x.var, drop = FALSE]
        x <- x[,!zero.x.var, drop = FALSE]
        p <- p - 1
      }
      else {
        stop("inconsistent arguments 'x', 'intercepts' and 'beta'")
      }
    }
    else
      stop("inconsistent arguments 'x', 'intercepts' and 'beta'")
  }
  else {
    if (n.coefs == p + pi) {
      x.intercepts <- 1
      if (any(zero.x.var) & NROW(x) > 1) {
        warning(paste0("constant columns in 'x' declared as non-intercept: ",
                       paste((1:p)[zero.x.var], collapse = ', '), "."))
      }
    }
    else if (n.coefs == p + pi - 1) {
      if (sum(zero.x.var) == 1) {
        if (NROW(x) > 1)
          warning(paste0("removing a constant columns from 'x': ",
                         paste((1:p)[zero.x.var], collapse = ', '), "."))
        x.intercepts <- x[,zero.x.var, drop = FALSE]
        x <- x[,!zero.x.var, drop = FALSE]
        p <- p - 1
      }
      else {
        stop("inconsistent arguments 'x', 'intercepts' and 'beta'")
      }
    }
    else {
      stop("inconsistent arguments 'x', 'intercepts' and 'beta'")
    }
  }

  #-------- Asymptotic limit of the response success prob. ---------#
  if (!missing(z)) {
    z <- as.matrix(z)
    q <- NCOL(z)
    if (length(delta) != q)
      stop("inconsistent sizes of arguments 'delta' and 'z'")
  }
  else {
    q <- 1
  }
  delta <- as.vector(delta)
  mu <- linkinv(offset + c(z %*% delta), log.p = TRUE)

  #-------- Response success prob. ---------------------------------#
  if (!full.intercepts) {
    eta <- beta * t(x)
    mu <-  exp(mu + colSums(linkinv(eta, log.p = TRUE)))
  }
  else {
    if (!all(intercepts)) {
      cintercepts <- cumsum(intercepts)
      eta <- sapply(1:p, FUN = function(j) {
        j1 <- j + cintercepts[j]
        if (intercepts[j])
          beta[j1-1] * x.intercepts + beta[j1] * x[,j]
        else
          beta[j1] * x[,j]
      })
      mu <-  exp(mu + rowSums(linkinv(eta, log.p = TRUE)))
    }
    else {
      beta.int <- beta[seq(1, n.coefs - 1, 2)]
      beta <- beta[seq(2, n.coefs, 2)]
      eta <- if (length(x.intercepts) > 1)
        outer(beta.int, x.intercepts)
      else beta.int
      eta <- eta + beta * t(x)
      mu <-  exp(mu + colSums(linkinv(eta, log.p = TRUE)))
    }
  }
  return(mu * weights)
}
