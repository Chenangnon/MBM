#'
#' Predict Method for MIB Model Fits
#'
#' Obtains predictions and optionally estimates standard errors of those
#' predictions from a fitted MIB model object. Measurement errors are not
#' included in the computations, even if present: the predictions are for
#' error-free covariate values.
#'
#' @param object a fitted object of class inheriting from "mibglm".
#'
#' @param newdata optionally, a data frame in which to look for variables with
#' which to predict. If omitted, the variables used during fitting are re-used.
#'
#' @param type the type of prediction required. The default \code{"prob"} is on
#' the scale of the success probability of the response variable; the alternative
#' \code{"response"} is on the scale of the response (this differs from
#' \code{"prob"} only if the response is binomial but not just binary). The
#' option \code{"link"} gives predictions on the scale of the linear predictors
#' (i.e. the predictions are log-odds (probabilities on logit scale).
#'
#' @param se.fit ogical switch indicating if standard errors are required.
#' Not yet implemented.
#'
#' @param na.action function determining what should be done with missing values
#' in \code{newdata}. The default is to predict \code{NA}.
#'
#' @param ... further arguments passed to or from other methods.
#'
#' @details
#' If \code{newdata} is omitted the predictions are based on the data used for the fit.
#' In that case how cases with missing values in the original fit is determined
#' by the \code{na.action} argument of that fit. If \code{na.action = na.omit}
#' omitted cases will not appear in the residuals, whereas if
#' \code{na.action = na.exclude} they will appear (in predictions and standard
#' errors), with residual value \code{NA}.
#'
#' When \code{object} has non zero measurement error components, they are
#' ignored by \code{predict.mibglm}. As a result, for such an \code{object},
#' the result of \code{predict(object)} will be different from \code{object$mu}
#' which accounts for measurement errors: \code{object$mu} assumes that the
#' predictors the predictions are being computed for are error-prone whereas
#' \code{predict(object)} assumes the predictor values are error-free.
#'
#' @return If \code{se.fit = FALSE}, a vector of predictions.
#'
#' If \code{se.fit = TRUE}, a list with components:
#' \item{fit}{Predictions, as for \code{se.fit = FALSE}.}
#' \item{se.fit}{Estimated standard errors.}
#'
#' @export predict.mibglm
#' @exportS3Method predict mibglm
#'
#' @examples
#' ## Simulate some data
#' library(mrbglm)
#' set.seed(167)
#' mrbdata = sim.mrb (beta = c(-2, -3),
#'                    x = cbind(x1 = runif(1000, min = -5, max = 10),
#'                              x2 = runif(1000, min = -5, max = 10)),
#'                    delta = qlogis(.6))$data[,c("y", "x1", "x2")]
#'
#' head (mrbdata)
#'
#' ## Fit a model with a maximum success probability (default)
#' MRBfit1 = glm.mib (y ~ x1 + x2,
#'                    data = mrbdata)
#'
#' ## Predict the response for observations 1,3,5,7,9,11
#' predict(MRBfit1, newdata = mrbdata[seq(1, 11, 2),])
#'
#' MRBfit1$mu[seq(1, 11, 2)]
#'

predict.mibglm <- function (object,
                            newdata = NULL,
                            type = c("prob", "response", "link", "terms"),
                            se.fit = FALSE,
                            na.action = na.pass, ...) {
  type <- match.arg(type)
  if (!(type %in% c("response", "prob", "link"))) {
    stop("only type = 'response', 'prob' or 'link' are currently available ")
  }
  na.act <- object$na.action
  object$na.action <- NULL
  if (!se.fit) {
    if (missing(newdata) & !inherits(object, "memib.fit")) {
      pred <- switch(type,
                     prob = object$mu,
                     response = object$fitted.values,
                     link = object$linkfun (object$mu))
      if (!is.null(na.act))
        pred <- napredict(na.act, pred)
    }
    else {
      if (missing(newdata))
        newdata <- object$data

      if (object$qo == 0) {
        Lo <- 0
      }
      else if (length(object$Lo.values) == 1) {
        Lo <- object$Lo.values
      }
      else {
        minp <- model.frame(object$minp.formula, data = newdata)
        if (NROW(minp) == 0)
          Lo <- object$Lo.values[1]
        else {
          minp <- model.matrix(minp, data = newdata,
                               na.action = na.action)
          minp <- c(object$Lo.coefs %*% t(minp))
          Lo <- object$linkinv (minp)
        }
      }

      if (object$q == 0) {
        L <- 1
      }
      else if (length(object$L.values) == 1) {
        L <- object$L.values
      }
      else {
        maxp <- model.frame(object$maxp.formula, data = newdata)
        if (NROW(maxp) == 0)
          L <- object$L.values[1]
        else {
          maxp <- model.matrix(maxp, data = newdata,
                               na.action = na.action)
          maxp <- c(object$L.coefs %*% t(maxp))
          L <- object$linkinv (maxp)
        }
      }

      xf <- model.frame(as.formula(object$formula[-2]), data = newdata)


      offset <- model.offset(xf)

      offset <- as.vector(model.offset(xf))
      if (!is.null(offset)) {
        if (length(offset) != NROW(xf))
          stop(gettextf("number of offsets is %d should equal %d (number of observations)",
                        length(offset), NROW(xf)), domain = NA)
      }
      else {
        offset <- 0
      }

      if (attr(attr(xf,"terms"),"intercept"))
        xf <- model.matrix(xf, data = newdata,
                           na.action = na.action)[,-1]
      else
        xf <- model.matrix(xf, data = newdata,
                           na.action = na.action)

      pi <- sum(object$intercept)
      if (pi > 0) {
        beta <- object$coefficients

        beta.int <- beta[1:pi]
        beta <- beta[(pi+1):(pi+object$p)]

        eta <- offset + beta.int + c(xf %*% beta)
      }
      else {
        beta <- object$coefficients[1:object$p]
        eta <- offset + c(xf %*% beta)
      }

      mu <- exp(object$linkinv (eta, log.p = TRUE))
      mu <- L * (Lo + (1 - Lo) * mu)

      pred <- switch(type,
                     prob = mu,
                     response = mu * object$weights,
                     link = object$linkfun (mu))

      if (!is.null(na.act))
        pred <- napredict(na.act, pred)
    }
  }
  else {
    stop("'se.fit' not yet implemented")

    if (missing(newdata)) {
      newdata <- object$data
    }

    theta <- c(object$coefficients,
               object$Lo.coefs,
               object$L.coefs)

    if (object$qo == 0 & object$q == 0) {
      Lo <- 0
      L <- 0
    }
    else if (object$qo == 0) {
      Lo <- 0
      maxp <- model.frame(object$maxp.formula, data = newdata)
      if (NROW(maxp) == 0)
        L <- object$L.values[1]
      else {
        if (attr(attr(maxp,"terms"),"intercept"))
          maxp <- maxp[,-1]
      }

    }
    else if (object$q == 0) {
      L <- 0

    }
    else {
      minp <- model.frame(object$minp.formula, data = newdata)
      if (NROW(minp) == 0)
        Lo <- object$Lo.values[1]
      else {
        if (attr(attr(minp,"terms"),"intercept"))
          minp <- minp[,-1]
      }
      maxp <- model.frame(object$maxp.formula, data = newdata)
      if (NROW(maxp) == 0)
        L <- object$L.values[1]
      else {
        if (attr(attr(maxp,"terms"),"intercept"))
          maxp <- maxp[,-1]
      }

    }

    predfun <- function(theta) {



      if (length(object$Lo.values) == 1) {
        Lo <- object$Lo.values
      }
      else {

        Lo <- c(object$Lo.coefs %*% minp)
        Lo <- object$linkinv (Lo)

      }

      if (object$q == 0) {
        L <- 1
      }
      else if (length(object$L.values) == 1) {
        L <- object$L.values
      }
      else {

        L <- c(object$L.coefs %*% maxp)
        L <- object$linkinv (L)
      }
    }

    xf <- model.frame(as.formula(object$formula[-2]), data = newdata)

    offset <- model.offset(xf)

    offset <- as.vector(model.offset(xf))
    if (!is.null(offset)) {
      if (length(offset) != NROW(xf))
        stop(gettextf("number of offsets is %d should equal %d (number of observations)",
                      length(offset), NROW(xf)), domain = NA)
    }
    else {
      offset <- 0
    }

    if (attr(attr(xf,"terms"),"intercept"))
      xf <- model.matrix(xf, data = newdata,
                         na.action = na.action)[,-1]
    else
      xf <- model.matrix(xf, data = newdata,
                         na.action = na.action)

    pi <- sum(object$intercept)
    if (pi > 0) {
      beta <- object$coefficients

      beta.int <- beta[1:pi]
      beta <- beta[(pi+1):(pi+object$p)]

      eta <- offset + beta.int + c(xf %*% beta)
    }
    else {
      beta <- object$coefficients[1:object$p]
      eta <- offset + c(xf %*% beta)
    }
    mu <- exp(object$linkinv (eta, log.p = TRUE))
    mu <- L * (Lo + (1 - Lo) * mu)

    pred <- switch(type,
                   prob = mu,
                   response = mu * object$weights,
                   link = object$linkfun (mu))

    if (!is.null(na.act))
      pred <- napredict(na.act, pred)

    pred <- list(fit = fit, se.fit = se.fit, residual.scale = residual.scale)
  }

  pred
}
