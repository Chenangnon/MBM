#' Print a Multiplicative Risk Binomial Regression Model Fit
#'
#' Printing a quick summary of a Multiplicative Risk Binomial Regression Model Fit.
#' This is a method for class \code{mibglm}.
#'
#' @param x an object of class \code{"mibglm"}, typically, a result of a call to
#' \link{glm.mib}.
#'
#' @param digits the number of significant digits to use when printing.
#'
#' @param me logical, should a summary of measurement errors be printed, if any?
#'
#' @param ... further arguments passed to or from other methods.
#'
#' @return invisibly \code{x}, after printing the main features of the object.
#'
#' @exportS3Method print mibglm
#' @export print.mibglm
#'
#' @examples
#' # Example 1
#' set.seed(10)
#' mrbdata = sim.mrb (beta = c(1, -2),
#'                    x = cbind(x1 = runif(100, min = -10, max = 5),
#'                              x2 = runif(100, min = -5, max = 10)),
#'                    delta = qlogis(.66))$data
#'
#' MRBfit = glm.mib (y ~ x1 + x2, data = mrbdata)
#' MRBfit
#'

print.mibglm <- function (x,
                          digits = max(3L, getOption("digits") - 3L),
                          me = FALSE, ...) {
  cat("\nCall:  ", paste(deparse(x$call), sep = "\n", collapse = "\n"),
      "\n\n", sep = "")
  if (length(coef(x))) {
    cat("Regression coefficients")
    if (is.character(co <- x$contrasts))
      cat("  [contrasts: ", apply(cbind(names(co), co),
                                  1L, paste, collapse = "="), "]")
    cat(":\n")
    print.default(format(x$coefficients, digits = digits),
                  print.gap = 2, quote = FALSE)
  }
  else cat("No coefficients\n\n")

  if (length(x$L.coefs) > 1) {
    cat("\nLimit-probability model coefficients")
    cat(":\n")
    print.default(format(x$L.coefs, digits = digits),
                  print.gap = 2, quote = FALSE)
  }

  cat("\nSuccess probability limits")
  Lo <- x$Lo.values * x$L.values
  if (length(Lo) == 1 & length(x$L.values) == 1) {
    cat(": (")
    cat(format(c(Minimum = Lo), digits = digits))
    cat(",  ")
    cat(format(c(Maximum = x$L.values), digits = digits))
    cat(") ")
  }
  else {
    cat("\n     Minimum: ")
    if (all(Lo == Lo[1]))
      cat(format(c(Minimum = Lo[1]), digits = digits))
    else {
      cat("\n ")
      print.default(format(summary(Lo), digits = digits),
                    print.gap = 2, quote = FALSE)
    }
    cat("\n     Maximum: ")
    if (length(x$L.values) == 1)
      cat(format(c(Maximum = x$L.values), digits = digits))
    else {
      cat("\n ")
      print.default(format(summary(x$L.values), digits = digits),
                    print.gap = 2, quote = FALSE)
    }
  }

  if (inherits(x, "memrb.fit") & me) {
    cat("\n\nStandard deviation(s) of measurement error(s): ")
    cat("\n ")
    print.default(format(summary(x$me.mat), digits = digits),
                  print.gap = 2, quote = FALSE)
  }

  cat("\nDegrees of Freedom:", x$df.null, "Total (i.e. Null); ",
      x$df.residual, "Residual\n")
  if (nzchar(mess <- naprint(x$na.action)))
    cat("  (", mess, ")\n", sep = "")
  cat("Null Deviance:\t   ",
      format(signif(x$null.deviance, digits)),
      "\nResidual Deviance: ",
      format(signif(x$deviance, digits)),
      "\tAIC:", format(signif(x$aic, digits)))
  cat("\n")
  invisible(x)
}
