
#' @exportS3Method sandwich::estfun
estfun.mrbglm <- function (x, ...) {
  scores <- x$estfun
  if (is.null(scores)) {
    scores <- numScore(theta = x$optres$par, likefun_i = x$likefun_i)
  }

  colnames(scores) <- names(x$optres$par)

  return(scores)
}

#' @exportS3Method sandwich::bread
bread.mrbglm <- function (x, ...) {
  hess <- x$optres$hessian
  if (is.null(hess)) {
    hess <- numHessian(theta = x$optres$par, nlikefun = x$nlikefun)
  }

  dimnames(hess) <- list(names(x$optres$par), names(x$optres$par))

  return(hess)
}

