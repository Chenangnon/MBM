# Run a simulation experiment using glm.mrb
# Old function
sim.experiment <- function (n = 1000, B = 2000, p = 1,
                            beta = if (p == 1) c(2, -1)
                            else if (p == 2) c(2, -1, 1, -1.5)
                            else c(2, -1, 1, -1.5, 3, 0.5),
                            delta = qlogis(0.6),
                            meanlog1 = 0.9887002, sdlog1 = 0.7927336, shift1 = - 2.142344,
                            min2 = 0, max2 = 5,
                            mean3 = 2, sd3 = 1,
                            type = "basic", # no multicolinearity, distributions?s : NOT used now
                            link = "logit",
                            criterion = c('ML', "NLS"),
                            start.values = c("TRUE", "NULL"),
                            method.optim = "BFGS",
                            return.fits = FALSE,
                            fixL = FALSE,
                            Lstart = stats::plogis(delta),
                            seed = 167,
                            parallel = FALSE,
                            cl = if(parallel) parallel::getDefaultCluster(),
                            verbose = 0L) {
  ### Save the call
  mcall <- match.call()

  ### Check some arguments
  stopifnot(p %in% c(1,2,3))
  p <- unique(p)
  stopifnot(all(criterion %in% c('ML', "NLS")))
  criterion <- unique(criterion)
  stopifnot(all(start.values %in% c("TRUE", "NULL")))
  start.values <- unique(start.values)

  # Generate the first covariate
  if (!is.null(seed))
    set.seed(seed)
  x <- as.data.frame(cbind(x1 = rlnorm(n = n, meanlog = meanlog1,
                                       sdlog = sdlog1) +
                             shift1))
  if (length(p) == 1) {

    ### Check some arguments
    if(is.list(beta))
      beta <- beta$beta1
    stopifnot(is.numeric(beta))
    stopifnot(length(beta) == 2 * p)

    ### Generate additional covariate if p > 1, and set a model formula
    if (p == 3) {
      x$x2 <- runif(n = n, min = min2, max = max2)
      x$x3 <- rnorm(n = n, mean = mean3, sd = sd3)
      yformula <- y ~ x1 + x2 + x3
    }
    else if (p == 2) {
      x$x2 <- runif(n = n, min = min2, max = max2)
      yformula <- y ~ x1 + x2
    }
    else {
      yformula <- y ~ x1
    }

    simres <- t(matteSapply(1:B, FUN = sim.exp.b, beta = beta, x = x,
                            delta = delta, link = link,
                            yformula = yformula, Lstart = Lstart, fixL = fixL,
                            method.optim, verbose = verbose, cl = if (parallel) cl))

  }
  else {

  }

  nx <- 2*(p + 1)
  nz <- 2 * (!fixL) * ((!fixL) + 1)
  structure(list(Logistic = simres[,1:(nx + 2)],
                 TruestartML = simres[,(nx + 2 + 1):(2 * nx + nz + 4)],
                 TruestartNLS = simres[,(2 * nx + nz + 2 * 2 + 1):(3 * nx + 2 * nz + 6)],
                 CustomstartML = simres[,(3 * nx + 2 * nz + 3 * 2 + 1):(4 * nx + 3 * nz + 8)],
                 CustomstartNLS = simres[,(4 * nx + 3 * nz + 4 * 2 + 1):(5 * nx + 4 * nz + 10)],
                 n = n, B = B, p = p, beta = beta, delta = delta, x = x,
                 call = mcall),
            class = "mcexp")
}

sim.exp.b <- function(i, beta, x, delta, link,
                      yformula, Lstart, fixL, method.optim,
                      verbose = 0L) {
  if (verbose) {
    cat (paste0("Repetion b ", i, "."))
  }
  mrbdatai <- sim.mrb (beta = beta, x = x, intercepts = TRUE,
                       delta = delta, link = link)$data

  ### Standard logistic fit
  Stdlogit <- glm (yformula, data = mrbdatai, family = binomial(link))
  SStdlogit <- summary(Stdlogit)
  ResStdlogit <- c(Stdlogit$coefficients,
                   SStdlogit$coefficients[,2],
                   conv = Stdlogit$converged,
                   zero.hessian = sum(diag(Stdlogit$cov.scaled) == 0 |
                                        is.na(Stdlogit$cov.scaled)))
  ### ML-MRB fit with TRUE start
  res0 <- glm.mrb (yformula, data = mrbdatai, link = link,
                   start = c(beta, delta),
                   Lstart = if (fixL) Lstart,
                   control = list(fixL = fixL,
                                  method = method.optim))
  r0 <- extract.expres.i (res0, fixL)

  ### NLS-MRB fit with TRUE start
  res1 <- glm.mrb (yformula, data = mrbdatai, link = link,
                   start = c(beta, delta),
                   Lstart = if (fixL) Lstart,
                   control = list(fixL = fixL,
                                  criterion = 'NLS',
                                  method = method.optim))
  r1 <- extract.expres.i (res1, fixL)

  ### ML-MRB fit with NULL start
  res2 <- glm.mrb (yformula, data = mrbdatai, link = link,
                   Lstart = if (fixL) Lstart,
                   control = list(fixL = fixL,
                                  method = method.optim))
  r2 <- extract.expres.i (res2, fixL)

  ### NLS-MRB fit with NULL start
  res3 <- glm.mrb (yformula, data = mrbdatai, link = link,
                   Lstart = if (fixL) Lstart,
                   control = list(fixL = fixL,
                                  criterion = 'NLS',
                                  method = method.optim))
  r3 <- extract.expres.i (res3, fixL)

  c(ResStdlogit, r0, r1, r2, r3)
}

extract.expres.i <- function(res, fixL) {
  Sres <- summary(res)
  if (fixL)
    c(res$coefficients,
      Sres$coefficients[,2],
      conv = res$converged,
      zero.hessian = sum(diag(res$hessian) == 0))
  else
    c(res$coefficients, res$L.coefs, res$L.values,
      Sres$coefficients[,2], L = Sres$L[,2],
      conv = res$converged,
      zero.hessian = sum(diag(res$hessian) == 0))
}

colStats <- function(x, stat = max, ...) {
  if (is.data.frame(x))
    x <- as.matrix(x)
  if (!is.array(x) || length(dn <- dim(x)) < 2L)
    stop("'x' must be an array of at least two dimensions")
  apply(x, MARGIN = 2, FUN = stat, ...)
}

# Function to compute summary statistics
mySummary.mat <- function(object) {
  rbind(Mean = colMeans(object, na.rm = TRUE),
        Sd = colStats (object, stat = sd, na.rm = TRUE),
        Min = colStats (object, stat = min, na.rm = TRUE),
        Q1 = colStats (object, stat = quantile, na.rm = TRUE, prob = .25),
        Median = colStats (object, stat = median, na.rm = TRUE),
        Q3 = colStats (object, stat = quantile, na.rm = TRUE, prob = .75),
        Max = colStats (object, stat = max, na.rm = TRUE))
}
