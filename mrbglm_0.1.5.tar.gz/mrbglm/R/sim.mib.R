#' Simulate Data from a Multiplicative Intercept Binomial Model
#'
#' This function simulates data from a multiplicative intercept binomial (MIB) model,
#' i.e. a binomial regression model where the success probability of the target
#' event (\code{y}) is a simple product of two probabilities: one determined by
#' predictors (independent variables) and one representing the maximum probability
#' of the observing \code{y = 1}, given the available predictors.
# This model
# also extends to include a minimum probability for the response.
#'
#' @param x numeric \code{n} by \code{p} matrix of predictors that determine
#' the success probability of the response variable.
#'
#' @param beta numeric vector of regression coefficients. The vector \code{beta}
#' is a \code{p}-vector; or a \code{p+1}-vector where the first element
#' corresponds to an intercept.
#'
#' @param weights numeric \code{n}-vector of binomial weights for the observations to be
#' generated. For the binomial generalized linear model, each element of
#' \code{weights} refers to the number of trials per experimental/observational
#' unit. Defaults to \code{weights = 1} interpreted as a column of all ones.
#'
#' @param z numeric \code{n} by \code{q} matrix of covariates that determine
#' the maximum success probability of the binomial response variable. Defaults
#' to \code{z = 1} interpreted as a column of ones.
#'
#' @param delta numeric \code{q}-vector of coefficients for the multiplicative
#' intercept which defines the maximum success probability of the binomial
#' response variable. Defaults to \code{delta = 0} which corresponds to a
#' maximum probability of \code{0.5} if a symmetric link function is used.
#'
#' @param offset,maxp.offset numeric \code{n}-vectors of offsets in the linear
#' predictor for the binomial response variable and its maximum success probability
#' respectively. Default to zero code{offset = 0} and \code{maxp.offset = 0}
#' interpreted as columns of zeros.
#'
#' @param link character, the link function to be used to relate linear
#' predictors to probabilities. Defaults to \code{'logit'}. The alternative
#' is \code{'probit'}.
#'
#' @param yname optional character, name of the response column of the simulated dataset.
#'
#' @export sim.mib
#' @import stats
#'
#' @details
#' We consider a binomial regression model for a response variable \eqn{Y}
#' where the probability \eqn{u} of \eqn{Y = 1} is the product of a probability
#' determined by individual independent variables, and a limit probability,
#' \code{L}. In other words,
#' \eqn{u = \frac{1}{1 + \exp(-a_0))} * \frac{1}{1 + \exp(-\eta))}} where
#' \eqn{\eta = b_0 + b_1 x_1 + \cdots + a_p + b_p x_p}.
#'
#' This model assumes that in addition to the linear predictor \eqn{\eta}, the
#' probability of \eqn{Y = 1} is upper bounded by
#' \code{L}=\eqn{\frac{1}{1 + \exp(-a_0))}}.
#'
#' In practice, the limit probability \code{L} can be determined by some categorical
#' variables implying qualitative differences within the population.
#'
#'
#' @seealso See examples in \link{sim.mib} for multiplicative risk binomial models
#' which.
#'
#' See \link{glm.mib} for fitting a MIB model.
#'
# We describe here a motivating case study on mutations / protein bonding.
# ???
#'
#' @return A list with components:
#' \item{data}{a \code{data.frame} containing the simulated response (named
#' \code{y}), and the predictors in both \code{x} and \code{z}.}
#' \item{nobs,p,q}{numbers of observations, predictors for the success
#' probability, and predictors for the maximum probability value, respectively.}
#' \item{intercepts}{the corresponding argument used to simulate the dataset.}
#' \item{beta,delta}{the corresponding arguments used to simulate the dataset.}
#' \item{weights,offset,maxp.offset,link}{the corresponding arguments used to simulate the dataset.}
#' \item{mu}{vector of success probabilities for the observations.}
#'
#' @examples
#' # Example 1
#' set.seed(10)
#' mrbdata = sim.mib (beta = c(1, -1, -2),
#'                    x = cbind(x1 = runif(100, min = -10, max = 5),
#'                              x2 = runif(100, min = -5, max = 10)),
#'                    delta = qlogis(.66))$data
#'
#' head (mrbdata)
#' summary(mrbdata)
#'
#
sim.mib <- function (x,  # interest covarying events/exposures;
                    beta, offset = 0, weights = 1, # number of replications per observation unit
                    z = 1, delta = 0, maxp.offset = 0, # logit asymptotic limit of the response success prob.
                    link = "logit", yname = "y") {
  #-------- Link function ------------------------------------------#
  link <- stats::binomial(link = link)$link
  linkinv <- switch(link,
                    logit = stats::plogis,
                    stats::pnorm)

  #-------- Covariates and regression coefficients ---------#
  x <- as.matrix(x)
  nobs <- NROW(x)
  if (length(weights) > 1) {
    if (length(weights)  != nobs)
      stop("inconsistent sizes of arguments 'x' and 'weights'")
  }
  p <- NCOL(x)
  if(length(nmbeta <- names(beta))) {
    beta <- as.vector(beta)
    nmbeta -> names(beta)
  }
  else {
    beta <- as.vector(beta)
  }
  n.coefs <- length(beta)

  beta.int <- 0
  if (n.coefs == p) {
    intercept <- FALSE
    pi <- 0
  }
  else if (n.coefs == p + 1) {
    intercepts <- TRUE
    beta.int <- beta[1]
    beta <- beta[-1]
    pi <- 1
  }
  else
    stop("inconsistent sizes of arguments 'beta' and 'x'")
  zero.x.var <- apply(x, MARGIN = 2, var) == 0
  if (any(zero.x.var)) {
    warning(paste0("constant columns in 'x' not declared as intercept: ",
                   paste((1:p)[zero.x.var], collapse = ', '), "."))
  }

  #-------- Asymptotic limit of the response success prob. ---------#
  if (!missing(z)) {
    z <- as.matrix(z)
    q <- NCOL(z)
    if (length(delta) != q)
      stop("inconsistent sizes of arguments 'delta' and 'z'")
  }
  else {
    q <- 1
  }
  if(length(nmdelta <- names(delta))) {
    delta <- as.vector(delta)
    nmdelta -> names(delta)
  }
  else {
    delta <- as.vector(delta)
  }
  mu <- linkinv(maxp.offset + c(z %*% delta), log.p = TRUE)

  #-------- Response success prob. ---------------------------------#
  eta <- offset + beta.int + c(x %*% beta)
  mu <-  exp(mu + linkinv(eta, log.p = TRUE))

  #-------- Response ---------------------------------#
  y <- stats::rbinom(length(mu), size = weights, prob = mu)
  data <- data.frame(y, x, z)
  colnames(data)[1] <- yname
  list(data = data,
       nobs = nobs, p = p, q = q,
       intercepts = intercepts, pi = pi,
       beta = beta, beta.int = beta.int, delta = delta, mu = mu,
       weights = weights, offset = offset, maxp.offset = maxp.offset, link = link)
}
