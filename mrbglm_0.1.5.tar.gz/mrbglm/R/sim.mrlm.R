#' Simulate Data from a Multiplicative Risk Binomial Model
#'
#' This function simulates data from a multiplicative risk binomial (MRB) model,
#' i.e. a binomial regression model where the success probability of the target
#' event is a simple product of probabilities linked to individual independent
#' variables.
#'
#' @param x numeric \code{n} by \code{p} matrix of predictors that determine the success
#' probability of the response variable.
#'
#' @param intercepts logical \code{p}-vector, should the model include one
#' intercept per predictor? Setting \code{intercepts = TRUE} is interpreted as
#' \code{intercepts = rep(TRUE, p)}, and setting \code{intercepts = FALSE} is
#' likewise interpreted as \code{intercepts = rep(FALSE, p)}. If the argument
#' \code{intercepts} is not specified, \code{intercepts} is inferred from the
#' sizes of \code{beta} and \code{x}. Inconsistencies results in errors.
#'
#' @param beta numeric vector of regression coefficients. The vector \code{beta}
#' is a \code{p}-vector if the model only include one multiplicative intercept
#' which defines the maximum success probability of the binomial response
#' variable. For a model with one intercept per predictor, \code{beta} must
#' have \code{2p} elements. If only \code{pi < p} elements of \code{intercepts}
#' are \code{TRUE}, \code{beta} must have \code{p + pi} elements.
#'
#' The order of the coefficients in \code{beta} is assumed to be as follows.
#' When all predictors have intercepts, \code{beta = [a_1, b_1, a_2, b_2, ..., a_p, b_p]}
#' where \code{a_j} and \code{b_j} are the intercept and the slope for the
#' \code{j}th predictor. When a predictor is lacking an intercept, drop the
#' corresponding element from \code{beta}.
#'
#' @param weights numeric \code{n}-vector of binomial weights for the observations to be
#' generated. For the binomial generalized linear model, each element of
#' \code{weights} refers to the number of trials per experimental/observational
#' unit. Defaults to \code{weights = 1} interpreted as a column of all ones.
#'
#' @param z numeric \code{n} by \code{q} matrix of covariates that determine
#' the maximum success probability of the binomial response variable. Defaults
#' to \code{z = 1} interpreted as a column of ones.
#'
#' @param delta numeric \code{q}-vector of coefficients for the multiplicative
#' intercept which defines the maximum success probability of the binomial
#' response variable. Defaults to \code{delta = 0} which corresponds to a
#' maximum probability of \code{0.5} if a symmetric link function is used.
#'
#' @param maxp.offset numeric \code{n}-vector of offsets in the linear predictor for the
#' maximum success probability of the binomial response variable.
#' Defaults to \code{maxp.offset = 0} interpreted as a column of zeros.
#'
#' @param link character, the link function to be used to relate linear
#' predictors to probabilities. Defaults to \code{'logit'}. The alternative
#' is \code{'probit'}.
#'
#' @param yname optional character, name of the response column of the simulated dataset.
#'
#' @export sim.mrb
#' @import stats
#'
#' @details
#' We consider a binomial regression model for a response variable \eqn{Y}
#' where the probability \eqn{u} of \eqn{Y = 1} is the product of probabilities linked
#' to individual independent variables. In other words,
#' \eqn{u = \frac{1}{1 + \exp(-a_0))} * \frac{1}{1 + \exp(-a_1 - b_1 x_1))} * ... * \frac{1}{1 + \exp(-a_p - b_p x_p))}}.
#' This model assumes that each explanatory variable \eqn{x_j} (for \eqn{j = 1, ..., p})
#' determines a latent (unobserved) binary event \eqn{Z_j} which has success probability
#' \eqn{u_j = \frac{1}{1 + \exp(-a_j - b_j x_j))}}. Given all \eqn{Z_j}, the
#' observed binary response \eqn{Y} takes the value \eqn{Y = \prod_{j=1}^p Z_j}
#' with probability \eqn{L = \frac{1}{1 + \exp(-a_0))}} and the value \eqn{Y = 0}
#' with probability \eqn{1-L}.
#'
#' As background for comparison, the classic logistic regression relies on a
#' multiplicative model for the odds (ratio between the probability \eqn{u}
#' of \eqn{Y = 1} and the probability \eqn{1 - u} of \eqn{Y = 0}). In other
#' words, \eqn{\frac{u}{1 - u} = \exp(b_0) * \exp(b_1 x_1) * ... * \exp(b_p x_p) = \exp(b_0 + b_1 x_1 + ... + b_p x_p)}
#' where \eqn{x_j} is a covariate and \eqn{\exp(b_1 x_1)} is the associated odd.
#'
#' However, many studies target the effect of a treatment \eqn{X} on a binary
#' outcome \eqn{Y} on the multiplicative scale. For a situation where the interest
#' is on the relative risk associated to an exposure versus non-exposure,
#' Richardson et al. (2017) developed a "multiplicative effect model" (MEM) for
#' relative risks, which are ratios contrasting the probability of \eqn{Y = 1}
#' in treatment group \eqn{Z = z} versus the probability of \eqn{Y = 1}
#' in a baseline group \eqn{Z = z_0}. This applies only for binary exposures.
#' The authors also considered difference in risks contrasting \eqn{Z = z} with
#' \eqn{Z = z_0}. Yin et al. (2022) generalized this model to general treatments
#' and covariates.
#'
#' We consider here another situation where the interest remains on the risk
#' associated to a binary event \eqn{Z = 1} versus \eqn{Z = 0}.
#' The response \eqn{Y} is zero if \eqn{Z = 0}. However, we do not observe
#' \eqn{Z}. We rather observed a covariate \eqn{x} that stochastically
#' determines \eqn{Z}. In addition, the success probability \eqn{u} of
#' the response is upper bounded below a limit \eqn{L \leq 1}, which can
#' be considered as a multiplicative intercept. Using the logit link function
#' results in \eqn{u = \frac{1}{1 + exp(-a_0)} * \frac{1}{1 + exp(-a - b x)}}
#' where \eqn{a_0} is a real such that \eqn{L = \frac{1}{1 + exp(-a_0)}}, \eqn{a}
#' is an intercept that determines the probability of \eqn{Z = 1} when
#' \eqn{x = 0}, and \eqn{b} is the logit scale slope of \eqn{x}.
#'
#' The MRL model deals directly with absolute risks. The coefficient \code{b}
#' can here be written as \eqn{b = \frac{d}{d x} \log(\frac{u}{L-u})}.
#'
#' @seealso See examples in \link{biv.plogit.prod} for comparing product of odds
#' (i.e. additive logits) and product of risks (product of likelihoods/additive
#' log-likelihoods) in the bivariate case.
#'
#' See \link{glm.mrb} for fitting a MRB model.
#'
# We describe here a motivating case study on mutations / protein bonding.
# ???
#'
#' @return A list with components:
#' \item{data}{a \code{data.frame} containing the simulated response (named
#' \code{y}), and the predictors in both \code{x} and \code{z}.}
#' \item{nobs,p,q}{numbers of observations, predictors for the success
#' probability, and predictors for the maximum probability value, respectively.}
#' \item{intercepts}{the corresponding argument used to simulate the dataset.}
#' \item{beta,delta}{the corresponding arguments used to simulate the dataset.}
#' \item{weights,maxp.offset,link}{the corresponding arguments used to simulate the dataset.}
#' \item{mu}{vector of success probabilities for the observations.}
#'
#' @references
#' Yin, J., Markes, S., Richardson, T. S., & Wang, L. (2022). Multiplicative effect modelling: the general case. Biometrika, 109(2), 559-566.
#'
#' Richardson, T. S., Robins, J. M., & Wang, L. (2017). On modeling and estimation for the relative risk and risk difference. Journal of the American Statistical Association, 112(519), 1121-1130.
#'
#' @examples
#' # Example 1
#' set.seed(10)
#' mrbdata = sim.mrb (beta = c(1, -2),
#'                    x = cbind(x1 = runif(100, min = -10, max = 5),
#'                              x2 = runif(100, min = -5, max = 10)),
#'                    delta = qlogis(.66))$data
#'
#' head (mrbdata)
#' summary(mrbdata)
#'
#' # Example 2: adding an additional intercept for the second predictor
#' set.seed(10)
#' mrbdata1 = sim.mrb (beta = c(1, 0, -2), intercepts = c(FALSE, TRUE),
#'                    x = cbind(x1 = runif(100, min = -10, max = 5),
#'                              x2 = runif(100, min = -5, max = 10)),
#'                    delta = qlogis(.66))$data
#'
#' summary (mrbdata1) # Should be the same as in Example 1
#'                    # since the added intercept is zero.
#'
#
sim.mrb <- function(x, intercepts, # interest covarying events/exposures;
                    beta, weights = 1, # number of replications per observation unit
                    z = 1, delta = 0, maxp.offset = 0, # logit asymptotic limit of the response success prob.
                    link = "logit", yname = "y") {
  #-------- Link function ------------------------------------------#
  link <- stats::binomial(link = link)$link
  linkinv <- switch(link,
                    logit = stats::plogis,
                    stats::pnorm)

  #-------- Covariates and regression coefficients ---------#
  x <- as.matrix(x)
  nobs <- NROW(x)
  if (length(weights) > 1) {
    if (length(weights)  != nobs)
      stop("inconsistent sizes of arguments 'x' and 'weights'")
  }
  p <- NCOL(x)
  if(length(nmbeta <- names(beta))) {
    beta <- as.vector(beta)
    nmbeta -> names(beta)
  }
  else {
    beta <- as.vector(beta)
  }
  n.coefs <- length(beta)
  if (!missing(intercepts)) {
    return(sim.mrb.pi(x = x, intercepts = intercepts > 0, beta = beta,
                      weights = weights, z = z, delta = delta,
                      maxp.offset = maxp.offset, link = link, linkinv = linkinv,
                      nobs = nobs, p = p, n.coefs = n.coefs, yname = yname))
  }

  beta.int <- NULL
  if (n.coefs == p) {
    full.intercepts <- FALSE
    intercepts <- rep(FALSE, p)
    x.intercepts <- 1
    pi <- 0
  }
  else if (n.coefs == (2 * p)) {
    full.intercepts <- TRUE
    intercepts <- rep(TRUE, p)
    x.intercepts <- rep(1, nobs)
    beta.int <- beta[seq(1, n.coefs - 1, 2)]
    beta <- beta[seq(2, n.coefs, 2)]
    pi <- p
  }
  else if (n.coefs == (2 * (p - 1))) {
    full.intercepts <- TRUE
    intercepts <- rep(TRUE, p - 1)
    x.intercepts <- x[,1]
    p <- p - 1
    x <- x[,-1, drop = FALSE]
    beta.int <- beta[seq(1, n.coefs - 1, 2)]
    beta <- beta[seq(2, n.coefs, 2)]
    pi <- p
  }
  else
    stop("inconsistent sizes of arguments 'beta' and 'x'")
  zero.x.var <- apply(x, MARGIN = 2, var) == 0
  if (any(zero.x.var)) {
    warning(paste0("constant columns in 'x' not declared as intercept: ",
                   paste((1:p)[zero.x.var], collapse = ', '), "."))
  }

  #-------- Asymptotic limit of the response success prob. ---------#
  if (!missing(z)) {
    z <- as.matrix(z)
    q <- NCOL(z)
    if (length(delta) != q)
      stop("inconsistent sizes of arguments 'delta' and 'z'")
  }
  else {
    q <- 1
  }
  if(length(nmdelta <- names(delta))) {
    delta <- as.vector(delta)
    nmdelta -> names(delta)
  }
  else {
    delta <- as.vector(delta)
  }
  mu <- linkinv(maxp.offset + c(z %*% delta), log.p = TRUE)

  #-------- Response success prob. ---------------------------------#
  if (!full.intercepts) {
    eta <- beta * t(x)
    mu <-  exp(mu + colSums(linkinv(eta, log.p = TRUE)))
  }
  else {
    eta <- outer(beta.int, x.intercepts)
    eta <- eta + beta * t(x)
    mu <-  exp(mu + colSums(linkinv(eta, log.p = TRUE)))
  }
  y <- stats::rbinom(length(mu), size = weights, prob = mu)
  data <- data.frame(y, x, z)
  colnames(data)[1] <- yname
  list(data = data,
       nobs = nobs, p = p, q = q,
       intercepts = intercepts, pi = pi,
       beta = beta, beta.int = beta.int, delta = delta, mu = mu,
       weights = weights, maxp.offset = maxp.offset, link = link)
}

# The function when 'intercepts' is supplied
sim.mrb.pi <- function(x, intercepts, # interest covarying events/exposures;
                       beta, weights = 1, # number of replications per observation unit
                       z = 1, delta = 0, maxp.offset = 0, # logit asymptotic limit of the response success prob.
                       link = "logit", linkinv,
                       nobs = NROW(x), p = NCOL(x), n.coefs, yname = "y") {
  #-------- Link function ------------------------------------------#
  if (missing(linkinv)) {
    linkinv <- switch(link,
                      logit = stats::plogis,
                      stats::pnorm)
  }

  #-------- Covariates and regression coefficients ---------#
  if (length(intercepts) != p) {
    if (length(intercepts) == 1) {
      intercepts <- rep(intercepts[1], p)
    }
    else
      stop("inconsistent arguments 'x', 'intercepts'")
  }
  pi <- sum(intercepts)
  full.intercepts <- pi > 0
  zero.x.var <- apply(x, MARGIN = 2, var) == 0
  if (!full.intercepts) {
    if (n.coefs == p) {
      x.intercepts <- 1
    }
    else if (n.coefs == p - 1) {
      zero.x.var <- apply(x, MARGIN = 2, var) == 0
      if (sum(zero.x.var) == 1) {
        warning(paste0("removing a constant columns from 'x': ",
                       paste((1:p)[zero.x.var], collapse = ', '), "."))
        x.intercepts <- x[,zero.x.var, drop = FALSE]
        x <- x[,!zero.x.var, drop = FALSE]
        p <- p - 1
      }
      else {
        stop("inconsistent arguments 'x', 'intercepts' and 'beta'")
      }
    }
    else
      stop("inconsistent arguments 'x', 'intercepts' and 'beta'")
  }
  else {
    if (n.coefs == p + pi) {
      x.intercepts <- 1
      if (any(zero.x.var)) {
        warning(paste0("constant columns in 'x' declared as non-intercept: ",
                       paste((1:p)[zero.x.var], collapse = ', '), "."))
      }
    }
    else if (n.coefs == p + pi - 1) {
      if (sum(zero.x.var) == 1) {
        warning(paste0("removing a constant columns from 'x': ",
                       paste((1:p)[zero.x.var], collapse = ', '), "."))
        x.intercepts <- x[,zero.x.var, drop = FALSE]
        x <- x[,!zero.x.var, drop = FALSE]
        p <- p - 1
      }
      else {
        stop("inconsistent arguments 'x', 'intercepts' and 'beta'")
      }
    }
    else {
      stop("inconsistent arguments 'x', 'intercepts' and 'beta'")
    }
  }

  #-------- Asymptotic limit of the response success prob. ---------#
  if (!missing(z)) {
    z <- as.matrix(z)
    q <- NCOL(z)
    if (length(delta) != q)
      stop("inconsistent sizes of arguments 'delta' and 'z'")
  }
  else {
    q <- 1
  }
  if(length(nmdelta <- names(delta))) {
    delta <- as.vector(delta)
    nmdelta -> names(delta)
  }
  else {
    delta <- as.vector(delta)
  }
  mu <- linkinv(maxp.offset + c(z %*% delta), log.p = TRUE)

  #-------- Response success prob. ---------------------------------#
  beta.int <- NULL
  if (!full.intercepts) {
    eta <- beta * t(x)
    mu <-  exp(mu + colSums(linkinv(eta, log.p = TRUE)))
  }
  else {
    if (!all(intercepts)) {
      cintercepts <- cumsum(intercepts)
      eta <- sapply(1:p, FUN = function(j) {
        j1 <- j + cintercepts[j]
        if (intercepts[j])
          beta[j1-1] * x.intercepts + beta[j1] * x[,j]
        else
          beta[j1] * x[,j]
      })
      mu <-  exp(mu + rowSums(linkinv(eta, log.p = TRUE)))
      beta.int <- sapply(1:p, FUN = function(j) {
        if (intercepts[j]) {
          beta[cintercepts[j] + j - 1]
        }
        else
          NA
      })
    }
    else {
      beta.int <- beta[seq(1, n.coefs - 1, 2)]
      beta <- beta[seq(2, n.coefs, 2)]
      eta <- if (length(x.intercepts) > 1)
        outer(beta.int, x.intercepts)
      else beta.int
      eta <- eta + beta * t(x)
      mu <-  exp(mu + colSums(linkinv(eta, log.p = TRUE)))
    }
  }
  y <- stats::rbinom(length(mu), size = weights, prob = mu)
  data <- data.frame(y, x, z)
  colnames(data)[1] <- yname
  list(data = data,
       nobs = nobs, p = p, q = q,
       intercepts = intercepts, pi = pi,
       beta = beta, beta.int = beta.int, delta = delta, mu = mu,
       weights = weights, maxp.offset = maxp.offset, link = link)
}
