#' Extract Log-Likelihood
#'
#' Extract Log-Likelihood from a multiplicative risk/intercept binomial model fit.
#'
#' @exportS3Method logLik mrbglm
#' @export logLik.mrbglm
#' @aliases logLik.mrbglm
#' @aliases logLik.mibglm
#'
#' @param object any object from which a log-likelihood value, or a contribution to a log-likelihood value, can be extracted.
#' In the library \code{mrbglm}, objects of classes \code{mrbglm} and \code{mibglm}.
#'
#' @param ...  additional arguments passed to or from other methods. None is used for \code{mrbglm} objects.
#'
#' @examples
#' set.seed(167)
#' mrbdata = sim.mrb (beta = c(2, -2),
#'                    x = cbind(x1 = runif(1000, min = -10, max = 5),
#'                              x2 = runif(1000, min = -5, max = 10)),
#'                    delta = qlogis(.66))$data
#'
#' head (mrbdata)
#'
#' MRBfit1 = glm.mrb (y ~ x1 + x2, data = mrbdata)
#'
#' logLik(MRBfit1)
#'
logLik.mrbglm <- logLik.mrb.fit <- function(object, ...) {
  if (is.null(object$logLike))
    NA
  else
    structure(object$logLike,
              nobs = object$nobs,
              df = object$rank,
              class = 'logLik')
}

#' @exportS3Method nobs mrbglm
# @exportS3Method nobs mibglm
nobs.mrbglm <- function(object, ...) {
  object$nobs
}
nobs.mibglm <- nobs.mrbglm

#' @exportS3Method df.residual mrbglm
# @exportS3Method df.residual mibglm
df.residual.mrbglm <- function(object, ...) {
  object$df.residual
}
df.residual.mibglm <- df.residual.mrbglm

#' @exportS3Method coef mrbglm
# @exportS3Method coef mibglm
coef.mrbglm <- function(object, ...) {

  theta <-  c(object$coefficients,
              if(!object$control$fixLo)  object$Lo.coefs,
              if(!object$control$fixL)  object$L.coefs,
              object$me.coefs)

  return(theta)
}
coef.mibglm <- coef.mrbglm
