#' Summarizing a Multiplicative Risk Binomial Regression Model Fit
#'
#' Summary a Multiplicative Risk Binomial Regression Model Fit.
#' This is a method for class \code{mrbglm}.
#'
#' @exportS3Method summary mrbglm
#' @export summary.mrbglm
#' @import numDeriv
#'
#' @param object an object of class \code{"glm"}, tipically, a result of a call to \link{glm.mrb},
#'
#' @param order.intercepts a character, one of \code{'mixed'} and \code{'separate'}.
#' The choice \code{'mixed'} means that the vector of coefficients is arranged as
#' \code{beta = [a_1, b_1, a_2, b_2, ..., a_p, b_p]} where \code{a_j} and
#' \code{b_j} are the intercept and the slope for the \code{j}th predictor,
#' and when a predictor is lacking an intercept, the corresponding element is
#' dropped from this expression of \code{beta}. The choice \code{'separate'}
#' means that the vector of coefficients is arranged as
#' \code{beta = [a_1, a_2, ..., a_p, b_1, b_2, ..., b_p]}, and when a
#' predictor is lacking an intercept, the corresponding element is dropped.
#'
#' @param correlation, logical; if \code{TRUE}, the correlation matrix of the estimated parameters is returned and printed.
#'
#' @param symbolic.cor logical; if \code{TRUE}, print the correlations in a symbolic form (see \link{symnum}) rather than as numbers.
#'
#' @param rsquared.method character, indicating the preferred pseudo R squared statistic (defaults to Kullback–Leibler divergence based \eqn{R^2}, see argument \code{method} of function \link{rsquared} for available alternatives).
#'
#' @param ... further arguments passed to or from other methods.
#'
#' @return An object of class \code{"summary.mrbglm"}, which is a list with components:
#' \item{deviance.resid}{the \code{residual.deviance} components of \code{object}.}
#' \item{coefficients}{he matrix of coefficients, standard errors, z-values and p-values. Aliased coefficients are omitted.}
#' \item{aliased}{named logical vector showing if the original coefficients are aliased.}
#' \item{dispersion}{dispersion for the binomial family, \code{1}.}
#' \item{df}{a 3-vector of the rank of the model and the number of residual degrees of freedom, plus number of coefficients (including aliased ones).}
#' \item{cov.scaled}{the estimated covariance matrix of the estimated model parameters.}
#' \item{cov.unscaled}{an aliase for \code{cov.scaled}.}
#' \item{correlation}{(only if correlation is true.) The estimated correlations of the estimated coefficients.}
#' \item{symbolic.cor}{(only if correlation is true.) The value of the argument symbolic.cor.}
#'
#' and the following components of \code{object}:
#'
#' \code{call,link,deviance,aic,df.residual,null.deviance,df.null,iter,converged,na.action,L.values}
#'
#' @examples
#' # Example 1
#' set.seed(10)
#' mrbdata = sim.mrb (beta = c(1, -2),
#'                    x = cbind(x1 = runif(100, min = -10, max = 5),
#'                              x2 = runif(100, min = -5, max = 10)),
#'                    delta = qlogis(.66))$data
#'
#' MRBfit = glm.mrb (y ~ x1 + x2, data = mrbdata)
#'
#' SumMRBfit = summary(MRBfit)
#'
#' SumMRBfit
#'

summary.mrbglm <- function(object,
                           order.intercepts = NULL,
                           correlation = FALSE,
                           symbolic.cor = FALSE,
                           rsquared.method = 'KL',
                           ...) {
  if(!missing(order.intercepts) && !is.null(order.intercepts)) {
    if (!identical(order.intercepts, object$order.intercepts)) {
      object <- mrb.switch.coef (object)
    }
  }
  est.disp <- FALSE
  df.r <- object$df.residual
  coefs <- c(object$coefficients,
             if(!object$control$fixLo)  object$Lo.coefs,
             if(!object$control$fixL)  object$L.coefs,
             object$me.coefs)
  aliased <- is.na(coefs)
  pq <- object$rank
  covmat <- object$Rmat
  dn <- c("Estimate", "Std. Error")
  if (any(class(covmat) %in% c("simpleError", "error", "condition", "try-error"))) {
    warning("algorithm did not converge: no covariance matrix estimate available")
    covmat <- NA # matrix(NA, ncol = pq, nrow = pq)
    coef.table <- cbind(coefs, NaN, NaN, NaN)
    dimnames(coef.table) <- list(names(coefs), c(dn,
                                                 "t value", "Pr(>|t|)"))
    Lo.table <- cbind(object$Lo.values, NaN)
    colnames(Lo.table) <- dn
    if (!is.null(names(object$Lo.values)))
      rownames(Lo.table) <- names(object$Lo.values)

    L.table <- cbind(object$L.values, NaN)
    colnames(L.table) <- dn
    if (!is.null(names(object$L.values)))
      rownames(L.table) <- names(object$L.values)
  }
  else {
    dimnames(covmat) <- list(names(coefs), names(coefs))
    var.cf <- diag(covmat)
    s.err <- sqrt(var.cf)
    tvalue <- coefs/s.err
    pvalue <- 2 * pnorm(-abs(tvalue))
    coef.table <- cbind(coefs, s.err, tvalue, pvalue)
    dimnames(coef.table) <- list(names(coefs), c(dn,
                                                 "z value", "Pr(>|z|)"))

    pi <- sum(object$intercepts)
    if (!object$control$fixLo & object$qo > 0) {
      Jaco <- numDeriv::jacobian(func = deltao2Lo, x = object$Lo.coefs, object = object)
      Lo.cov.scaled <- Jaco %*% object$Rmat[(pi + object$p +
                                              1):(pi + object$p + object$qo),
                                           (pi + object$p +
                                              1):(pi + object$p + object$qo),
                                           drop = FALSE] %*% t(Jaco)
      Lo.err <- sqrt(diag(Lo.cov.scaled))
      Lo.table <- cbind(object$Lo.values, Lo.err)
    }
    else
      Lo.table <- cbind(object$Lo.values, NaN)
    colnames(Lo.table) <- dn
    if (!is.null(names(object$Lo.values)))
      rownames(Lo.table) <- names(object$Lo.values)

    if (!object$control$fixL & object$q > 0) {
      Jac <- numDeriv::jacobian(func = delta2L, x = object$L.coefs, object = object)
      L.cov.scaled <- Jac %*% object$Rmat[(pi + object$p + object$qo + 1
                                           ):(pi + object$p + object$qo + object$q),
                                          (pi + object$p + object$qo + 1
                                           ):(pi + object$p + object$qo + object$q),
                                          drop = FALSE] %*% t(Jac)
      L.err <- sqrt(diag(L.cov.scaled))
      L.table <- cbind(object$L.values, L.err)
    }
    else
      L.table <- cbind(object$L.values, NaN)
    colnames(L.table) <- dn
    if (!is.null(names(object$L.values)))
      rownames(L.table) <- names(object$L.values)
  }
  df.f <- length(aliased)
  object$iter <- object$iter
  keep <- match(c("call", "link", "deviance", "aic",
                  "df.residual", "null.deviance", "df.null", "iter",
                  "converged", "na.action", "Lo.values", "L.values", "me.mat"),
                names(object), 0L)
  deviance.resid <- object$residual.deviance
  ans <- c(object[keep],
           list(deviance.resid = deviance.resid,
                coefficients = coef.table,
                Lo = Lo.table, L = L.table,
                aliased = aliased,
                dispersion = object$dispersion, df = c(object$rank, df.r, df.f),
                cov.unscaled = covmat, cov.scaled = covmat,
                r.squared = rsquared(object, method = rsquared.method),
                criterion = object$control$criterion))
  if (correlation && pq > 0) {
    dd <- sqrt(diag(covmat))
    ans$correlation <- covmat/outer(dd, dd)
    ans$symbolic.cor <- symbolic.cor
  }
  class(ans) <- "summary.mrbglm"
  return(ans)
}

# A function to compute L.values from a MRB model object, for a given vector 'delta'
delta2L <- function (delta, object) {
  logLvalues <- object$linkinv(object$fit.call$maxp.offset + c(object$fit.call$zmaxp %*% delta), log.p = TRUE)
  exp (logLvalues)
}

deltao2Lo <- function (deltao, object) {
  logLovalues <- object$linkinv(object$fit.call$minp.offset + c(object$fit.call$zminp %*% deltao), log.p = TRUE)
  exp (logLovalues)
}
